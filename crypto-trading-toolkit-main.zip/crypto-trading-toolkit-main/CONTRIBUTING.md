# Contributing to Crypto Trading Toolkit

感谢你对本项目的关注！我们欢迎任何形式的贡献。

## 如何贡献

### 报告问题 (Issues)

如果你发现了bug或有新功能建议：

1. 在 [Issues](https://github.com/Jasonfifteen/crypto-trading-toolkit/issues) 中搜索
2. 创建新 Issue，包含：
   - 清晰的标题和描述
   - 复现步骤
   - 预期行为 vs 实际行为
   - 环境信息（OS、Python版本）
   - 相关日志

### 提交代码 (Pull Requests)

1. **Fork 并克隆**
   ```bash
   git clone https://github.com/YOUR_USERNAME/crypto-trading-toolkit.git
   cd crypto-trading-toolkit
   ```

2. **创建分支**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **编写代码**
   - 遵循现有代码风格
   - 添加清晰的注释
   - 测试你的更改

4. **提交**
   ```bash
   git commit -m "feat: 描述你的改动"
   ```

5. **创建 PR**
   在 GitHub 上提交 Pull Request

## 贡献领域

### 🤖 AI助手改进
- 优化对话逻辑
- 添加新的分析功能
- 改进市场数据获取

### 📚 交易策略
- 添加新策略
- 优化现有策略参数
- 补充策略文档

### 📖 文档
- 改进使用说明
- 添加示例
- 翻译文档

### 🐛 Bug修复
- 修复已知问题
- 改进错误处理
- 性能优化

## Commit 规范

- `feat:` 新功能
- `fix:` Bug修复
- `docs:` 文档
- `style:` 格式
- `refactor:` 重构
- `test:` 测试
- `chore:` 工具

## 代码风格

- Python: PEP 8
- 4空格缩进
- 有意义的变量名
- 函数添加文档字符串

## 项目结构

```
crypto-trading-toolkit/
├── tools/              # AI助手和工具脚本
├── skills/             # 交易策略库
├── docs/              # 文档
├── README.md
├── LICENSE
└── CONTRIBUTING.md
```

## 测试

提交 PR 前请测试：

```bash
# 测试AI助手
python3 tools/intelligent_bot.py

# 检查语法
python3 -m py_compile tools/*.py
```

## 行为准则

- 尊重所有人
- 包容和友好
- 接受建设性批评
- 专注社区利益

## 需要帮助？

- 📖 [文档](./docs/)
- 💬 [Issues](https://github.com/Jasonfifteen/crypto-trading-toolkit/issues)
- 📧 联系维护者

感谢贡献！🚀
