# 🚀 智能Bot快速开始

## ✅ 当前状态

✅ **Bot已启动** - `intelligent_bot.py` 正在后台运行
✅ **SIREN回本监控已启动** - 价格监控中，回本时自动通知
✅ **Telegram连接正常** - 可以开始对话了

---

## 💬 立即开始对话

打开Telegram，向 [@JasonTread_bot](https://t.me/JasonTread_bot) 发送：

### 示例1: 查询行情
```
ETH的行情怎么样？
```

### 示例2: 交易建议
```
现在能做多BTC吗？
```

### 示例3: 策略咨询
```
推荐一个交易策略
```

### 示例4: 深度分析
```
分析一下SOL
```

---

## 🎯 Bot会做什么

1. **理解你的问题** - 不需要特定格式，随便聊
2. **获取实时数据** - 自动查询Binance市场数据
3. **深度分析** - 价格、资金费率、订单簿、趋势判断
4. **给出建议** - 具体的入场点、止损位、止盈位
5. **记住对话** - 可以连续提问

---

## 📊 可以问的问题类型

### 行情查询
- "ETH多少钱"
- "看一下BTC价格"
- "SIREN现在的行情"

### 交易决策
- "能做多ETH吗"
- "BTC可以做空吗"
- "SIREN适合入场吗"

### 策略学习
- "推荐交易策略"
- "新手适合什么策略"
- "meme币怎么交易"

### 深度分析
- "分析BTC"
- "研究一下ETH"
- "SOL深度分析"

### 持仓咨询
- "我的SIREN空单还能回本吗"
- "持仓情况"
- "分析一下我的仓位"

---

## 🔧 管理命令

### 查看Bot状态
```bash
ps aux | grep intelligent_bot.py
```

### 查看实时日志
```bash
tail -f /Users/helei/Downloads/jason-trading-skills/tools/intelligent_bot.log
```

### 重启Bot
```bash
pkill -f "intelligent_bot.py"
cd /Users/helei/Downloads/jason-trading-skills/tools
python3 -u intelligent_bot.py > intelligent_bot.log 2>&1 &
```

### 停止Bot
```bash
pkill -f "intelligent_bot.py"
```

---

## 🎁 特殊功能

### SIREN回本监控
- ✅ **已自动启动**
- 目标价格: $2.6168
- 检查间隔: 30秒
- 回本时会立即通知你，并给出止盈建议

### 查看监控状态
```bash
ps aux | grep siren_breakeven_monitor
tail -f /Users/helei/Downloads/jason-trading-skills/tools/siren_monitor.log
```

---

## 💡 使用技巧

### 1. 自然对话
不需要记命令，想怎么问就怎么问：
- ✅ "ETH怎么样" → Bot会理解
- ✅ "看看BTC" → Bot会查价格
- ✅ "能做多吗" → Bot会分析建议

### 2. 连续提问
Bot会记住对话，可以连续问：
```
你: "ETH的行情"
Bot: [显示行情]

你: "能做多吗"
Bot: [针对ETH给建议]

你: "给个具体点位"
Bot: [详细入场/止损/止盈]
```

### 3. 明确币种
如果你问"现在能做多吗"，Bot会默认分析ETH。
更好的方式：**"BTC能做多吗"**

### 4. 查看多个币种
可以一次问多个：
```
"分别看一下BTC和ETH的行情"
```

---

## 🔔 通知设置

### 当前通知
1. **Bot启动通知** - 启动时发送一次
2. **SIREN回本通知** - 价格到达时自动通知
3. **SIREN接近回本提醒** - 距离<1%时提前提醒

### 自定义通知（开发中）
未来可以设置：
- "ETH突破2100提醒我"
- "BTC跌破40000通知我"
- "资金费率超过0.1%通知"

---

## 🆙 升级到GPT-4（可选）

如果想要更智能的对话：

1. **获取OpenAI API Key**
   - 访问 https://platform.openai.com/api-keys
   - 创建新的API Key

2. **重启Bot带API Key**
```bash
pkill -f "intelligent_bot.py"
cd /Users/helei/Downloads/jason-trading-skills/tools

# 方法1: 环境变量
export OPENAI_API_KEY="sk-xxxxx"
python3 -u intelligent_bot.py > intelligent_bot.log 2>&1 &

# 方法2: 命令行参数
python3 -u intelligent_bot.py --openai-key "sk-xxxxx" > intelligent_bot.log 2>&1 &
```

**GPT-4的优势：**
- 更自然的对话
- 理解复杂问题
- 记忆能力更强
- 推理更深入

**当前模式（智能规则引擎）已经很好用：**
- 免费
- 响应快
- 能处理90%的场景

---

## ⚠️ 重要提示

1. **Bot建议仅供参考**
   - 不构成投资建议
   - 自己判断风险

2. **严格风险管理**
   - 必须设置止损
   - 不要满仓
   - 小仓位试探

3. **市场变化快**
   - 数据有延迟
   - 及时调整策略
   - 保持警惕

---

## 📱 联系方式

- Telegram Bot: [@JasonTread_bot](https://t.me/JasonTread_bot)
- 有问题直接问Bot，它会尽力回答！

---

## 🎉 现在就开始

1. 打开Telegram
2. 找到 @JasonTread_bot
3. 发送："你好，帮我看一下ETH的行情"

享受智能交易助手的便利！ 🚀
