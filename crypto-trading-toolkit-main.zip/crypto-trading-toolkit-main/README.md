# Crypto Trading Toolkit

🚀 专业加密货币交易工具包 - AI助手 + 交易策略

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)

---

## 🎯 本仓库内容

### 🤖 AI交易助手
智能Telegram机器人，提供实时市场分析和交易建议

**核心功能：**
- 💬 自然语言对话
- 📊 实时市场数据分析
- 🎯 交易建议和策略推荐
- 📈 资金费率、K线分析

[使用文档 →](./docs/INTELLIGENT_BOT_GUIDE.md)

### 📚 交易策略库
5大经过验证的交易策略文档

- Smart Money Following - 跟随聪明钱
- Momentum Meme Trading - Meme币交易
- Funding Rate Arbitrage - 资金费率套利
- Breakout & Retest - 突破回测
- Spot Grid Trading - 现货网格

[查看策略 →](./skills/trading-strategies/)

---

## 📦 监控和信号系统

市场监控和交易信号功能已独立为单独的项目：

### → [dex-monitoring-skill](https://github.com/Jasonfifteen/dex-monitoring-skill)

**包含：**
- 🔍 通用DEX代币实时监控
- 🎯 自动交易信号捕捉
- 📊 庄家行为识别
- 💰 智能风险管理

如需使用监控和信号功能，请访问上述独立仓库。

---

## 🚀 快速开始

### 安装依赖
```bash
pip3 install requests
```

### 使用AI助手
```bash
# 配置
export TELEGRAM_BOT_TOKEN="your_token"
export TELEGRAM_CHAT_ID="your_chat_id"

# 运行
python3 tools/intelligent_bot.py
```

---

## 🛠️ 工具列表

| 文件 | 功能 | 版本 |
|------|------|------|
| `intelligent_bot.py` | AI对话助手 | v3.0 |
| `ai_telegram_bot.py` | 基础版Bot | v2.0 |
| `get_chat_id.py` | 获取Chat ID | v1.0 |

---

## 📖 文档

- [AI Bot使用指南](./docs/INTELLIGENT_BOT_GUIDE.md)
- [交易策略文档](./skills/trading-strategies/)
- [风险管理](./docs/RISK_MANAGEMENT.md)
- [Telegram设置](./docs/TELEGRAM_SETUP.md)

---

## 🔗 相关项目

- **[dex-monitoring-skill](https://github.com/Jasonfifteen/dex-monitoring-skill)** - DEX监控和交易信号系统

---

## ⚠️ 风险提示

本项目仅供学习研究。加密货币交易有风险，投资需谨慎。

---

## 📄 许可

MIT License

---

**需要监控功能？** → 访问 [dex-monitoring-skill](https://github.com/Jasonfifteen/dex-monitoring-skill)
