# 🔐 GitHub 2FA 重新设置指南

## 问题：手机上没有GitHub的2FA验证码

如果你当初设置2FA时没有保存恢复码，现在又找不到验证器，有以下解决方案：

---

## 方案1: 使用Personal Access Token（推荐，不需要2FA）

这是**最简单的方法**，可以完全绕过2FA验证码！

### 步骤：

#### 1. 访问GitHub Token设置页面

**直接访问：**
```
https://github.com/settings/tokens
```

**或者手动导航：**
1. 登录GitHub（网页版）
2. 点击右上角头像
3. Settings
4. 左侧找到 "Developer settings"（最底部）
5. Personal access tokens → Tokens (classic)

#### 2. 创建新Token

点击 **"Generate new token (classic)"**

**如果这里要求2FA验证码：**
- 先看方案2（移除2FA）
- 或使用恢复码（如果有保存）

#### 3. 配置Token

```
Token名称: jason-trading-skills
过期时间: No expiration（不过期）

权限勾选:
✅ repo (完整仓库权限)
  ✅ repo:status
  ✅ repo_deployment
  ✅ public_repo
  ✅ repo:invite
  ✅ security_events
```

#### 4. 生成并复制Token

1. 点击 "Generate token"
2. **立即复制Token！** 
   - 格式: `ghp_xxxxxxxxxxxxxxxxxxxx`
   - ⚠️ 离开页面后无法再次查看
3. 保存到安全的地方

#### 5. 在Git中使用Token

```bash
# 配置Git记住凭据
git config --global credential.helper store

# 创建GitHub仓库（在GitHub网页上）
# 然后添加远程仓库
cd /Users/helei/Downloads/jason-trading-skills
git remote add origin https://github.com/YOUR_USERNAME/jason-trading-skills.git

# Push时使用Token
git push -u origin main
# Username: 你的GitHub用户名
# Password: 粘贴Token（不是密码！）

# 输入一次后，Git会记住，以后不需要再输入
```

---

## 方案2: 关闭2FA后重新设置

**⚠️ 警告：暂时降低账户安全性**

### 如果你能登录GitHub网页：

#### 步骤1: 移除2FA

1. 登录GitHub（网页）
2. Settings → Password and authentication
3. 找到 "Two-factor authentication"
4. 如果有 "Disable" 按钮 → 点击禁用
5. 可能需要输入密码确认

**如果要求2FA验证码才能禁用：**
- 使用恢复码（如果有）
- 联系GitHub支持恢复账号
- 跳转到方案3

#### 步骤2: 创建Token

禁用2FA后，按方案1的步骤创建Token

#### 步骤3: 重新启用2FA（可选）

1. 使用新的验证器app（推荐Google Authenticator或Microsoft Authenticator）
2. Settings → Password and authentication
3. Enable two-factor authentication
4. 扫描二维码
5. **保存恢复码！！！**（这次一定要保存）

---

## 方案3: 使用恢复码（Recovery Codes）

如果你设置2FA时保存了8个恢复码：

### 在哪里找恢复码？

- 邮箱（GitHub发送的设置确认邮件）
- 密码管理器（如果有保存）
- 笔记本/记事本
- 截图/照片

### 使用恢复码：

1. 在2FA验证页面
2. 点击 "More options"
3. 选择 "Use a recovery code"
4. 输入一个恢复码（每个只能用一次）
5. 登录后立即生成新的恢复码

---

## 方案4: 联系GitHub支持（最后手段）

如果以上都不行：

1. 访问: https://support.github.com/contact
2. 选择 "Account recovery"
3. 说明情况：
   ```
   I lost access to my 2FA authenticator and don't have recovery codes.
   I need to disable 2FA to regain access to my account.
   ```
4. 提供身份证明（可能需要）
5. 等待GitHub支持回复（通常1-3天）

---

## 推荐操作流程（最简单）

### 方案A: 如果能创建Token（不需要2FA验证）

```bash
# 1. 在GitHub网页创建Token
访问 https://github.com/settings/tokens → Generate token

# 2. 在GitHub网页创建新仓库
仓库名: jason-trading-skills
类型: Public 或 Private

# 3. 本地配置
cd /Users/helei/Downloads/jason-trading-skills
git remote add origin https://github.com/YOUR_USERNAME/jason-trading-skills.git
git config --global credential.helper store
git push -u origin main
# 输入: Username + Token

# 完成！
```

### 方案B: 如果创建Token需要2FA

```bash
# 1. 先移除2FA
GitHub Settings → Password and authentication → Disable 2FA

# 2. 创建Token
按方案A操作

# 3. （可选）重新启用2FA并保存恢复码
```

---

## 安全提示

✅ **推荐做法：**
- 使用Token而不是密码
- Token设置适当的权限
- Token过期时间设置合理
- 多个项目使用不同Token

✅ **2FA最佳实践：**
- 使用多个验证器（备份）
- 保存恢复码在安全的地方
- 定期检查2FA设置
- 考虑使用硬件密钥（YubiKey）

❌ **不要做：**
- Token不要提交到代码仓库
- Token不要分享给他人
- 恢复码不要保存在联网设备
- 不要使用真实密码进行git push

---

## 快速检查清单

**测试你能否创建Token：**

- [ ] 能登录GitHub网页
- [ ] 能访问 https://github.com/settings/tokens
- [ ] 点击 "Generate new token" 后：
  - [ ] 不需要2FA → **使用方案1**
  - [ ] 需要2FA但有恢复码 → **使用方案3**
  - [ ] 需要2FA且无恢复码 → **使用方案2或4**

---

## 现在该做什么？

1. **检查能否访问Token页面**
   ```
   https://github.com/settings/tokens
   ```

2. **尝试创建Token**
   - 成功 → 太好了！按方案1操作
   - 失败（要求2FA）→ 告诉我，我们用其他方案

3. **告诉我结果**
   - "可以创建Token了"
   - "需要2FA验证码"
   - "有恢复码"
   - "都没有，需要联系支持"

---

**我会根据你的情况提供具体的命令！** 🚀
