# Telegram Bot Setup Guide

## 快速开始

### 1. 获取Bot Token

1. 在Telegram搜索 `@BotFather`
2. 发送 `/newbot`
3. 按提示设置机器人名称
4. 获得Token（格式: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`）

### 2. 获取Chat ID

**方法1: 使用工具脚本**
```bash
cd /Users/helei/Downloads/jason-trading-skills/tools
python3 get_chat_id.py
# 按提示输入Bot Token
# 给机器人发送任意消息
# 脚本会显示你的Chat ID
```

**方法2: 手动获取**
1. 给你的机器人发送一条消息
2. 访问: `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates`
3. 找到 `"chat":{"id":123456789}` 中的数字

### 3. 配置环境变量

```bash
# 临时配置（当前终端）
export TELEGRAM_BOT_TOKEN="your_bot_token_here"
export TELEGRAM_CHAT_ID="your_chat_id_here"

# 永久配置（添加到 ~/.zshrc 或 ~/.bashrc）
echo 'export TELEGRAM_BOT_TOKEN="your_bot_token_here"' >> ~/.zshrc
echo 'export TELEGRAM_CHAT_ID="your_chat_id_here"' >> ~/.zshrc
source ~/.zshrc
```

### 4. 安装依赖

```bash
pip3 install requests
```

### 5. 启动机器人

```bash
cd /Users/helei/Downloads/jason-trading-skills/tools
python3 ai_telegram_bot.py
```

**后台运行：**
```bash
nohup python3 ai_telegram_bot.py > bot.log 2>&1 &
echo $! > bot.pid
```

**停止机器人：**
```bash
kill $(cat bot.pid)
```

---

## 机器人功能

### 1. 价格查询
```
ETH价格
BTC现货价格
SIREN合约价格
```

### 2. 代币分析
```
分析 SIREN
分析 0x997a58129890bbda032231a52ed1ddc845fc18e1
分析 ETH Ethereum
```

### 3. 策略咨询
```
推荐策略
ETH合约策略
Meme币怎么交易
稳定收益策略
网格交易怎么设置
```

### 4. 实时监控
```
监控 SIREN
停止监控
当前监控状态
```

### 5. 帮助
```
help
帮助
```

---

## 高级配置

### 自定义监控参数

编辑 `ai_telegram_bot.py`:

```python
# 监控间隔（秒）
self.monitor_interval = 300  # 5分钟

# 止损/止盈设置
self.position = {
    "entry_price": 2.5235,
    "stop_loss": 2.75,
    "take_profit_1": 2.35,
    "take_profit_2": 2.20,
    # ...
}
```

### 添加新代币监控

```python
def start_monitoring(self, currency):
    """添加新代币到监控列表"""
    self.monitored_tokens[currency] = {
        "entry_price": current_price,
        "stop_loss": stop_loss_price,
        # ...
    }
```

---

## 故障排除

### 机器人无响应
1. 检查进程是否运行: `ps aux | grep ai_telegram_bot`
2. 查看日志: `tail -f bot.log`
3. 检查网络连接
4. 验证Token和Chat ID是否正确

### API超时
- Telegram API在中国可能需要代理
- 修改代码中的 `timeout=3` 参数
- 考虑使用VPN

### 数据获取失败
- 检查Binance API连接
- 验证代币符号是否正确
- 查看具体错误信息

---

## 安全建议

1. **不要分享Bot Token** - Token泄露后立即重置
2. **Chat ID保密** - 防止他人向你的bot发送命令
3. **API密钥安全** - 如果使用交易API，严格保护密钥
4. **代码审查** - 使用前检查代码内容

---

**需要帮助？** 查看完整文档或联系 @JasonFifteen
