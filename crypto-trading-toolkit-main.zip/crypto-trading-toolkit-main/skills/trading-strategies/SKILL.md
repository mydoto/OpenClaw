---
name: trading-strategies
version: "2026.3.23"
updated: "2026-03-23"
description: "Comprehensive trading strategy guidance for crypto futures, spot, meme coins, and on-chain tokens. Provides multi-strategy analysis framework covering Smart Money Following, Momentum Meme Trading, Funding Rate Arbitrage, Breakout & Retest, and Spot Grid Trading. Use this skill when users ask for trading advice, strategy recommendations, risk management, entry/exit signals, or position management across any market type."
---

# Trading Strategies Assistant

This skill provides **comprehensive trading strategy analysis and recommendations** for cryptocurrency markets, covering futures, spot, meme coins, and on-chain tokens. It integrates 5 proven trading strategies and provides actionable insights based on real-time market data.

## Strategy Framework

### 5 Core Strategies

| # | Strategy | Risk Level | Market Type | Use Case |
|---|----------|------------|-------------|----------|
| 1 | **Smart Money Following** | Medium | All | Follow institutional flows and whale movements |
| 2 | **Momentum Meme Trading** | High | Meme/New Tokens | Short-term speculation on viral tokens |
| 3 | **Funding Rate Arbitrage** | Low | Futures | Delta-neutral arbitrage on funding rates |
| 4 | **Breakout & Retest** | Medium | Futures/Spot | Trend-following on key level breakouts |
| 5 | **Spot Grid Trading** | Low | Spot | Automated profit from range-bound markets |

## Trigger Phrases

Use this skill when users ask about:
- "交易策略" / "trading strategy"
- "推荐策略" / "recommend strategy"
- "怎么交易" / "how to trade"
- "Meme币怎么买" / "how to trade meme coins"
- "稳定收益" / "stable income"
- "网格交易" / "grid trading"
- "资金费率套利" / "funding rate arbitrage"
- "突破交易" / "breakout trading"
- "跟随聪明钱" / "smart money following"
- Token-specific strategy questions (e.g., "ETH合约策略", "SIREN交易建议")

## Strategy Selection Logic

### Step 1: Identify Token/Market Type

```python
if token is BTC/ETH/major_altcoin:
    suitable_strategies = [Breakout, Funding_Arbitrage, Smart_Money, Grid]
    exclude = [Momentum_Meme]
    
elif token is meme_coin or high_volatility:
    suitable_strategies = [Momentum_Meme, Smart_Money]
    use_with_caution = [Grid]
    exclude = [Funding_Arbitrage]
    
elif token is mid_cap_altcoin:
    suitable_strategies = [Breakout, Smart_Money, Grid]
    
elif market_condition == "ranging":
    primary = Grid
    secondary = Breakout
    
elif market_condition == "trending":
    primary = Breakout
    secondary = Smart_Money
```

### Step 2: Analyze Market Data

Required data points:
- ✅ Current price & 24h change
- ✅ Volume & liquidity
- ✅ Funding rate (for futures)
- ✅ Order book depth / buy-sell ratio
- ✅ Recent price action (1h, 4h, 12h trends)
- ✅ Smart Money flows (if available)
- ✅ Key support/resistance levels

### Step 3: Multi-Strategy Scoring

Rate each strategy on scale of 1-5:
- ⭐⭐⭐⭐⭐ Highly Recommended
- ⭐⭐⭐⭐ Recommended
- ⭐⭐⭐ Suitable
- ⭐⭐ Use with Caution
- ⭐ Not Recommended / Not Applicable

## Execution Workflow

### 1. When User Asks for General Strategy Advice

**Example: "推荐交易策略" / "What strategies do you recommend?"**

Response template:
```markdown
🎯 **5大交易策略对比**

**高风险高收益：**
🚀 Momentum Meme Trading
- 适合：新上线Meme币，暴涨币种
- 风险：极高（可能归零）
- 收益：单日10-100%+
- 持仓时间：数小时到1-2天

**中等风险：**
🔥 Breakout & Retest
- 适合：主流币合约，趋势明显
- 风险：中等（需严格止损）
- 收益：单次3-15%
- 持仓时间：1-7天

🧠 Smart Money Following
- 适合：所有市场，跟随机构
- 风险：中等（需验证信号）
- 收益：持续5-20%
- 持仓时间：根据聪明钱动向

**低风险稳定收益：**
💰 Funding Rate Arbitrage
- 适合：期货市场，资金费率极端时
- 风险：低（对冲保护）
- 收益：年化10-30%
- 持仓时间：数天到数周

📊 Spot Grid Trading
- 适合：震荡市，主流币现货
- 风险：低（无爆仓风险）
- 收益：震荡一轮0.5-2%
- 持仓时间：持续运行

**根据你的风险偏好选择：**
- 激进型 → Momentum Meme
- 平衡型 → Breakout + Smart Money
- 稳健型 → Grid + Funding Arbitrage
```

### 2. When User Asks for Token-Specific Strategy

**Example: "分析ETH合约策略" / "ETH trading strategy"**

Workflow:
```
1. Fetch market data (price, volume, funding rate, trends)
2. Analyze current market state:
   - Trending or ranging?
   - High or low volatility?
   - Buy pressure or sell pressure?
3. Score each strategy (1-5) for this specific token
4. Recommend top 3 strategies with detailed execution plans
5. Provide specific entry/exit levels, stop-loss, take-profit
6. Include risk management rules
7. Provide actionable next steps
```

Response template structure:
```markdown
🔷 **[TOKEN] 合约交易策略分析**

**当前市场概况**
[Price, 24h change, volume, funding rate, trends]

**5大策略适配分析**

1️⃣ [Strategy Name] - ⭐⭐⭐⭐⭐
[Current signals, entry/exit conditions, specific parameters]

2️⃣ [Strategy Name] - ⭐⭐⭐⭐
[Analysis...]

[Continue for all 5 strategies]

**当前最优策略**
[Detailed execution plan with specific levels]

**风险管理**
[Position sizing, stop-loss rules, take-profit strategy]

**立即行动方案**
[Step-by-step action items]
```

### 3. When User Asks About Specific Strategy

**Example: "Meme币怎么交易?" / "网格交易怎么设置?"**

- Read the corresponding strategy document from `/references/`
- Provide concise summary (2-3 paragraphs)
- Include key rules and parameters
- Give 1-2 practical examples
- Link to full documentation if user wants details

## Strategy Reference Documents

| Strategy | Document | Content |
|----------|----------|---------|
| Smart Money Following | `references/smart-money-following.md` | How to track and follow institutional flows |
| Momentum Meme Trading | `references/momentum-meme-trading.md` | High-risk meme coin speculation tactics |
| Funding Rate Arbitrage | `references/funding-rate-arbitrage.md` | Delta-neutral funding rate capture |
| Breakout & Retest | `references/breakout-retest.md` | Trend-following on key level breaks |
| Spot Grid Trading | `references/spot-grid-trading.md` | Automated range-trading setup |
| Strategy Comparison | `references/README.md` | Side-by-side comparison table |

## Risk Management Framework

### Universal Risk Rules (Apply to ALL Strategies)

```python
# Position Sizing
single_position_risk = 2-5% of total_capital
max_concurrent_positions = 3
total_leverage_exposure <= 2x account_value

# Stop-Loss
always_set_stop_loss = True
max_loss_per_trade = 2-3% of account
stop_loss_types = ["price", "time", "signal"]

# Take-Profit
use_scaled_exits = True  # Close 50% at TP1, trail rest
typical_profit_targets = [1.5x, 2x, 3x of stop_loss distance]

# Leverage
conservative = 2-3x
moderate = 5-10x
aggressive = 10-20x  # Only for experienced traders
never_exceed = 20x
```

### Strategy-Specific Risk Adjustments

| Strategy | Max Leverage | Stop-Loss | Position Size |
|----------|--------------|-----------|---------------|
| Momentum Meme | 3-5x | Wide (-15-20%) | Small (5-10% capital) |
| Breakout | 5-10x | Tight (-2-3%) | Medium (20-30%) |
| Smart Money | 3-10x | Medium (-5%) | Medium (15-25%) |
| Funding Arbitrage | 1-3x | Wide (-10%) | Large (50-80%) |
| Grid Trading | 1-2x | None (range exit) | Large (30-50%) |

## Market Data Integration

### Required APIs

```python
# Binance Futures
GET /fapi/v1/ticker/24hr?symbol={SYMBOL}
GET /fapi/v1/fundingRate?symbol={SYMBOL}&limit=3
GET /fapi/v1/klines?symbol={SYMBOL}&interval={INTERVAL}&limit={LIMIT}
GET /fapi/v1/depth?symbol={SYMBOL}&limit=20

# Binance Spot
GET /api/v3/ticker/24hr?symbol={SYMBOL}
GET /api/v3/avgPrice?symbol={SYMBOL}

# Binance Web3 (Smart Money)
POST /bapi/defi/v1/public/wallet-direct/tracker/wallet/token/inflow/rank/query/ai
Body: {"chainId": "56", "period": "24h", "tagType": 2}

# Gate Alpha (On-chain tokens)
GET /alpha/tickers?currency={CURRENCY}
GET /alpha/tokens?chain={CHAIN}
```

### Data Processing

```python
def analyze_market_trend(price_data, smart_money_flow, volume):
    """
    Returns: {
        "trend": "bullish" | "bearish" | "neutral",
        "volatility": "low" | "medium" | "high",
        "sentiment": "strong_buy" | "buy" | "neutral" | "sell" | "strong_sell",
        "reversal_score": -5 to +5  # Negative=bearish, Positive=bullish
    }
    """
    # Implementation in ai_telegram_bot.py > analyze_market_trend()
```

## Response Templates

### Template 1: Multi-Strategy Analysis (for specific token)

```
🔷 **{TOKEN} 合约交易策略分析**
_(基于5大交易策略框架)_

*当前市场概况*
💰 价格: ${price}
📊 24h变化: {change}%
📈 24h最高: ${high}
📉 24h最低: ${low}
💹 24h波动: {volatility}%
💰 资金费率: {funding_rate}%
📊 买卖比: {ratio}

*趋势分析*
⏰ 1小时: {trend_1h}%
⏰ 4小时: {trend_4h}%
⏰ 12小时: {trend_12h}%

━━━━━━━━━━━━━━━━━━

*🎯 5大策略适配分析*

*1️⃣ {Strategy 1}*
✅ *推荐指数: ⭐⭐⭐⭐⭐*
[Analysis and execution plan]

*2️⃣ {Strategy 2}*
[Continue...]

━━━━━━━━━━━━━━━━━━

*🎯 当前最优策略*

*📍 短期策略 (1-3天)*
[Detailed execution with specific levels]

*📍 中期策略 (1-2周)*
[Trend-following approach]

━━━━━━━━━━━━━━━━━━

*⚠️ 风险管理*
[Position sizing, stop-loss, take-profit rules]

━━━━━━━━━━━━━━━━━━

*🎬 立即行动方案*
✅ 观察信号: [Specific levels to watch]
✅ 设置订单: [Exact order parameters]
✅ 监控指标: [What to monitor]

━━━━━━━━━━━━━━━━━━

*📊 核心结论*
[Summary with emoji status indicators]

*最佳策略*
🥇 {Top strategy}
🥈 {Second strategy}
🥉 {Third strategy}

*下一步*
[Clear next actions]
```

### Template 2: Strategy Explanation (for strategy queries)

```
🎯 **{Strategy Name}**

*策略概述*
[2-3 sentences explaining the strategy]

*适用场景*
✅ {Scenario 1}
✅ {Scenario 2}
✅ {Scenario 3}

*核心原则*
1. {Rule 1}
2. {Rule 2}
3. {Rule 3}

*操作步骤*
```
{Step-by-step instructions}
```

*风险控制*
⚠️ {Risk 1}
⚠️ {Risk 2}
✅ {Mitigation 1}
✅ {Mitigation 2}

*实战案例*
{Example scenario with numbers}

_详细文档：references/{strategy-filename}.md_
```

### Template 3: General Strategy Overview

```
🎯 **5大交易策略推荐**

**高风险高收益 (适合激进型)**
🚀 Momentum Meme Trading
风险: ⚠️⚠️⚠️⚠️⚠️ | 收益: 💰💰💰💰💰
[One-line description]

**中等风险 (适合平衡型)**
🔥 Breakout & Retest
🧠 Smart Money Following
[Descriptions...]

**低风险稳定 (适合稳健型)**
💰 Funding Rate Arbitrage
📊 Spot Grid Trading
[Descriptions...]

**选择建议：**
• 新手 → Grid Trading
• 有经验 → Breakout + Smart Money
• 老手 → 全策略组合
• Meme投机 → Momentum (小仓位)

**想了解某个策略？**
回复策略名称，如："Meme币交易"、"网格设置"
```

## Telegram Bot Integration

The trading strategies are integrated into `ai_telegram_bot.py`:

```python
def handle_strategy_query(self, text):
    """Route strategy-related queries to appropriate responses"""
    
    if "推荐策略" in text or "有什么策略" in text:
        return self.get_strategy_overview()
    
    elif "meme" in text.lower() or "meme币" in text:
        return self.get_momentum_meme_strategy()
    
    elif "稳定收益" in text or "稳健" in text:
        return self.get_stable_strategies()
    
    elif "网格" in text or "grid" in text.lower():
        return self.get_grid_trading_guide()
    
    else:
        return self.list_available_strategies()
```

## Error Handling

| Error Type | Response |
|------------|----------|
| No market data available | "⚠️ 无法获取市场数据，请稍后重试" |
| Token not found | "❌ 未找到该代币，请检查代币名称" |
| Insufficient data for analysis | "⚠️ 数据不足，建议等待更多交易数据" |
| High volatility warning | "🚨 当前波动率极高，建议降低仓位" |
| Low liquidity warning | "⚠️ 流动性较低，谨慎使用大额订单" |

## Safety Rules

1. **Never guarantee profits** - Always emphasize risks
2. **Always provide stop-loss** - Never suggest trades without risk management
3. **Warn on high leverage** - Caution when >10x is mentioned
4. **Disclose limitations** - Be honest about strategy constraints
5. **Token-specific warnings**:
   - Meme coins: "⚠️ Meme币风险极高，可能归零"
   - New tokens: "⚠️ 新币种，历史数据不足"
   - Low liquidity: "⚠️ 流动性低，滑点可能很大"

## Version History

- **2026.3.23**: Initial comprehensive strategy skill
  - Integrated 5 core strategies
  - Multi-strategy analysis framework
  - Risk management rules
  - Telegram bot integration
  - Response templates

## Related Skills

- `gate-exchange-alpha`: For Alpha token trading execution
- `siren-realtime-monitor`: For real-time market monitoring
- `ai-trading-assistant`: For Telegram bot integration

---

**Usage Note**: This is a guidance skill. For actual trade execution on Gate Alpha, use the `gate-exchange-alpha` skill. This skill provides strategy recommendations and analysis only.
