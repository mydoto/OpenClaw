---
name: Breakout & Retest Futures Strategy  
description: |
  Captures volatility expansion as price leaves consolidation zones. Trades 
  breakouts with confirmation, targeting liquidation cascades and stop hunts.
  Best for 4H-1D timeframes on major pairs.
category: Futures Trading
win_rate: 55-65%
risk_level: Medium-High
timeframe: 4H-1D
---

# 🔥 Breakout & Retest Strategy

## 概述

捕捉价格突破盘整区间后的波动扩张，利用强制平仓和止损猎杀产生的连锁反应。

## 核心原理

市场80%时间处于盘整，20%时间趋势。突破moment是最易赚钱的时机，因为：

- ✅ 突破触发大量止损单
- ✅ 引发强制平仓连锁反应
- ✅ FOMO情绪导致追涨
- ✅ 方向明确，盈亏比好

## 设置流程

### 1. 识别盘整区间

```python
# 价格在区间震荡至少 48小时
consolidation_time >= 48_hours

# 振幅 < 5%
range = (high - low) / low
if range < 0.05:
    consolidation = True

# 触碰边界多次
touches_resistance >= 3
touches_support >= 3
```

**视觉识别**:
```
价格图表:

$70k -------|||||||||-------  ← 阻力
           盘整区
$68k -------|||||||||-------  ← 支撑

越盘越久 = 突破越强
```

### 2. 等待突破

**有效突破标准**:

```python
# A. 价格突破
if close > resistance:
    breakout = True

# B. 成交量确认
if volume > 2 * avg_volume:
    volume_confirm = True

# C. 收盘确认
if 4h_candle_close > resistance:
    time_confirm = True

# 全部满足 = 真突破
if breakout and volume_confirm and time_confirm:
    valid_breakout = True
```

### 3. 入场时机

**方式 1: 激进 - 突破即入**
```python
# 突破瞬间入场
if price > resistance and volume_surge:
    enter_long()
    stop_loss = consolidation_low
```

**方式 2: 保守 - 等回踩**
```python
# 等价格回测阻力位(现变支撑)
if price_retested_resistance and bounced:
    enter_long()  
    stop_loss = resistance * 0.98
```

### 4. 止损设置

```python
# 激进入场
stop_loss = consolidation_bottom - 1%

# 保守入场(回踩)
stop_loss = resistance - 2%

# 动态调整
if price_moved > +10%:
    move_stop_to_breakeven()
```

### 5. 止盈目标

```python
range_size = resistance - support

# Target 1: 1x区间
TP1 = resistance + range_size
take_profit(50%, TP1)

# Target 2: 2x区间  
TP2 = resistance + range_size * 2
take_profit(30%, TP2)

# Target 3: 跟踪止损
trailing_stop = 15%
```

## 最佳标的选择

### 🥇 BTC/ETH (推荐)
```
✅ 流动性最好
✅ 假突破少
✅ 趋势可预测
✅ 盈亏比优秀
```

### 🥈 Top 10 Altcoins
```
✅ 波动更大
✅ 突破力度强
⚠️ 假突破多
⚠️ 需要更严格确认
```

### 🥉 避免
```
❌ 小市值币 - 易操纵
❌ 新上币 - 无历史数据
❌ Meme币 - 随机性强
```

## 进阶技巧

### A. 识别假突破

**假突破特征**:
```
1. 成交量未放大
2. 只有单根针突破
3. 快速回落至区间内
4. 无后续跟进
```

**应对**:
```python
if breakout:
    wait_for_confirmation(4_hours)
    
    if price_back_in_range:
        fake_breakout = True
        do_not_enter()
```

### B. 利用清算图

```python
# 查看清算热力图
liquidation_map = get_liquidations()

# 阻力位上方有大量多头清算
if liquidation_cluster_above_resistance:
    # 突破后可能触发连锁清算
    # 增加仓位信心
    confidence = "HIGH"
```

### C. 多时间框架确认

```
1D: 识别大级别区间
4H: 确认突破
1H: 精确入场
15m: 设置止损
```

## 实战案例

### ✅ BTC突破 $70k (2024年3月)

```
盘整:
- $68k - $70k 震荡 5天
- 触碰$70k 阻力 6次
- 成交量递减(积聚能量)

突破:
- 3月14日 4H收盘 $70,200
- 成交量暴增 3.5x
- 连续2根阳线确认

入场:
- 价格: $70,500  
- 止损: $68,800 (-2.4%)
- 目标: $74,000 (+5%)

结果:
- 36小时到达 TP1 $72,000
- 卖出 50%，实现 +2.1%
- 72小时到达 TP2 $74,500
- 总收益 +4.2%
- 盈亏比: 1.8:1
```

### ❌ 假突破教训

```
盘整:
- ETH $3,200 - $3,400 震荡

突破:
- 单根针突破到 $3,450
- 但成交量正常(未放大)

结果:
- 4小时后回落至 $3,300
- 假突破陷阱

教训:
- 必须等成交量确认
- 必须等收盘确认
- 单根针不算突破
```

## 风险管理

### 仓位大小

```python
account = 10000

# 计算止损距离
entry = 70000
stop_loss = 68500
risk_per_trade = entry - stop_loss  # $1500

# 风险2%
max_risk = account * 0.02  # $200

# 计算仓位
position_size = max_risk / risk_per_trade
# $200 / $1500 = 0.133 BTC

# 或简化版
position = account * 0.10  # 10%总资本
```

### 同时持仓限制

```
最多3个突破仓位
必须不同资产(避免相关性)
总敞口 < 30%
```

### 止损纪律

```
❌ 不要移动止损扩大风险
❌ 不要"再给一次机会"
✅ 价格触及 = 立即退出
✅ 亏损后休息,避免报复性交易
```

## 工具推荐

### 图表分析
- **TradingView** - 最佳图表工具
- **Coinalyze** - 清算图
- **Glassnode** - 链上数据

### 自动提醒
```python
# 设置价格提醒
set_alert(
    symbol="BTCUSDT",
    condition="price > 70000",
    message="BTC突破$70k!"
)
```

### 执行工具
- **Binance** - 深度流动性
- **Bybit** - 多种订单类型
- **3Commas** - 自动化执行

## 性能指标 (2024-2026)

```
胜率: 58%
平均盈利: +6.8%
平均亏损: -2.1%  
盈亏比: 3.2:1
月均交易: 4-6次
年化收益: 45-65%
最大回撤: -12%
```

## 最佳实践

### ✅ 做

```
✅ 等待明确突破
✅ 确认成交量
✅ 使用多时间框架
✅ 严格止损
✅ 分批止盈
✅ 记录每笔交易
```

### ❌ 不做

```
❌ 追高(突破后+5%)
❌ 无止损交易
❌ 盘整内交易
❌ 情绪化决策
❌ 过度交易
```

## 心理准备

### 耐心

```
可能数周无交易机会
不要强行交易
等待高质量设置
```

### 接受亏损

```
40-45%交易会亏损
这是正常的
关键是总体盈亏比
```

### 执行力

```
设置好了就要执行
不要犹豫
不要第二次猜测
```

---

**策略类型**: 趋势跟随/突破  
**最佳时间**: 4H-1D  
**风险等级**: 中高  
**胜率**: 55-65%  
**盈亏比**: 2.5-3.5:1  
**适合**: 有耐心的中级交易者  
**核心**: 等待 + 确认 + 执行