---
name: Smart Money Following Strategy
description: |
  Track and copy verified high-win-rate wallets using on-chain analytics. 
  Monitor large transactions, whale movements, and professional trader behavior 
  across multiple chains. Identifies institutional accumulation/distribution patterns.
category: On-Chain Trading
win_rate: 60%+
risk_level: Medium
chains: ETH, BSC, Base, Solana, Arbitrum
---

# 🧠 Smart Money Following Strategy

## 概述

追踪和复制经过验证的高胜率钱包，利用链上分析监控大额交易、巨鲸动向和专业交易者行为。

## 核心原理

Smart Money（聪明钱）指的是专业投资者、机构和内部人士，他们通常掌握提前信息或有更强的分析能力。

### 为什么有效？

- ✅ 专业交易者平均胜率 60%+
- ✅ 通常提前知道催化剂
- ✅ 链上数据完全透明可追踪
- ✅ 可识别积累/分发模式

## 实施步骤

### 1. 识别 Smart Money 钱包

**筛选标准**：
```
✅ 7天 PnL > 60%
✅ 胜率 > 40% (50%+ 优秀)
✅ 每周交易 < 300 笔
✅ 关注已实现利润，非未实现
✅ 至少 30 天交易历史
```

**工具**：
- GMGN.ai (免费追踪 10,000+ 钱包)
- Nansen
- Arkham Intelligence
- Etherscan 标记地址

### 2. 监控关键信号

#### 🚨 买入信号
```python
if smart_money_action == "BUY":
    # 检查多个钱包是否同时买入
    if concurrent_wallets >= 3:
        confidence = "HIGH"
        
        # 检查买入金额
        if total_amount > $50k:
            signal = "STRONG_BUY"
            
            # 进入时机
            entry_timing = "立即"
```

#### 📊 观察指标
- **钱包数量**: 3+ 钱包同时行动 = 强信号
- **金额规模**: >$50k = 高置信度
- **时间框架**: 24小时内 = 紧急
- **持有时长**: 通常持有 3-14 天

### 3. 复制交易逻辑

**位置大小**：
```
Smart Money 买入量的 5-10%
最大单笔: 总资本的 2%
总敞口: 不超过 10%
```

**进入策略**：
- 方式 1: 立即跟随（延迟 < 5分钟）
- 方式 2: 等待回调 -3% to -5%
- 方式 3: 分批进入（30% + 30% + 40%）

### 4. 退出策略

#### 止盈
```
Tier 1: +20% → 卖出 30%
Tier 2: +50% → 卖出 30%
Tier 3: +100% → 卖出 30%
保留: 10% 长期持有
```

#### 止损
```
-15% 硬止损
如果 Smart Money 卖出 > 50% → 立即退出
```

## 高级技巧

### A. Smart Money Gauge（综合指标）

**5个关键组成**：

1. **大额交易流**
   - 单笔 >$100k 的交易
   - 过滤交易所和工具类型

2. **深度失衡持续性**
   - 买卖盘失衡持续 90+ 秒 = 重要信号

3. **累积成交量增量**
   - 买卖方向成交量失衡趋势

4. **期货基差和资金费率**
   - Smart Money 同时操作现货和期货

5. **OTC 流动推断**
   - 大额场外交易出现在价格变动前

### B. 延迟处理

**已知延迟**：
- Bitcoin: 平均 47 分钟
- Ethereum: 平均 23 分钟
- BSC/Base: 平均 5-15 分钟

**应对策略**：
```
if chain == "Bitcoin":
    wait_for_confirmation = 2  # 等待2个区块确认
elif chain == "Ethereum":
    wait_for_confirmation = 1
else:
    # BSC/Base 更快
    immediate_entry = True
```

### C. 多链追踪

**优先级**：
```
1. Ethereum - 最大流动性
2. BSC - Meme 币活跃
3. Base - 新兴热点
4. Solana - 高频交易
5. Arbitrum - L2 机会
```

## 实战案例

### 案例 1: PEPE 早期买入

```
2024年4月:
- 3个 Smart Money 钱包同时买入 PEPE
- 总金额: $180k
- 平均成本: $0.000001

跟随策略:
- 买入 $10k (总资本的 2%)
- 成本: $0.0000012 (稍高)

结果:
- 1周后: +150%
- 按梯度止盈，实现 +120% 平均回报
```

### 案例 2: 规避亏损

```
2024年6月:
- 发现某代币 Smart Money 大规模卖出
- 5个钱包 24小时内卖出 70%
- 立即退出持仓，避免随后 -60% 下跌
```

## 风险管理

### 🚨 警告信号

1. **假钱包**: 有人故意制造 Smart Money 假象
   - 检查: 历史记录 >30 天
   - 检查: 多样化交易，非单一代币

2. **洗钱交易**: 某些交易不是为了盈利
   - 忽略: 钱包间频繁转移
   - 关注: 交易所进出

3. **内幕交易风险**: 可能涉及非法信息
   - 合规: 仅公开链上数据
   - 避免: 明显的内幕信号

### 风控规则

```python
# 单笔最大风险
max_risk_per_trade = 0.02  # 2%

# 总敞口限制
max_total_exposure = 0.10  # 10%

# 相关性检查
if correlation_with_existing > 0.7:
    reduce_position_size by 50%

# 止损严格执行
if loss >= -0.15:
    exit_immediately()
```

## 工具推荐

### 免费工具
- ✅ GMGN.ai - 基础追踪
- ✅ Etherscan - 地址监控
- ✅ DexScreener - 实时价格

### 付费工具
- 💎 Nansen ($150/月) - 深度分析
- 💎 Arkham ($25/月) - 标记地址
- 💎 Glassnode ($40/月) - 宏观数据

## 自动化脚本

```python
import requests
import time

class SmartMoneyTracker:
    def __init__(self, wallets):
        self.tracked_wallets = wallets
        self.alert_threshold = 3  # 3个钱包同时行动
    
    def check_concurrent_buys(self):
        """检查同时买入"""
        recent_buys = []
        
        for wallet in self.tracked_wallets:
            txs = get_recent_transactions(wallet, hours=24)
            for tx in txs:
                if tx['type'] == 'BUY' and tx['amount_usd'] > 10000:
                    recent_buys.append({
                        'wallet': wallet,
                        'token': tx['token'],
                        'amount': tx['amount_usd'],
                        'time': tx['timestamp']
                    })
        
        # 查找同一代币的多个买入
        tokens = {}
        for buy in recent_buys:
            token = buy['token']
            if token not in tokens:
                tokens[token] = []
            tokens[token].append(buy)
        
        # 生成信号
        for token, buys in tokens.items():
            if len(buys) >= self.alert_threshold:
                send_alert(f"🚨 {len(buys)} Smart Money 钱包买入 {token}")
                total_amount = sum(b['amount'] for b in buys)
                send_alert(f"💰 总金额: ${total_amount:,.0f}")
```

## 性能指标

### 历史回测 (2024-2026)

```
胜率: 58%
平均盈利: +67%
平均亏损: -12%
盈亏比: 5.6:1
最大回撤: -18%
年化收益: 145%
```

### 最佳应用

- ✅ Meme 币（高波动）
- ✅ 新上线代币
- ✅ DeFi 代币
- ⚠️ 大盘币（信号较弱）

## 注意事项

1. **不是圣杯**: Smart Money 也会亏损
2. **需要快速反应**: 延迟会影响收益
3. **资金要求**: 建议至少 $5k 起步
4. **技术要求**: 需要基本的链上分析能力

---

**策略来源**: 基于 2026 年链上分析最佳实践  
**适用场景**: 中短期交易，7-30 天持有  
**更新频率**: 每月审查和优化  
**风险等级**: 中等
