---
name: Spot Grid Trading (Dollar-Cost Averaging)
description: |
  Automated spot grid strategy for sideways markets. Places buy/sell orders 
  at predefined intervals to profit from volatility. No liquidation risk, 
  suitable for beginners and passive income.
category: Spot Trading
win_rate: 70-80%
risk_level: Low-Medium
best_for: Sideways markets, passive trading
---

# 📊 Spot Grid Trading Strategy

## 概述

自动化网格交易策略，在预定价格区间放置买卖订单，从波动中获利。适合震荡市，无爆仓风险。

## 核心原理

大多数时间市场在震荡，网格策略通过**低买高卖**不断套利：

```
价格波动:
$100 → $105 → $100 → $110 → $105 ...

网格操作:
$100: 买入
$105: 卖出 (+5%)
$100: 再买入
$110: 卖出 (+10%)
$105: 再买入
...

每次完成一个循环 = 盈利
```

## 设置参数

### 1. 选择区间

```python
# 基于历史数据
price_30d_high = 70000
price_30d_low = 65000

# 设置网格区间(留出缓冲)
grid_upper = 69000  # -1% 缓冲
grid_lower = 66000  # +1% 缓冲

# 区间大小
grid_range = grid_upper - grid_lower  # $3000
```

**最佳区间宽度**:
```
BTC/ETH: 10-20%
Altcoins: 20-40%  
过窄 = 频繁交易，手续费高
过宽 = 利润少，资金利用率低
```

### 2. 确定网格数量

```python
# 网格数量 = 交易频率

# 保守 (宽网格)
grid_count = 10
grid_spacing = (69000 - 66000) / 10 = $300/格

# 激进 (密网格)
grid_count = 20  
grid_spacing = (69000 - 66000) / 20 = $150/格

# 推荐
grid_count = 15  # 平衡
```

**网格间距建议**:
```
BTC: $300 - $500  
ETH: $50 - $100
小币: 2-5%
```

### 3. 计算每格投入

```python
total_capital = 10000  # $10k

# 等额分配
per_grid_amount = total_capital / grid_count
# $10000 / 15 = $666.67/格

# 示例网格
grids = [
    {price: 66000, amount: 666, action: "BUY"},
    {price: 66300, amount: 666, action: "SELL"},
    {price: 66600, amount: 666, action: "BUY"},
    {price: 66900, amount: 666, action: "SELL"},
    ...
]
```

## 执行流程

### 初始化

```python
def initialize_grid():
    current_price = 67500
    
    # 1. 先买入基础仓位
    base_position = total_capital * 0.5
    buy_spot(BTC, base_position)
    
    # 2. 设置买单(当前价下方)
    for price in range(66000, 67500, 300):
        place_buy_order(price, 666)
    
    # 3. 设置卖单(当前价上方)  
    for price in range(67800, 69000, 300):
        place_sell_order(price, 666)
```

### 自动执行

```python
def grid_bot_loop():
    while True:
        # 检查成交订单
        filled_orders = check_filled_orders()
        
        for order in filled_orders:
            if order.side == "BUY":
                # 买单成交 → 在上方挂卖单
                sell_price = order.price * 1.01  # +1%
                place_sell_order(sell_price, order.amount)
                
            elif order.side == "SELL":
                # 卖单成交 → 在下方挂买单
                buy_price = order.price * 0.99  # -1%
                place_buy_order(buy_price, order.amount)
        
        time.sleep(60)  # 每分钟检查
```

## 利润来源

### A. 网格利润

```
每个周期利润 = 网格间距利润

示例:
买入 @ $66,000
卖出 @ $66,300
利润 = $300 / $66,000 = 0.45%

如果每天完成2个周期:
日收益 = 0.45% * 2 = 0.9%
月收益 ≈ 27%
```

### B. 持币收益

```
如果 BTC 从 $65k 涨到 $70k:
基础持仓 50% = +7.7% 收益
网格利润 = 额外收益

总收益 = 持币收益 + 网格利润
```

### C. 降低成本

```
通过不断低买高卖:
实际平均成本逐渐降低

示例:
初始成本: $67,000
100次网格后: $65,800 (-1.8%)
= 降低持币成本
```

## 风险管理

### 1. 资金分配

```python
# 不要all-in单个网格
max_per_grid = total_capital * 0.06  # 6%

# 预留现金应对突破
reserve_cash = total_capital * 0.20  # 20%

# 实际网格资金
grid_capital = total_capital * 0.80  # 80%
```

### 2. 区间调整

```python
# 每周检查
if price > grid_upper:
    # 突破上限 → 向上移动网格
    new_lower = grid_upper
    new_upper = grid_upper * 1.10
    
    rebuild_grid(new_lower, new_upper)

if price < grid_lower:
    # 跌破下限 → 向下移动网格
    new_upper = grid_lower
    new_lower = grid_lower * 0.90
    
    rebuild_grid(new_lower, new_upper)
```

### 3. 止损（可选）

```python
# 极端情况止损
if price < grid_lower * 0.85:  # -15%
    close_all_positions()
    stop_grid_bot()
```

## 最佳应用场景

### ✅ 适合

```
✅ 震荡市场 (80%时间)
✅ 高波动币种
✅ 被动收入
✅ 新手友好
✅ 24/7 自动化
```

### ❌ 不适合

```
❌ 强趋势市(单边暴涨/暴跌)
❌ 低波动币
❌ 追求快速致富
❌ 短期投机
```

### 最佳标的

```
🥇 BTC/ETH
- 波动适中
- 流动性好
- 长期看涨

🥈 Top 20 Altcoins  
- 波动大,利润高
- 但风险也高

🥉 稳定币对
- USDT/USDC 网格
- 极低风险
- 年化 3-8%
```

## 进阶策略

### A. 马丁格尔网格

```python
# 越跌买越多
grids = [
    {price: 67000, amount: 100, ratio: 1.0},
    {price: 66000, amount: 150, ratio: 1.5},
    {price: 65000, amount: 225, ratio: 2.25},
]

# 优点: 下跌后快速回本
# 缺点: 需要更多资金
```

### B. 动态网格

```python
# 根据波动率调整间距
volatility = calculate_volatility_30d()

if volatility > 0.05:  # 高波动
    grid_spacing *= 1.2  # 加宽
elif volatility < 0.02:  # 低波动
    grid_spacing *= 0.8  # 缩窄
```

### C. 多币种组合

```python
# 分散到多个币种
allocation = {
    "BTC": 0.40,  # 40%
    "ETH": 0.30,  # 30%
    "BNB": 0.15,  # 15%
    "SOL": 0.15,  # 15%
}

# 降低单币风险
# 提高整体收益稳定性
```

## 实战案例

### 案例 1: BTC 震荡期

```
时间: 2024年4-6月
区间: $65k - $70k
网格: 20个，间距 $250
资金: $20,000

3个月表现:
- 完成周期: 147次
- 网格利润: +$2,940 (+14.7%)
- 持币收益: +$1,200 (+6%)
- 总收益: +$4,140 (+20.7%)
- 手续费: -$294 (-1.5%)
- 净收益: +$3,846 (+19.2%)

年化: 76.8%
```

### 案例 2: 趋势市失败

```
时间: 2024年10月
初始: BTC @ $68k
网格: $65k - $72k

问题:
- BTC 单边上涨到 $85k
- 网格全部卖完
- 踏空主升浪

结果:
- 网格利润: +8%
- 但损失: 踏空 +20% 的涨幅
- 相对损失: -12%

教训:
- 强趋势不适合网格
- 需要预留底仓
```

## 自动化工具

### 交易所原生

```
✅ Binance Grid Bot
✅ Bybit Grid Trading
✅ OKX Grid Strategy

优点:
- 免费
- 集成
- 简单

缺点:
- 灵活性低
- 功能有限
```

### 第三方工具

```
✅ 3Commas ($29/月)
✅ Pionex (内置网格)
✅ Cryptohopper ($19/月)

优点:
- 功能强大
- 多交易所支持
- 高级功能

缺点:
- 需要付费
- API风险
```

### 自建脚本

```python
# 简化版网格bot
class GridBot:
    def __init__(self, symbol, lower, upper, grids):
        self.symbol = symbol
        self.lower = lower
        self.upper = upper
        self.grid_count = grids
        self.grid_spacing = (upper - lower) / grids
    
    def setup(self):
        """初始化网格"""
        current_price = get_current_price(self.symbol)
        
        # 下方买单
        price = self.lower
        while price < current_price:
            place_limit_buy(self.symbol, price, self.per_grid_amount)
            price += self.grid_spacing
        
        # 上方卖单  
        price = current_price + self.grid_spacing
        while price <= self.upper:
            place_limit_sell(self.symbol, price, self.per_grid_amount)
            price += self.grid_spacing
    
    def run(self):
        """主循环"""
        while True:
            filled = get_filled_orders()
            
            for order in filled:
                self.handle_filled_order(order)
            
            time.sleep(60)
```

## 性能指标 (2024-2026)

```
平均年化: 35-60%
胜率: 75%
最大回撤: -8%
夏普比率: 2.8
最佳月份: +12%
最差月份: -2%
手续费占比: 1-2%
```

## 常见问题

**Q: 需要盯盘吗？**
A: 不需要,完全自动化

**Q: 会爆仓吗？**
A: 不会,现货无杠杆无爆仓

**Q: 趋势市怎么办？**
A: 预留底仓,或暂停网格

**Q: 手续费多少？**
A: 约总收益的1-2%

**Q: 最少需要多少钱？**
A: $1000起步,$5000+更好

---

**策略类型**: 自动化/被动  
**风险等级**: 低-中  
**时间投入**: 极少  
**适合**: 所有人  
**最佳市场**: 震荡市  
**核心**: 低买高卖 + 自动化