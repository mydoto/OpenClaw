#!/usr/bin/env python3
"""
Full AI Assistant Telegram Bot
Version: 3.0
Features: Complete AI capabilities + Trading + Analysis
"""

import requests
import time
import json
from datetime import datetime
import sys
import threading

class AITelegramBot:
    def __init__(self, telegram_token, chat_id):
        self.telegram_token = telegram_token
        self.chat_id = chat_id
        self.last_update_id = 0
        
        # Trading state
        self.positions = {
            "SIREN": {
                "entry": 2.52351,
                "stop_loss": 2.75,
                "side": "SHORT",  # SHORT or LONG
                "tiers": [
                    {"target": 2.35, "pct": 30, "done": False},
                    {"target": 2.20, "pct": 30, "done": False},
                    {"target": 2.00, "pct": 30, "done": False},
                    {"target": 1.50, "pct": 10, "done": False},
                ]
            }
        }
        
        # Historical data for trend analysis
        self.price_history = []
        self.sm_history = []
        self.volume_history = []
        
        # Conversation context
        self.context = []
        
    def send_message(self, message, parse_mode="Markdown"):
        """Send message to Telegram"""
        url = f"https://api.telegram.org/bot{self.telegram_token}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": message, "parse_mode": parse_mode}
        
        try:
            response = requests.post(url, json=payload, timeout=5)
            return response.json().get("ok", False)
        except Exception as e:
            print(f"发送失败: {e}")
            return False
    
    def get_updates(self, offset=None):
        """Get new messages"""
        url = f"https://api.telegram.org/bot{self.telegram_token}/getUpdates"
        params = {"offset": offset, "timeout": 30}
        
        try:
            response = requests.get(url, params=params, timeout=35)
            return response.json()
        except:
            return None
    
    # === API 调用函数 ===
    
    def get_binance_price(self, symbol="SIRENUSDT"):
        """获取币安合约价格"""
        try:
            url = f"https://fapi.binance.com/fapi/v1/ticker/24hr?symbol={symbol}"
            r = requests.get(url, timeout=10)
            return r.json()
        except:
            return None
    
    def get_smart_money(self, contract="0x997a58129890bbda032231a52ed1ddc845fc18e1"):
        """获取 Smart Money 数据"""
        try:
            url = "https://web3.binance.com/bapi/defi/v1/public/wallet-direct/tracker/wallet/token/inflow/rank/query/ai"
            data = {"chainId": "56", "period": "24h", "tagType": 2}
            r = requests.post(url, json=data, timeout=10)
            result = r.json()
            
            for token in result.get("data", []):
                if token.get("ca", "").lower() == contract.lower():
                    return token
            return None
        except:
            return None
    
    def search_token(self, keyword, chain=""):
        """搜索代币 - 支持多链"""
        try:
            # Binance Web3 API 支持多链搜索
            url = "https://web3.binance.com/bapi/defi/v4/public/wallet-direct/buw/wallet/market/token/search/ai"
            
            # 支持的链
            chains = {
                "bsc": "56",
                "eth": "1", 
                "ethereum": "1",
                "base": "8453",
                "polygon": "137",
                "matic": "137",
                "arbitrum": "42161",
                "arb": "42161",
                "optimism": "10",
                "op": "10",
                "avalanche": "43114",
                "avax": "43114",
            }
            
            # 如果指定了链，使用对应的chainId
            if chain.lower() in chains:
                chain_id = chains[chain.lower()]
            else:
                # 默认搜索所有支持的链
                chain_id = "56"  # 先从BSC开始
            
            params = {
                "chainId": chain_id,
                "keyword": keyword,
                "page": 1,
                "size": 10
            }
            
            r = requests.get(url, params=params, timeout=10)
            results = r.json().get("data", {}).get("list", [])
            
            # 如果BSC没找到且未指定链，尝试其他链
            if not results and not chain:
                for chain_name, chain_id in [("Ethereum", "1"), ("Base", "8453")]:
                    params["chainId"] = chain_id
                    r = requests.get(url, params=params, timeout=10)
                    results = r.json().get("data", {}).get("list", [])
                    if results:
                        break
            
            return results
        except:
            return []
    
    def analyze_token(self, contract, chain_id="56"):
        """完整分析一个代币 - 支持多链"""
        try:
            # 获取基础信息
            url = f"https://web3.binance.com/bapi/defi/v4/public/wallet-direct/buw/wallet/market/token/meta/info/ai"
            params = {"chainId": chain_id, "contractAddress": contract}
            meta = requests.get(url, params=params, timeout=10).json().get("data", {})
            
            # 获取动态数据
            url2 = f"https://web3.binance.com/bapi/defi/v4/public/wallet-direct/buw/wallet/market/token/dynamic/info/ai"
            dynamic = requests.get(url2, params=params, timeout=10).json().get("data", {})
            
            return {"meta": meta, "dynamic": dynamic, "chain_id": chain_id}
        except:
            return None
    
    def get_spot_price(self, symbol):
        """获取现货价格"""
        try:
            url = f"https://api.binance.com/api/v3/ticker/24hr?symbol={symbol}"
            r = requests.get(url, timeout=10)
            return r.json()
        except:
            return None
    
    def search_trading_pair(self, keyword):
        """搜索交易对（现货+合约）"""
        try:
            results = []
            
            # 1. 搜索现货
            spot_url = "https://api.binance.com/api/v3/exchangeInfo"
            spot_info = requests.get(spot_url, timeout=10).json()
            
            for symbol_info in spot_info.get("symbols", []):
                symbol = symbol_info.get("symbol", "")
                base = symbol_info.get("baseAsset", "")
                quote = symbol_info.get("quoteAsset", "")
                
                if keyword.upper() in symbol or keyword.upper() in base:
                    results.append({
                        "symbol": symbol,
                        "base": base,
                        "quote": quote,
                        "type": "SPOT"
                    })
                    if len(results) >= 5:
                        break
            
            # 2. 搜索合约
            futures_url = "https://fapi.binance.com/fapi/v1/exchangeInfo"
            futures_info = requests.get(futures_url, timeout=10).json()
            
            for symbol_info in futures_info.get("symbols", []):
                symbol = symbol_info.get("symbol", "")
                base = symbol_info.get("baseAsset", "")
                
                if keyword.upper() in symbol or keyword.upper() in base:
                    results.append({
                        "symbol": symbol,
                        "base": base,
                        "type": "FUTURES"
                    })
                    if len(results) >= 10:
                        break
            
            return results
        except:
            return []
    
    # === AI 处理函数 ===
    
    def process_message(self, text):
        """处理用户消息 - 核心 AI 逻辑"""
        
        text_lower = text.lower()
        
        # === 1. 交易策略查询 ===
        if any(word in text_lower for word in ["策略", "strategy", "怎么交易", "如何交易", "推荐"]):
            return self.handle_strategy_query(text)
        
        # === 2. 价格查询 ===
        if any(word in text_lower for word in ["价格", "price", "现价", "多少钱"]):
            return self.handle_price_query(text)
        
        # === 2. 代币分析 ===
        elif any(word in text_lower for word in ["分析", "analyze", "查一下", "看看"]):
            return self.handle_token_analysis(text)
        
        # === 3. Smart Money ===
        elif any(word in text_lower for word in ["smart money", "聪明钱", "资金流", "大户"]):
            return self.handle_smart_money_query(text)
        
        # === 4. 仓位管理 ===
        elif any(word in text_lower for word in ["仓位", "持仓", "position", "我的"]):
            return self.handle_position_query()
        
        # === 5. 交易建议 ===
        elif any(word in text_lower for word in ["建议", "怎么办", "操作", "advice", "应该"]):
            return self.handle_trading_advice()
        
        # === 6. 搜索代币 ===
        elif any(word in text_lower for word in ["搜索", "search", "找", "有没有"]):
            return self.handle_token_search(text)
        
        # === 7. 设置操作 ===
        elif any(word in text_lower for word in ["设置", "修改", "调整", "set"]):
            return self.handle_settings(text)
        
        # === 8. 帮助 ===
        elif any(word in text_lower for word in ["帮助", "help", "功能", "能做什么"]):
            return self.get_help()
        
        # === 9. 通用对话 ===
        else:
            return self.handle_general_chat(text)
    
    def handle_strategy_query(self, text):
        """处理交易策略查询"""
        text_lower = text.lower()
        
        # 策略推荐
        if any(word in text_lower for word in ["推荐策略", "什么策略", "哪个策略", "策略对比"]):
            return "🎯 *Top 5 交易策略*\n\n*新手/稳健*\n📊 Spot Grid (网格)\n💰 Funding Rate (套利)\n\n*中级*\n🧠 Smart Money (跟单)\n🔥 Breakout (突破)\n\n*激进*\n🚀 Meme Trading (短线)\n\n💡 发送 \"Meme策略\" 查看详情"
        
        # Meme币交易
        elif "meme" in text_lower or "土狗" in text_lower:
            return "🚀 *Meme币策略*\n\n*信号*:\n✅ 成交量3x+\n✅ 涨幅5%+\n✅ Twitter热度\n\n*操作*:\n• 持有2-6小时\n• 止损-15%\n• +50%卖一半\n\n⚠️ 高风险！"
        
        # 稳定策略
        elif any(word in text_lower for word in ["稳定", "低风险", "套利"]):
            return "💰 *稳定策略*\n\n1. 资金费率套利\n• 买现货+空合约\n• 年化15-25%\n• 风险极低\n\n2. 网格交易\n• 自动化\n• 年化35-60%\n• 适合震荡市"
        
        else:
            return "📚 *交易策略*\n\n我知道5个策略:\n1. Smart Money\n2. Meme Trading\n3. Funding Arbitrage\n4. Breakout\n5. Grid Trading\n\n发送 \"推荐策略\" 查看"
    
    def handle_price_query(self, text):
        """处理价格查询 - 支持现货和合约"""
        # 尝试从文本提取币种和类型
        text_lower = text.lower()
        symbol = "SIRENUSDT"
        is_futures = True  # 默认合约
        
        # 检测是现货还是合约
        if any(word in text_lower for word in ["现货", "spot"]):
            is_futures = False
        elif any(word in text_lower for word in ["合约", "futures", "永续"]):
            is_futures = True
        
        # 提取币种
        if "btc" in text_lower:
            symbol = "BTCUSDT"
        elif "eth" in text_lower:
            symbol = "ETHUSDT"
        elif "bnb" in text_lower:
            symbol = "BNBUSDT"
        elif "sol" in text_lower:
            symbol = "SOLUSDT"
        
        # 获取价格
        if is_futures:
            data = self.get_binance_price(symbol)
            market_type = "合约"
        else:
            data = self.get_spot_price(symbol)
            market_type = "现货"
        
        if not data:
            return "❌ 无法获取价格数据"
        
        price = float(data.get("lastPrice", 0))
        change = float(data.get("priceChangePercent", 0))
        high = float(data.get("highPrice", 0))
        low = float(data.get("lowPrice", 0))
        volume = float(data.get("volume", 0))
        
        response = f"📊 *{symbol.replace('USDT', '')}/USDT ({market_type})*\n\n"
        response += f"💰 当前价格: `${price:.4f}`\n"
        response += f"📈 24h 涨跌: `{change:+.2f}%`\n"
        response += f"📊 24h 高: `${high:.4f}`\n"
        response += f"📉 24h 低: `${low:.4f}`\n"
        response += f"💹 24h 量: `{volume:,.0f}`\n"
        
        # 如果是 SIREN，加上仓位信息
        if "SIREN" in symbol and "SIREN" in self.positions:
            pos = self.positions["SIREN"]
            entry = pos["entry"]
            pnl = ((entry - price) / entry) * 100
            response += f"\n📍 你的开仓价: `${entry:.4f}`\n"
            response += f"💵 盈亏: `{pnl:+.2f}%`"
        
        return response
    
    def handle_token_analysis(self, text):
        """处理代币分析请求"""
        # 尝试提取合约地址和链
        words = text.split()
        contract = None
        token_name = None
        chain = ""
        
        # 检测链
        chain_keywords = ["eth", "ethereum", "bsc", "base", "polygon", "matic", "arbitrum", "arb", "solana", "sol"]
        for word in words:
            if word.lower() in chain_keywords:
                chain = word.lower()
                break
        
        for word in words:
            if word.startswith("0x") and len(word) == 42:
                contract = word
                break
            elif word not in ["分析", "analyze", "查一下", "看看", "帮我", "代币", chain]:
                token_name = word
        
        # 如果没有合约地址但有代币名称，先搜索
        if not contract and token_name:
            self.send_message(f"🔍 正在搜索 {token_name}...")
            
            # 先尝试搜索交易对（现货/合约）
            trading_pairs = self.search_trading_pair(token_name)
            
            if trading_pairs:
                # 找到交易对，询问要分析现货还是合约
                pair_list = ""
                for i, pair in enumerate(trading_pairs[:5], 1):
                    pair_list += f"{i}. {pair['symbol']} ({pair['type']})\n"
                
                return f"✅ 找到交易对:\n\n{pair_list}\n💡 发送序号或直接说 \"分析 {trading_pairs[0]['symbol']} 现货\" 或 \"分析 {trading_pairs[0]['symbol']} 合约\""
            
            # 如果没找到交易对，搜索链上代币
            results = self.search_token(token_name, chain)
            
            if results:
                # 使用第一个搜索结果
                contract = results[0].get("ca")
                chain_id = results[0].get("chainId", "56")
                name = results[0].get("name", token_name)
                
                chain_names = {
                    "1": "Ethereum",
                    "56": "BSC", 
                    "8453": "Base",
                    "137": "Polygon",
                    "42161": "Arbitrum"
                }
                chain_name = chain_names.get(chain_id, "Unknown")
                
                self.send_message(f"✅ 找到 {name} ({chain_name} 链)，开始分析...")
            else:
                return f"❌ 未找到 '{token_name}'，请提供:\n• 交易对（如: BTCUSDT）\n• 合约地址（0x...）\n• 指定链（如: 分析 PEPE eth）"
        
        if not contract:
            return "❓ 请提供:\n• 代币名称（如：PEPE）\n• 交易对（如：BTCUSDT）\n• 合约地址（0x...）\n\n示例:\n• \"分析 BTC 现货\"\n• \"分析 ETH 合约\"\n• \"分析 PEPE eth链\"\n• \"分析 0x123...abc\""
        
        self.send_message("🔍 正在深度分析，请稍候...")
        
        # 确定chainId
        chain_ids = {
            "eth": "1", "ethereum": "1",
            "bsc": "56",
            "base": "8453",
            "polygon": "137", "matic": "137",
            "arbitrum": "42161", "arb": "42161"
        }
        chain_id = chain_ids.get(chain.lower(), "56")
        
        analysis = self.analyze_token(contract, chain_id)
        if not analysis:
            return "❌ 无法分析该代币"
        
        meta = analysis.get("meta", {})
        dynamic = analysis.get("dynamic", {})
        chain_id = analysis.get("chain_id", "56")
        
        chain_names = {
            "1": "Ethereum",
            "56": "BSC",
            "8453": "Base", 
            "137": "Polygon",
            "42161": "Arbitrum",
            "10": "Optimism",
            "43114": "Avalanche"
        }
        chain_name = chain_names.get(chain_id, f"Chain {chain_id}")
        
        name = meta.get("name", "Unknown")
        symbol = meta.get("symbol", "???")
        price = float(dynamic.get("price", 0))
        mc = float(dynamic.get("marketCap", 0))
        holders = int(dynamic.get("holdersNum", 0))
        
        response = f"📊 *{name} ({symbol})*\n"
        response += f"⛓️ 链: `{chain_name}`\n\n"
        response += f"💰 价格: `${price:.6f}`\n"
        response += f"💎 市值: `${mc:,.0f}`\n"
        response += f"👥 持有人: `{holders:,}`\n"
        response += f"🔗 合约: `{contract[:8]}...{contract[-6:]}`\n"
        
        # Smart Money 数据
        sm = self.get_smart_money(contract)
        if sm:
            inflow = float(sm.get("inflow", 0))
            response += f"\n🧠 Smart Money: `${inflow:,.0f}`\n"
            if inflow < -10000:
                response += "⚠️ 大量流出，谨慎操作"
            elif inflow > 10000:
                response += "📈 大量流入，关注反转"
        
        return response
    
    def handle_smart_money_query(self, text):
        """处理 Smart Money 查询"""
        sm = self.get_smart_money()
        if not sm:
            return "❌ 无法获取 Smart Money 数据"
        
        inflow = float(sm.get("inflow", 0))
        traders = int(sm.get("traders", 0))
        
        response = f"🧠 *Smart Money 状态*\n\n"
        response += f"💵 24h 净流向: `${inflow:,.0f}`\n"
        response += f"👥 活跃交易者: `{traders}`\n\n"
        
        if inflow < -20000:
            response += "🚨 *严重警告*: 大量撤离！"
        elif inflow < -10000:
            response += "⚠️ *警告*: 净流出明显"
        elif inflow < 0:
            response += "📊 净流出，保持观察"
        elif inflow > 10000:
            response += "📈 *关注*: 有大量流入"
        else:
            response += "📊 资金流动平稳"
        
        return response
    
    def handle_position_query(self):
        """查询仓位状态"""
        if "SIREN" not in self.positions:
            return "📊 当前无持仓"
        
        pos = self.positions["SIREN"]
        price_data = self.get_binance_price("SIRENUSDT")
        
        if not price_data:
            return "❌ 无法获取价格"
        
        current_price = float(price_data.get("lastPrice", 0))
        entry = pos["entry"]
        stop = pos["stop_loss"]
        pnl = ((entry - current_price) / entry) * 100
        
        response = f"📊 *SIREN 仓位状态*\n\n"
        response += f"💰 当前价: `${current_price:.4f}`\n"
        response += f"📍 开仓价: `${entry:.4f}`\n"
        response += f"📈 盈亏: `{pnl:+.2f}%`\n"
        response += f"🛡️ 止损: `${stop}`\n\n"
        
        response += "*止盈梯度:*\n"
        for i, tier in enumerate(pos["tiers"], 1):
            status = "✅" if tier["done"] else "⏳"
            target = tier["target"]
            pct = tier["pct"]
            dist = ((current_price - target) / current_price * 100)
            response += f"{status} Tier {i}: `${target}` ({pct}%) - {dist:+.1f}%\n"
        
        return response
    
    def handle_trading_advice(self):
        """提供交易建议"""
        price_data = self.get_binance_price("SIRENUSDT")
        sm_data = self.get_smart_money()
        
        if not price_data:
            return "❌ 无法获取数据"
        
        current_price = float(price_data.get("lastPrice", 0))
        change_24h = float(price_data.get("priceChangePercent", 0))
        
        pos = self.positions.get("SIREN", {})
        entry = pos.get("entry", 0)
        stop = pos.get("stop_loss", 999)
        
        pnl = ((entry - current_price) / entry) * 100 if entry else 0
        
        response = f"💡 *交易建议*\n\n"
        response += f"📊 当前状况:\n"
        response += f"  • 价格: ${current_price:.4f}\n"
        response += f"  • 24h: {change_24h:+.2f}%\n"
        response += f"  • P&L: {pnl:+.2f}%\n\n"
        
        # 判断逻辑
        if current_price >= stop:
            response += "🚨 *立即行动*: 已触及止损，建议立即平仓！"
        elif current_price >= stop * 0.98:
            response += "⚠️ *警告*: 接近止损，准备平仓"
        elif pnl > 5:
            response += "💰 *建议*: 有不错浮盈，可考虑部分止盈锁定利润"
        elif pnl > 0:
            response += "📈 *建议*: 有浮盈，继续持有，注意止损"
        elif pnl > -5:
            response += "📊 *建议*: 小幅浮亏，继续观察，确保止损设置"
        else:
            response += "⚠️ *建议*: 浮亏较大，考虑是否要提前止损"
        
        # Smart Money 因素
        if sm_data:
            inflow = float(sm_data.get("inflow", 0))
            if inflow < -10000:
                response += "\n\n🧠 Smart Money 大量流出，增加谨慎"
            elif inflow > 10000:
                response += "\n\n🧠 Smart Money 流入，可能有反转"
        
        return response
    
    def handle_token_search(self, text):
        """搜索代币"""
        # 提取关键词
        words = text.split()
        keyword = None
        for word in words:
            if word not in ["搜索", "search", "找", "有没有", "查", "看看"]:
                keyword = word
                break
        
        if not keyword:
            return "❓ 请告诉我要搜索什么代币"
        
        self.send_message(f"🔍 正在搜索 '{keyword}'...")
        
        results = self.search_token(keyword)
        if not results:
            return f"❌ 没有找到 '{keyword}'"
        
        response = f"🔍 *搜索结果: {keyword}*\n\n"
        
        for i, token in enumerate(results[:5], 1):
            name = token.get("name", "Unknown")
            symbol = token.get("symbol", "???")
            price = float(token.get("price", 0))
            mc = float(token.get("marketCap", 0))
            
            response += f"{i}. *{name}* ({symbol})\n"
            response += f"   💰 ${price:.6f}\n"
            response += f"   💎 ${mc:,.0f}\n\n"
        
        return response
    
    def handle_settings(self, text):
        """处理设置"""
        return "⚙️ *可设置项*\n\n• 止损价\n• 止盈目标\n• 监控间隔\n\n示例: \"设置止损为 2.80\""
    
    def get_help(self):
        """获取帮助"""
        return """
📚 *AI 助手 - 完整功能*

*💰 价格查询*
• "SIREN 什么价格"
• "BTC 现货"
• "ETH 合约"

*🔍 代币分析*（全链支持！）
• "分析 PEPE"
• "分析 0x123...abc"
• "查一下 DOGE eth链"

*🔎 搜索代币*
• "搜索 PEPE"
• "找 meme 币"

*🧠 Smart Money*
• "Smart Money 怎么样"
• "聪明钱在干嘛"

*📊 仓位管理*
• "我的仓位"
• "持仓状态"

*💡 交易建议*
• "给个建议"
• "现在怎么办"

*🎯 交易策略*（新增！）
• "推荐策略"
• "什么是Smart Money策略"
• "Meme币怎么交易"
• "稳定收益策略"
• "网格交易怎么做"

*💬 自然对话*
直接说你想做什么，我会理解！
"""
    
    def handle_general_chat(self, text):
        """处理通用对话"""
        text_lower = text.lower()
        
        if any(word in text_lower for word in ["你好", "hi", "hello", "嗨"]):
            return "👋 你好！我是你的 AI 交易助手。有什么可以帮你？"
        
        elif any(word in text_lower for word in ["谢谢", "thank", "感谢"]):
            return "😊 不客气！有问题随时找我"
        
        elif any(word in text_lower for word in ["可以", "能不能", "会不会"]):
            return "💪 我可以帮你:\n• 查询价格和数据\n• 分析代币\n• 追踪 Smart Money\n• 提供交易建议\n\n直接告诉我你要做什么！"
        
        else:
            return f"💬 收到: \"{text}\"\n\n我可以帮你查询价格、分析代币、追踪 Smart Money、管理仓位等。\n\n发送 \"帮助\" 查看所有功能。"
    
    # === 智能策略分析 ===
    
    def analyze_market_trend(self, price, sm_data, volume):
        """分析市场趋势，给出策略建议"""
        
        # 记录历史数据
        self.price_history.append(price)
        if len(self.price_history) > 12:  # 保留最近12次（1小时）
            self.price_history.pop(0)
        
        if sm_data:
            sm_inflow = float(sm_data.get("inflow", 0))
            self.sm_history.append(sm_inflow)
            if len(self.sm_history) > 12:
                self.sm_history.pop(0)
        
        self.volume_history.append(volume)
        if len(self.volume_history) > 12:
            self.volume_history.pop(0)
        
        # 需要至少3次数据才能分析趋势
        if len(self.price_history) < 3:
            return None
        
        # === 趋势分析 ===
        
        # 1. 价格趋势
        price_change_15m = ((price - self.price_history[-3]) / self.price_history[-3] * 100) if len(self.price_history) >= 3 else 0
        price_change_30m = ((price - self.price_history[-6]) / self.price_history[-6] * 100) if len(self.price_history) >= 6 else 0
        price_change_1h = ((price - self.price_history[0]) / self.price_history[0] * 100) if len(self.price_history) >= 12 else 0
        
        # 2. Smart Money 趋势
        sm_trend = None
        if len(self.sm_history) >= 3:
            recent_sm = sum(self.sm_history[-3:]) / 3
            if recent_sm > 5000:
                sm_trend = "BULLISH"  # 流入
            elif recent_sm < -5000:
                sm_trend = "BEARISH"  # 流出
            else:
                sm_trend = "NEUTRAL"
        
        # 3. 成交量趋势
        volume_trend = None
        if len(self.volume_history) >= 2:
            volume_change = ((volume - self.volume_history[-2]) / self.volume_history[-2] * 100)
            if volume_change > 50:
                volume_trend = "SURGE"  # 暴增
            elif volume_change > 20:
                volume_trend = "UP"  # 上升
            elif volume_change < -20:
                volume_trend = "DOWN"  # 下降
            else:
                volume_trend = "STABLE"
        
        # === 信号判断 ===
        
        signals = {
            "price_trend": None,
            "sm_signal": None,
            "volume_signal": None,
            "reversal_score": 0,  # 反转分数（正数=看涨，负数=看跌）
            "action": None,
            "reason": []
        }
        
        # 价格信号
        if price_change_15m > 3:
            signals["price_trend"] = "STRONG_UP"
            signals["reversal_score"] += 2
            signals["reason"].append("15分钟强势上涨 +{:.1f}%".format(price_change_15m))
        elif price_change_15m > 1:
            signals["price_trend"] = "UP"
            signals["reversal_score"] += 1
            signals["reason"].append("15分钟上涨 +{:.1f}%".format(price_change_15m))
        elif price_change_15m < -3:
            signals["price_trend"] = "STRONG_DOWN"
            signals["reversal_score"] -= 2
            signals["reason"].append("15分钟大幅下跌 {:.1f}%".format(price_change_15m))
        elif price_change_15m < -1:
            signals["price_trend"] = "DOWN"
            signals["reversal_score"] -= 1
            signals["reason"].append("15分钟下跌 {:.1f}%".format(price_change_15m))
        
        # Smart Money 信号
        if sm_trend == "BULLISH":
            signals["sm_signal"] = "INFLOW"
            signals["reversal_score"] += 3  # Smart Money 权重大
            signals["reason"].append("Smart Money 大量流入")
        elif sm_trend == "BEARISH":
            signals["sm_signal"] = "OUTFLOW"
            signals["reversal_score"] -= 3
            signals["reason"].append("Smart Money 持续流出")
        
        # 成交量信号
        if volume_trend == "SURGE":
            signals["volume_signal"] = "SURGE"
            if price_change_15m > 0:
                signals["reversal_score"] += 2
                signals["reason"].append("成交量暴增 + 上涨 = 突破信号")
            else:
                signals["reversal_score"] -= 1
                signals["reason"].append("成交量暴增但价格下跌")
        
        # === 策略建议 ===
        
        pos = self.positions.get("SIREN", {})
        current_side = pos.get("side", "SHORT")
        
        # 反转信号判断
        if signals["reversal_score"] >= 4:
            if current_side == "SHORT":
                signals["action"] = "CLOSE_AND_REVERSE"
                signals["reason"].insert(0, "⚠️ 强烈反转信号！建议平空反手做多")
            else:
                signals["action"] = "ADD_LONG"
                signals["reason"].insert(0, "📈 趋势确认，可加仓做多")
        
        elif signals["reversal_score"] >= 2:
            if current_side == "SHORT":
                signals["action"] = "CONSIDER_CLOSE"
                signals["reason"].insert(0, "⚠️ 反转迹象，考虑平仓观望")
            else:
                signals["action"] = "HOLD_LONG"
                signals["reason"].insert(0, "📊 做多趋势良好，继续持有")
        
        elif signals["reversal_score"] <= -4:
            if current_side == "LONG":
                signals["action"] = "CLOSE_AND_SHORT"
                signals["reason"].insert(0, "⚠️ 下跌信号强烈！建议平多反手做空")
            else:
                signals["action"] = "HOLD_SHORT"
                signals["reason"].insert(0, "📉 空头趋势确认，继续持有")
        
        elif signals["reversal_score"] <= -2:
            if current_side == "LONG":
                signals["action"] = "CONSIDER_CLOSE"
                signals["reason"].insert(0, "⚠️ 下跌信号，考虑平仓")
            else:
                signals["action"] = "HOLD_SHORT"
                signals["reason"].insert(0, "📊 做空趋势良好，继续持有")
        
        else:
            signals["action"] = "HOLD"
            signals["reason"].insert(0, "📊 趋势不明确，维持当前仓位")
        
        return signals
    
    # === 监控线程 ===
    
    def monitoring_loop(self):
        """监控循环"""
        print("🔄 监控线程启动")
        
        iteration = 0
        last_hourly_report = time.time()
        
        while True:
            try:
                iteration += 1
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                print(f"[{timestamp}] 监控检查 #{iteration}")
                
                # 检查 SIREN 仓位
                if "SIREN" in self.positions:
                    price_data = self.get_binance_price("SIRENUSDT")
                    sm_data = self.get_smart_money()
                    
                    if price_data:
                        price = float(price_data.get("lastPrice", 0))
                        change_24h = float(price_data.get("priceChangePercent", 0))
                        volume = float(price_data.get("volume", 0))
                        pos = self.positions["SIREN"]
                        entry = pos["entry"]
                        stop = pos["stop_loss"]
                        pnl = ((entry - price) / entry) * 100
                        
                        print(f"  价格: ${price:.4f} | P&L: {pnl:+.2f}%")
                        
                        # === 智能策略分析 ===
                        signals = self.analyze_market_trend(price, sm_data, volume)
                        
                        # 标记：是否需要发送通知
                        should_notify = False
                        notifications = []
                        
                        # === 1. 严重预警：止损 ===
                        if price >= stop:
                            should_notify = True
                            notifications.append({
                                "type": "CRITICAL",
                                "message": (
                                    f"🚨 *STOP LOSS HIT!*\n\n"
                                    f"价格: `${price:.4f}`\n"
                                    f"止损: `${stop}`\n\n"
                                    f"⚠️ *立即平仓！*"
                                )
                            })
                        
                        # === 2. 警告：接近止损 ===
                        elif price >= stop * 0.98:
                            should_notify = True
                            dist = ((stop - price) / price * 100)
                            notifications.append({
                                "type": "HIGH",
                                "message": (
                                    f"⚠️ *接近止损！*\n\n"
                                    f"当前: `${price:.4f}`\n"
                                    f"止损: `${stop}`\n"
                                    f"距离: `{dist:.2f}%`\n\n"
                                    f"准备平仓！"
                                )
                            })
                        
                        # === 3. 止盈检查 ===
                        for i, tier in enumerate(pos["tiers"], 1):
                            if not tier["done"] and price <= tier["target"]:
                                should_notify = True
                                notifications.append({
                                    "type": "CRITICAL",
                                    "message": (
                                        f"🎯 *Tier {i} 触发!*\n\n"
                                        f"价格: `${price:.4f}`\n"
                                        f"目标: `${tier['target']}`\n"
                                        f"盈利: `{pnl:+.2f}%`\n\n"
                                        f"✅ 建议平仓 *{tier['pct']}%*"
                                    )
                                })
                                tier["done"] = True
                        
                        # === 4. Smart Money 大幅异动 ===
                        if sm_data and len(self.sm_history) >= 2:
                            sm_inflow = float(sm_data.get("inflow", 0))
                            prev_sm = self.sm_history[-2] if len(self.sm_history) >= 2 else 0
                            sm_change = sm_inflow - prev_sm
                            
                            if abs(sm_change) > 15000:  # 单次变化超过$15k
                                should_notify = True
                                direction = "流入" if sm_change > 0 else "流出"
                                emoji = "📈" if sm_change > 0 else "📉"
                                notifications.append({
                                    "type": "HIGH",
                                    "message": (
                                        f"{emoji} *Smart Money 异动！*\n\n"
                                        f"变化: `${sm_change:+,.0f}`\n"
                                        f"当前: `${sm_inflow:,.0f}`\n"
                                        f"方向: {direction}\n\n"
                                        f"⚠️ 大资金{'进入' if sm_change > 0 else '撤离'}！"
                                    )
                                })
                        
                        # === 5. 剧烈价格波动 ===
                        if len(self.price_history) >= 2:
                            prev_price = self.price_history[-2]
                            price_change_5m = ((price - prev_price) / prev_price * 100)
                            
                            if abs(price_change_5m) > 5:  # 5分钟变化>5%
                                should_notify = True
                                direction = "上涨" if price_change_5m > 0 else "下跌"
                                emoji = "🚀" if price_change_5m > 0 else "💥"
                                notifications.append({
                                    "type": "HIGH",
                                    "message": (
                                        f"{emoji} *剧烈波动！*\n\n"
                                        f"5分钟{direction}: `{price_change_5m:+.2f}%`\n"
                                        f"当前价: `${price:.4f}`\n\n"
                                        f"⚠️ 高度波动，注意风险！"
                                    )
                                })
                        
                        # === 6. 强烈策略信号 ===
                        if signals and signals.get("action") in ["CLOSE_AND_REVERSE", "CLOSE_AND_SHORT", "ADD_LONG"]:
                            should_notify = True
                            score = signals["reversal_score"]
                            reasons = signals["reason"]
                            action = signals["action"]
                            
                            alert = f"🤖 *AI 策略提醒！*\n\n"
                            alert += f"信号强度: `{score:+d}`\n\n"
                            
                            if action == "CLOSE_AND_REVERSE":
                                alert += f"🚨 *强烈反转信号*\n\n"
                                alert += f"建议:\n"
                                alert += f"1. 平掉当前空单\n"
                                alert += f"2. 反手开多单\n\n"
                            elif action == "CLOSE_AND_SHORT":
                                alert += f"🚨 *强烈下跌信号*\n\n"
                                alert += f"建议:\n"
                                alert += f"1. 平掉当前多单\n"
                                alert += f"2. 反手开空单\n\n"
                            elif action == "ADD_LONG":
                                alert += f"📈 *做多机会*\n\n"
                                alert += f"建议: 考虑加仓做多\n\n"
                            
                            alert += f"主要原因:\n"
                            for reason in reasons[:3]:
                                alert += f"• {reason}\n"
                            
                            notifications.append({
                                "type": "STRATEGY",
                                "message": alert
                            })
                        
                        # === 发送所有通知 ===
                        if should_notify:
                            for notif in notifications:
                                self.send_message(notif["message"])
                                print(f"  ⚠️ 已发送 {notif['type']} 通知")
                                time.sleep(1)  # 避免消息太快
                        else:
                            print(f"  ✓ 无重要事件")
                        
                        # === 每小时汇总（可选） ===
                        current_time = time.time()
                        if current_time - last_hourly_report >= 3600:  # 1小时
                            summary = self._build_hourly_summary(price, pnl, sm_data, pos, signals)
                            self.send_message(summary)
                            print(f"  📊 已发送每小时汇总")
                            last_hourly_report = current_time
                
                # 等待5分钟
                time.sleep(300)
                
            except Exception as e:
                print(f"监控错误: {e}")
                time.sleep(60)
    
    def _build_hourly_summary(self, price, pnl, sm_data, pos, signals):
        """构建每小时汇总"""
        summary = f"📊 *每小时汇总*\n\n"
        summary += f"⏰ {datetime.now().strftime('%H:%M')}\n"
        summary += f"💰 价格: `${price:.4f}`\n"
        summary += f"📍 开仓: `${pos['entry']:.4f}`\n"
        summary += f"💵 盈亏: `{pnl:+.2f}%`\n"
        summary += f"🛡️ 止损: `${pos['stop_loss']}`\n"
        
        if sm_data:
            inflow = float(sm_data.get("inflow", 0))
            traders = int(sm_data.get("traders", 0))
            summary += f"\n🧠 Smart Money: `${inflow:,.0f}`\n"
            summary += f"👥 SM 交易者: `{traders}`\n"
        
        summary += f"\n*止盈进度:*\n"
        for i, tier in enumerate(pos["tiers"], 1):
            status = "✅" if tier["done"] else "⏳"
            summary += f"{status} T{i}: `${tier['target']}` ({tier['pct']}%)\n"
        
        if signals and signals.get("action"):
            score = signals["reversal_score"]
            summary += f"\n🤖 AI 信号: `{score:+d}` - {signals['action']}"
        
        return summary
    
    # === 主循环 ===
    
    def run(self):
        """运行机器人"""
        print("\n" + "="*60)
        print("🤖 AI Telegram Bot 启动")
        print("="*60)
        print(f"📱 Chat ID: {self.chat_id}")
        print("="*60 + "\n")
        
        # 启动监控线程
        monitor_thread = threading.Thread(target=self.monitoring_loop, daemon=True)
        monitor_thread.start()
        
        # 发送启动消息
        self.send_message("🤖 AI 助手已启动！\n\n我可以帮你查询、分析、建议等任何事情。\n\n直接告诉我你要做什么！")
        
        # 主循环
        offset = None
        print("💬 等待消息...\n")
        
        while True:
            try:
                updates = self.get_updates(offset)
                
                if not updates or not updates.get("ok"):
                    continue
                
                for update in updates.get("result", []):
                    update_id = update.get("update_id")
                    if update_id:
                        offset = update_id + 1
                    
                    message = update.get("message", {})
                    chat_id = str(message.get("chat", {}).get("id", ""))
                    text = message.get("text", "")
                    
                    if chat_id != str(self.chat_id) or not text:
                        continue
                    
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] 收到: {text}")
                    
                    # 处理消息
                    response = self.process_message(text)
                    
                    if response:
                        self.send_message(response)
                        print(f"[{datetime.now().strftime('%H:%M:%S')}] 已回复\n")
                
            except KeyboardInterrupt:
                print("\n⏹️ 停止")
                break
            except Exception as e:
                print(f"错误: {e}")
                time.sleep(5)

def main():
    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--token', required=True)
    parser.add_argument('--chat-id', required=True)
    
    args = parser.parse_args()
    
    bot = AITelegramBot(args.token, args.chat_id)
    bot.run()

if __name__ == "__main__":
    main()
