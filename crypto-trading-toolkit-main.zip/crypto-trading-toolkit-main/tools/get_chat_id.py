#!/usr/bin/env python3
"""
Get Telegram Chat ID Helper
Quick script to retrieve your Telegram Chat ID
"""

import requests
import sys

def get_chat_id(bot_token):
    """Fetch updates and extract chat ID"""
    print("🔍 Fetching updates from Telegram...")
    print("=" * 60)
    
    url = f"https://api.telegram.org/bot{bot_token}/getUpdates"
    
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        if not data.get("ok"):
            print("❌ Error: API request failed")
            print(f"Response: {data}")
            return None
        
        results = data.get("result", [])
        
        if not results:
            print("⚠️ No messages found!")
            print("\n📝 Please follow these steps:")
            print("  1. Open Telegram")
            print("  2. Search for your bot: @JasonTread_bot")
            print("  3. Send any message to the bot (e.g., 'hello')")
            print("  4. Run this script again")
            return None
        
        # Extract all unique chat IDs
        chat_ids = set()
        for result in results:
            if "message" in result:
                msg = result["message"]
                if "chat" in msg and "id" in msg["chat"]:
                    chat_id = msg["chat"]["id"]
                    chat_ids.add(chat_id)
                    
                    # Print details
                    print(f"\n✅ Found Chat ID: {chat_id}")
                    print(f"   From: {msg['chat'].get('first_name', 'Unknown')}")
                    if "username" in msg["chat"]:
                        print(f"   Username: @{msg['chat']['username']}")
                    print(f"   Message: {msg.get('text', '(no text)')}")
        
        if not chat_ids:
            print("⚠️ No chat IDs found in messages")
            return None
        
        # Return the first (or only) chat ID
        primary_chat_id = list(chat_ids)[0]
        
        print("\n" + "=" * 60)
        print(f"🎯 Your Chat ID: {primary_chat_id}")
        print("=" * 60)
        
        return primary_chat_id
        
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error: {e}")
        return None
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return None

def test_send_message(bot_token, chat_id):
    """Send a test message to verify setup"""
    print(f"\n📤 Sending test message to Chat ID: {chat_id}...")
    
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": "🎉 Success! Your SIREN monitor is ready!\n\nYou will receive alerts here.",
        "parse_mode": "Markdown"
    }
    
    try:
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        
        if response.json().get("ok"):
            print("✅ Test message sent successfully!")
            print("   Check your Telegram to confirm.")
            return True
        else:
            print(f"⚠️ Message send failed: {response.json()}")
            return False
            
    except Exception as e:
        print(f"❌ Failed to send test message: {e}")
        return False

def main():
    print("\n" + "=" * 60)
    print("📱 Telegram Chat ID Helper")
    print("=" * 60 + "\n")
    
    # Your bot token
    bot_token = "8200719161:AAEk04eOrn4WfcY75_gEYaYJHEynGmUV030"
    
    # Get chat ID
    chat_id = get_chat_id(bot_token)
    
    if not chat_id:
        print("\n❌ Could not retrieve Chat ID. Please try again after messaging your bot.")
        sys.exit(1)
    
    # Send test message
    test_send_message(bot_token, chat_id)
    
    # Generate command to start monitoring
    print("\n" + "=" * 60)
    print("🚀 Ready to Start Monitoring!")
    print("=" * 60)
    print("\nRun this command to start:\n")
    print(f"python3 siren_monitor.py \\")
    print(f"  --telegram-token \"{bot_token}\" \\")
    print(f"  --chat-id \"{chat_id}\"")
    print("\nOr use the quick start script:\n")
    print("./start_monitor.sh")
    print("  (Then choose option 1 and enter the token and chat ID)\n")

if __name__ == "__main__":
    main()
