#!/usr/bin/env python3
"""
智能交易助手 - 真正的AI对话
支持自然语言对话、市场分析、策略推荐
"""

import requests
import time
import json
import os
from datetime import datetime
import threading

class IntelligentTradingBot:
    def __init__(self, telegram_token, chat_id, openai_api_key=None):
        self.telegram_token = telegram_token
        self.chat_id = chat_id
        self.openai_api_key = openai_api_key or os.getenv("OPENAI_API_KEY")
        self.last_update_id = 0
        
        # 对话历史
        self.conversation_history = []
        
        # 系统提示词
        self.system_prompt = """你是一个专业的加密货币交易AI助手，具备以下能力：

1. **市场分析**：能够获取和分析实时市场数据（价格、资金费率、订单簿等）
2. **策略推荐**：掌握5大交易策略（Meme动量、突破回测、资金费率套利、网格交易、Smart Money跟随）
3. **风险管理**：提供具体的入场点、止损位、止盈位建议
4. **自然对话**：像专业交易员一样与用户交流

关键原则：
- 先获取数据再分析，不要猜测
- 提供具体数字，不说模糊建议
- 必须包含风险提示
- 用Markdown格式，关键数字用代码块
- 简洁直接，不说废话

可用工具：
- get_price(symbol): 获取实时价格
- get_market_data(symbol): 获取完整市场数据
- get_funding_rate(symbol): 获取资金费率
- get_order_book(symbol): 获取订单簿深度
"""
        
        # 持仓信息（如果需要）
        self.positions = {}
    
    def send_message(self, message, parse_mode="Markdown"):
        """发送Telegram消息"""
        url = f"https://api.telegram.org/bot{self.telegram_token}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": message, "parse_mode": parse_mode}
        
        try:
            response = requests.post(url, json=payload, timeout=5)
            return response.json().get("ok", False)
        except Exception as e:
            print(f"[错误] 发送消息失败: {e}")
            return False
    
    def get_updates(self, offset=None):
        """获取Telegram更新"""
        url = f"https://api.telegram.org/bot{self.telegram_token}/getUpdates"
        params = {"timeout": 30}
        if offset:
            params["offset"] = offset
        
        try:
            response = requests.get(url, params=params, timeout=35)
            return response.json().get("result", [])
        except Exception as e:
            print(f"[错误] 获取更新失败: {e}")
            return []
    
    def get_market_data(self, symbol):
        """获取市场数据（工具函数）"""
        try:
            # 合约数据
            url = f"https://fapi.binance.com/fapi/v1/ticker/24hr?symbol={symbol}"
            response = requests.get(url, timeout=3)
            futures = response.json()
            
            # 资金费率
            url_fr = f"https://fapi.binance.com/fapi/v1/fundingRate?symbol={symbol}&limit=1"
            fr_response = requests.get(url_fr, timeout=3)
            fr_data = fr_response.json()
            
            return {
                "price": float(futures.get("lastPrice", 0)),
                "change_24h": float(futures.get("priceChangePercent", 0)),
                "high_24h": float(futures.get("highPrice", 0)),
                "low_24h": float(futures.get("lowPrice", 0)),
                "volume_24h": float(futures.get("volume", 0)),
                "funding_rate": float(fr_data[0]["fundingRate"]) if fr_data else None
            }
        except Exception as e:
            print(f"[错误] 获取市场数据失败: {e}")
            return None
    
    def call_openai(self, user_message):
        """调用OpenAI API进行对话"""
        if not self.openai_api_key:
            return self._fallback_intelligent_response(user_message)
        
        try:
            # 构建消息历史
            messages = [{"role": "system", "content": self.system_prompt}]
            
            # 添加对话历史（最近5轮）
            for item in self.conversation_history[-10:]:
                messages.append({
                    "role": item["role"],
                    "content": item["content"]
                })
            
            # 添加当前消息
            messages.append({"role": "user", "content": user_message})
            
            # 调用OpenAI API
            url = "https://api.openai.com/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {self.openai_api_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": "gpt-4",  # 或 "gpt-3.5-turbo"
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 1000
            }
            
            response = requests.post(url, headers=headers, json=payload, timeout=30)
            data = response.json()
            
            if "choices" in data and len(data["choices"]) > 0:
                return data["choices"][0]["message"]["content"]
            else:
                print(f"[警告] OpenAI响应异常: {data}")
                return self._fallback_intelligent_response(user_message)
                
        except Exception as e:
            print(f"[错误] OpenAI调用失败: {e}")
            return self._fallback_intelligent_response(user_message)
    
    def _fallback_intelligent_response(self, user_message):
        """
        智能fallback（不依赖OpenAI）
        基于规则但比v2.0更智能
        """
        text_lower = user_message.lower()
        
        # 提取币种
        symbol = self._extract_symbol(user_message)
        
        # === 场景1: 价格/行情查询 ===
        if any(word in text_lower for word in ["价格", "行情", "price", "多少", "看一下", "看看", "查看"]):
            return self._handle_market_query(symbol, user_message)
        
        # === 场景2: 交易建议 ===
        elif any(word in text_lower for word in ["能", "可以", "做多", "做空", "买", "卖", "市价", "适合"]):
            return self._handle_trading_advice(symbol, user_message)
        
        # === 场景3: 策略咨询 ===
        elif any(word in text_lower for word in ["策略", "推荐", "建议", "怎么交易", "如何"]):
            return self._handle_strategy_query(user_message)
        
        # === 场景4: 持仓分析 ===
        elif any(word in text_lower for word in ["持仓", "仓位", "回本", "盈亏", "我的单"]):
            return self._handle_position_analysis(user_message)
        
        # === 场景5: 深度分析 ===
        elif any(word in text_lower for word in ["分析", "analyze", "研究", "评估"]):
            return self._handle_deep_analysis(symbol, user_message)
        
        # === 场景6: 通用对话 ===
        else:
            return self._handle_general_conversation(user_message)
    
    def _extract_symbol(self, text):
        """从文本提取币种"""
        text_lower = text.lower()
        
        symbols = {
            "btc": "BTCUSDT",
            "eth": "ETHUSDT",
            "bnb": "BNBUSDT",
            "sol": "SOLUSDT",
            "siren": "SIRENUSDT",
            "doge": "DOGEUSDT",
            "shib": "SHIBUSDT",
        }
        
        for key, value in symbols.items():
            if key in text_lower:
                return value
        
        return "ETHUSDT"  # 默认
    
    def _handle_market_query(self, symbol, user_message):
        """处理市场查询"""
        data = self.get_market_data(symbol)
        
        if not data:
            return "❌ 无法获取市场数据，请稍后重试"
        
        coin = symbol.replace("USDT", "")
        price = data["price"]
        change = data["change_24h"]
        high = data["high_24h"]
        low = data["low_24h"]
        fr = data["funding_rate"]
        
        # 趋势判断
        if change > 3:
            trend = "📈 *强势上涨*"
            sentiment = "看多情绪浓厚"
        elif change < -3:
            trend = "📉 *快速下跌*"
            sentiment = "看空情绪明显"
        else:
            trend = "📊 *横盘震荡*"
            sentiment = "市场观望"
        
        response = f"*{coin} 实时行情*\n\n"
        response += f"💰 当前价格: `${price:,.2f}`\n"
        response += f"📊 24h涨跌: `{change:+.2f}%` {trend}\n"
        response += f"📈 24h最高: `${high:,.2f}`\n"
        response += f"📉 24h最低: `${low:,.2f}`\n"
        
        if fr is not None:
            fr_pct = fr * 100
            response += f"\n💹 资金费率: `{fr_pct:.4f}%`\n"
            if fr_pct > 0.01:
                response += "   • 多头付费给空头\n"
                response += "   • " + sentiment + "（偏多）\n"
            elif fr_pct < -0.01:
                response += "   • 空头付费给多头\n"
                response += "   • " + sentiment + "（偏空）\n"
            else:
                response += "   • 市场中性\n"
        
        return response
    
    def _handle_trading_advice(self, symbol, user_message):
        """处理交易建议请求"""
        data = self.get_market_data(symbol)
        
        if not data:
            return "❌ 无法获取市场数据"
        
        coin = symbol.replace("USDT", "")
        price = data["price"]
        change = data["change_24h"]
        fr = data["funding_rate"]
        
        response = f"*{coin} 交易建议*\n\n"
        response += f"💰 当前价格: `${price:,.2f}` ({change:+.2f}%)\n\n"
        
        # 判断逻辑
        if "做多" in user_message or "买入" in user_message or "long" in user_message.lower():
            if change > 5:
                response += "⚠️ *不建议立即做多*\n\n"
                response += f"*原因：*\n"
                response += f"• 短期涨幅{change:.1f}%，已超涨\n"
                response += f"• 容易回调\n\n"
                response += f"*建议：*\n"
                response += f"1️⃣ 等待回调到 `${price * 0.97:.2f}` 再考虑\n"
                response += f"2️⃣ 或等待突破 `${price * 1.02:.2f}` 再追涨\n"
                response += f"3️⃣ 止损设在 `${price * 0.95:.2f}`\n"
            elif change < -3:
                response += "✅ *可以考虑轻仓做多*\n\n"
                response += f"*原因：*\n"
                response += f"• 短期下跌{change:.1f}%，可能反弹\n"
                response += f"• 风险收益比合适\n\n"
                response += f"*建议：*\n"
                response += f"1️⃣ 入场: `${price:.2f}` 附近\n"
                response += f"2️⃣ 止损: `${price * 0.97:.2f}` (-3%)\n"
                response += f"3️⃣ 止盈: `${price * 1.05:.2f}` (+5%)\n"
                response += f"4️⃣ 仓位: 总资金的10-20%\n"
                response += f"5️⃣ 杠杆: 2-3x\n"
            else:
                response += "⏳ *建议观望*\n\n"
                response += f"*原因：*\n"
                response += f"• 市场方向不明确\n"
                response += f"• 等待更好的入场点\n\n"
                response += f"*关键位：*\n"
                response += f"• 突破 `${price * 1.02:.2f}` 做多\n"
                response += f"• 跌破 `${price * 0.98:.2f}` 观望\n"
        
        elif "做空" in user_message or "卖出" in user_message or "short" in user_message.lower():
            if change < -5:
                response += "⚠️ *不建议追空*\n\n"
                response += f"*原因：*\n"
                response += f"• 短期跌幅{change:.1f}%，已超跌\n"
                response += f"• 可能出现技术性反弹\n\n"
                response += f"*建议：*\n"
                response += f"等待反弹到 `${price * 1.03:.2f}` 再做空\n"
            elif change > 3:
                response += "✅ *可以考虑做空*\n\n"
                response += f"*原因：*\n"
                response += f"• 短期涨幅{change:.1f}%，回调风险增加\n\n"
                response += f"*建议：*\n"
                response += f"1️⃣ 入场: `${price:.2f}`\n"
                response += f"2️⃣ 止损: `${price * 1.03:.2f}` (+3%)\n"
                response += f"3️⃣ 止盈: `${price * 0.95:.2f}` (-5%)\n"
                response += f"4️⃣ 仓位: 10-15%\n"
            else:
                response += "⏳ *等待明确信号*\n"
        
        else:
            # 综合建议
            if change > 3:
                response += "⚠️ *短期超涨，建议观望或轻仓做空*\n"
            elif change < -3:
                response += "✅ *短期超跌，可以考虑轻仓做多*\n"
            else:
                response += "⏳ *盘整中，等待突破*\n"
        
        response += "\n⚠️ **风险提示**\n"
        response += "• 严格止损，保护本金\n"
        response += "• 小仓位试探，不要梭哈\n"
        response += "• 市场瞬息万变，随时调整\n"
        
        return response
    
    def _handle_strategy_query(self, user_message):
        """处理策略查询"""
        response = "*🎯 交易策略推荐*\n\n"
        
        response += "*根据风险偏好选择：*\n\n"
        
        response += "*🟢 低风险（新手适合）*\n"
        response += "📊 网格交易 + 💰 资金费率套利\n"
        response += "• 年化收益: 10-30%\n"
        response += "• 风险: 低\n"
        response += "• 杠杆: 1-2x\n\n"
        
        response += "*🟡 中风险（进阶玩家）*\n"
        response += "🔥 突破回测 + 🧠 Smart Money跟随\n"
        response += "• 单次收益: 3-20%\n"
        response += "• 风险: 中\n"
        response += "• 杠杆: 3-5x\n\n"
        
        response += "*🔴 高风险（专业交易员）*\n"
        response += "🚀 Meme动量交易\n"
        response += "• 单次收益: 10-100%+\n"
        response += "• 风险: 极高\n"
        response += "• 杠杆: 5-10x\n\n"
        
        response += "回复策略名称（如\"网格交易\"）获取详细说明"
        
        return response
    
    def _handle_position_analysis(self, user_message):
        """处理持仓分析"""
        # 这里可以根据实际情况添加持仓解析逻辑
        response = "*📊 持仓分析*\n\n"
        response += "要查看持仓分析，请告诉我：\n"
        response += "• 币种（如ETH、BTC）\n"
        response += "• 开仓价格\n"
        response += "• 方向（做多/做空）\n\n"
        response += "例如：\"SIREN空单，开仓2.62\""
        
        return response
    
    def _handle_deep_analysis(self, symbol, user_message):
        """处理深度分析"""
        data = self.get_market_data(symbol)
        
        if not data:
            return "❌ 无法获取数据"
        
        coin = symbol.replace("USDT", "")
        
        response = f"*🔍 {coin} 深度分析*\n\n"
        response += f"*技术面：*\n"
        response += f"• 价格: `${data['price']:,.2f}`\n"
        response += f"• 24h涨跌: `{data['change_24h']:+.2f}%`\n"
        response += f"• 波动范围: `${data['low_24h']:,.2f}` - `${data['high_24h']:,.2f}`\n\n"
        
        if data['funding_rate']:
            fr_pct = data['funding_rate'] * 100
            response += f"*资金面：*\n"
            response += f"• 资金费率: `{fr_pct:.4f}%`\n"
            
            if fr_pct > 0.05:
                response += "• 多头情绪极度亢奋\n"
                response += "• 建议：警惕顶部，可考虑做空\n\n"
            elif fr_pct < -0.05:
                response += "• 空头情绪极度悲观\n"
                response += "• 建议：关注反弹机会\n\n"
            else:
                response += "• 市场情绪平衡\n\n"
        
        response += "*策略建议：*\n"
        if data['change_24h'] > 5:
            response += "⚠️ 超涨，建议等回调\n"
        elif data['change_24h'] < -5:
            response += "✅ 超跌，可以抄底\n"
        else:
            response += "⏳ 震荡，等待突破\n"
        
        return response
    
    def _handle_general_conversation(self, user_message):
        """处理通用对话"""
        greetings = ["你好", "hi", "hello", "在吗", "在不在"]
        thanks = ["谢谢", "感谢", "thanks", "thank"]
        
        text_lower = user_message.lower()
        
        if any(g in text_lower for g in greetings):
            return "你好！我是你的智能交易助手 🤖\n\n我可以帮你：\n✅ 查询实时行情\n✅ 分析市场趋势\n✅ 推荐交易策略\n✅ 提供操作建议\n\n试试发送：\n• \"ETH的行情\"\n• \"能做多BTC吗\"\n• \"推荐交易策略\""
        
        elif any(t in text_lower for t in thanks):
            return "不客气！有任何交易问题随时问我 😊"
        
        else:
            return f"收到你的消息：「{user_message}」\n\n我目前可以：\n• 查询价格 - \"ETH价格\"\n• 交易建议 - \"能做多BTC吗\"\n• 策略推荐 - \"推荐策略\"\n• 深度分析 - \"分析SOL\"\n\n请告诉我你想了解什么！"
    
    def process_message(self, user_message):
        """处理消息主入口"""
        print(f"\n{'='*60}")
        print(f"[{datetime.now().strftime('%H:%M:%S')}] 用户: {user_message}")
        print(f"{'='*60}")
        
        # 保存到历史
        self.conversation_history.append({
            "role": "user",
            "content": user_message,
            "timestamp": datetime.now().isoformat()
        })
        
        # 生成回复（优先使用OpenAI，失败则用智能fallback）
        if self.openai_api_key:
            response = self.call_openai(user_message)
        else:
            response = self._fallback_intelligent_response(user_message)
        
        # 保存回复
        self.conversation_history.append({
            "role": "assistant",
            "content": response,
            "timestamp": datetime.now().isoformat()
        })
        
        # 限制历史长度
        if len(self.conversation_history) > 20:
            self.conversation_history = self.conversation_history[-20:]
        
        print(f"[{datetime.now().strftime('%H:%M:%S')}] 助手: {response[:100]}...")
        print(f"{'='*60}\n")
        
        return response
    
    def chat_loop(self):
        """主聊天循环"""
        print("💬 开始监听消息...")
        
        while True:
            try:
                updates = self.get_updates(self.last_update_id + 1)
                
                for update in updates:
                    self.last_update_id = update["update_id"]
                    
                    if "message" in update and "text" in update["message"]:
                        user_message = update["message"]["text"]
                        
                        # 处理消息
                        response = self.process_message(user_message)
                        
                        # 发送回复
                        self.send_message(response)
                        print("✅ 已回复\n")
                
                time.sleep(1)
                
            except KeyboardInterrupt:
                print("\n👋 Bot已停止")
                break
            except Exception as e:
                print(f"[错误] {e}")
                time.sleep(5)
    
    def run(self):
        """启动Bot"""
        print("\n" + "="*60)
        print("🤖 智能交易助手启动")
        print("="*60)
        print(f"📱 Chat ID: {self.chat_id}")
        
        if self.openai_api_key:
            print("🧠 AI模式: OpenAI GPT-4")
        else:
            print("🧠 AI模式: 智能规则引擎（推荐配置OpenAI API Key）")
        
        print("="*60)
        print()
        
        # 发送启动通知
        startup_msg = "✅ *智能交易助手已上线！*\n\n"
        
        if self.openai_api_key:
            startup_msg += "🧠 GPT-4驱动，真正的AI对话\n\n"
        else:
            startup_msg += "🤖 智能规则引擎（建议配置OpenAI API）\n\n"
        
        startup_msg += "我可以：\n"
        startup_msg += "✅ 实时行情查询\n"
        startup_msg += "✅ 市场趋势分析\n"
        startup_msg += "✅ 交易策略推荐\n"
        startup_msg += "✅ 精准操作建议\n\n"
        startup_msg += "试试问我：\n"
        startup_msg += "• ETH的行情怎么样？\n"
        startup_msg += "• 现在能做多BTC吗？\n"
        startup_msg += "• 推荐一个交易策略\n"
        
        self.send_message(startup_msg)
        
        # 启动聊天循环
        self.chat_loop()


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="智能交易助手")
    parser.add_argument("--token", default="8200719161:AAEk04eOrn4WfcY75_gEYaYJHEynGmUV030", help="Telegram Token")
    parser.add_argument("--chat-id", default="6174733465", help="Chat ID")
    parser.add_argument("--openai-key", help="OpenAI API Key（可选）")
    
    args = parser.parse_args()
    
    bot = IntelligentTradingBot(
        telegram_token=args.token,
        chat_id=args.chat_id,
        openai_api_key=args.openai_key
    )
    bot.run()
