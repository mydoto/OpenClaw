# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- 通用交易信号捕捉系统
- 多维度信号分析（买卖比、价格、成交量）
- 信号强度评分（1-10级）
- 智能风险管理（自动止损/止盈）
- 完整合约地址显示
- 自学习记录系统

### Changed
- 优化DEX监控性能
- 改进Telegram通知格式

## [1.0.0] - 2026-03-24

### Added
- 通用DEX代币监控系统
- 支持所有主流链（BSC/ETH/Polygon/Arbitrum/Base等）
- 价格异动检测（>5%）
- 成交量暴增检测（>2.5倍）
- 买卖压力分析
- 庄家行为识别（拉盘/出货/吸筹）
- Telegram实时通知
- 配置文件支持
- 完整使用文档

### Technical
- 使用DEX Screener API（免费）
- Python 3.9+ 支持
- 异步通知机制

---

## Changelog 格式说明

### 版本号规则
- **Major (X.0.0)**: 不兼容的API更改
- **Minor (0.X.0)**: 向后兼容的新功能
- **Patch (0.0.X)**: 向后兼容的bug修复

### 变更类型
- **Added**: 新功能
- **Changed**: 现有功能的更改
- **Deprecated**: 即将移除的功能
- **Removed**: 已移除的功能
- **Fixed**: bug修复
- **Security**: 安全相关更新

### 日期格式
YYYY-MM-DD (ISO 8601)

---

[Unreleased]: https://github.com/Jasonfifteen/dex-monitoring-skill/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/Jasonfifteen/dex-monitoring-skill/releases/tag/v1.0.0
