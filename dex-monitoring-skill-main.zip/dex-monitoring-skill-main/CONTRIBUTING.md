# Contributing to DEX Monitoring Skill

感谢你对本项目的关注！我们欢迎任何形式的贡献。

## 如何贡献

### 报告问题 (Issues)

如果你发现了bug或有新功能建议：

1. 在 [Issues](https://github.com/Jasonfifteen/dex-monitoring-skill/issues) 中搜索，确保问题未被报告
2. 创建新 Issue，使用清晰的标题和描述
3. 包含以下信息：
   - 问题的详细描述
   - 复现步骤
   - 预期行为 vs 实际行为
   - 你的环境（OS、Python版本等）
   - 相关日志或截图

### 提交代码 (Pull Requests)

1. **Fork 仓库**
   ```bash
   # 在 GitHub 上 Fork 仓库
   git clone https://github.com/YOUR_USERNAME/dex-monitoring-skill.git
   cd dex-monitoring-skill
   ```

2. **创建分支**
   ```bash
   git checkout -b feature/your-feature-name
   # 或
   git checkout -b fix/your-bug-fix
   ```

3. **编写代码**
   - 遵循现有代码风格
   - 添加必要的注释
   - 确保代码可运行

4. **测试**
   ```bash
   # 测试监控系统
   python3 universal_dex_monitor.py --config dex_monitor_config.json
   
   # 测试信号系统
   python3 universal_signal_trader.py --config signal_trader_config.json
   ```

5. **提交更改**
   ```bash
   git add .
   git commit -m "feat: 添加新功能描述"
   # 或
   git commit -m "fix: 修复bug描述"
   ```

6. **推送并创建 PR**
   ```bash
   git push origin feature/your-feature-name
   ```
   然后在 GitHub 上创建 Pull Request

### Commit 规范

使用语义化的 commit 信息：

- `feat:` 新功能
- `fix:` Bug修复
- `docs:` 文档更新
- `style:` 代码格式调整（不影响功能）
- `refactor:` 代码重构
- `test:` 测试相关
- `chore:` 构建/工具相关

例如：
```
feat: 添加对Solana链的支持
fix: 修复流动性为0时的崩溃问题
docs: 更新安装文档
```

## 开发指南

### 代码风格

- 使用 4 空格缩进
- 函数和类使用文档字符串
- 变量名使用小写+下划线 (snake_case)
- 类名使用大驼峰 (PascalCase)

### 添加新链支持

1. 在 `get_token_data()` 中添加链的特殊处理
2. 在 `format_alert()` 中添加链的 emoji
3. 更新 README.md 的支持链列表
4. 测试至少一个该链的代币

### 添加新指标

1. 在 `get_token_data()` 中获取数据
2. 在 `analyze_signals()` 或 `analyze_signal()` 中添加分析逻辑
3. 在 `format_alert()` 或 `format_signal_message()` 中显示
4. 更新配置文件模板

## 项目结构

```
dex-monitoring-skill/
├── universal_dex_monitor.py      # 市场监控核心
├── universal_signal_trader.py    # 交易信号核心
├── dex_monitor_config.json       # 监控配置模板
├── signal_trader_config.json     # 信号配置模板
├── start_dex_monitor.sh          # 启动脚本
├── UNIVERSAL_DEX_MONITOR_GUIDE.md
├── SIGNAL_TRADER_GUIDE.md
├── QUICK_REFERENCE.md
├── README.md
├── LICENSE
└── CONTRIBUTING.md               # 本文件
```

## 需要帮助？

- 📖 查看 [使用文档](./README.md)
- 💬 在 [Issues](https://github.com/Jasonfifteen/dex-monitoring-skill/issues) 中提问
- 📧 或直接联系维护者

## 行为准则

- 尊重所有贡献者
- 使用友好和包容的语言
- 接受建设性的批评
- 专注于对社区最有利的事情

感谢你的贡献！🎉
