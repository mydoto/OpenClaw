# DEX监控快速参考卡

## 🚀 一键启动

```bash
cd "/Users/helei/Downloads/Jason skills/local-tools"
python3 universal_dex_monitor.py --config dex_monitor_config.json
```

## 📝 配置模板

```json
{
  "tokens": [
    {"address": "0x...", "name": "TOKEN", "chain": "bsc"}
  ],
  "thresholds": {
    "price_alert": 5,
    "volume_surge": 2.5,
    "extreme_buy_ratio": 2.0,
    "extreme_sell_ratio": 0.5,
    "check_interval": 180
  }
}
```

## 🎯 常用命令

```bash
# 监控单个代币
python3 universal_dex_monitor.py --token 0x... --name TOKEN --chain bsc

# 添加代币到配置
python3 universal_dex_monitor.py --config CONFIG --token 0x... --add-token

# 列出配置中的代币
python3 universal_dex_monitor.py --config CONFIG --list-tokens

# 后台运行
nohup python3 -u universal_dex_monitor.py --config CONFIG > log.txt 2>&1 &

# 停止监控
pkill -f universal_dex_monitor
```

## 📊 信号类型

| 信号 | 说明 | 阈值 |
|------|------|------|
| 📈 价格拉升 | 短时间内价格快速上涨 | >5% |
| 📉 价格砸盘 | 短时间内价格快速下跌 | <-5% |
| ⚡ 成交量暴增 | 成交量突然大幅增加 | >2.5倍 |
| 🟢 强烈买压 | 买入远大于卖出 | >2:1 |
| 🔴 强烈卖压 | 卖出远大于买入 | <0.5:1 |
| 🚨 庄家拉盘 | 价格拉升+成交量暴增 | 组合 |
| ⚠️ 庄家出货 | 价格砸盘+强烈卖压 | 组合 |
| 💡 庄家吸筹 | 低位+强烈买压 | 组合 |

## 🌐 支持的链

| 链 | chain参数 |
|----|-----------|
| BSC | `bsc` |
| Ethereum | `ethereum` |
| Polygon | `polygon` |
| Arbitrum | `arbitrum` |
| Base | `base` |
| Optimism | `optimism` |
| Avalanche | `avalanche` |

## ⚙️ 阈值建议

### 保守型（大机会）

```json
{
  "price_alert": 10,
  "volume_surge": 3.0,
  "check_interval": 300
}
```

### 平衡型（推荐）

```json
{
  "price_alert": 5,
  "volume_surge": 2.5,
  "check_interval": 180
}
```

### 激进型（高频）

```json
{
  "price_alert": 3,
  "volume_surge": 2.0,
  "check_interval": 120
}
```

## 🔍 如何找代币地址

1. **DEX Screener**: https://dexscreener.com
2. **BSCScan**: https://bscscan.com
3. **Etherscan**: https://etherscan.io

## 📱 Telegram设置

已配置：
- Token: `8200719161:AAEk04eOrn4WfcY75_gEYaYJHEynGmUV030`
- Chat ID: `6174733465`

## 🐛 常见问题

**Q: 没收到通知？**
A: 检查代币地址、Telegram配置、阈值设置

**Q: 可以监控多少个代币？**
A: 建议≤10个

**Q: 数据延迟多少？**
A: <1分钟（检查间隔+API延迟）

## 📚 更多信息

- 完整文档: [SKILL.md](./SKILL.md)
- 详细指南: `/Users/helei/Downloads/Jason skills/local-tools/UNIVERSAL_DEX_MONITOR_GUIDE.md`

---

**快速开始监控！** 🚀
