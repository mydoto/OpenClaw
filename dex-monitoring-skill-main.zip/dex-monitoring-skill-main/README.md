# Universal DEX Token Monitoring & Signal Trading System

🔍 实时监控任何DEX代币的市场异动 + 🎯 自动捕捉交易信号

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)

---

## 🎯 核心特性

### 📊 市场监控系统
- ✅ **通用性强** - 支持所有DEX代币和主流链（BSC/ETH/Polygon/Arbitrum/Base等）
- ✅ **多币监控** - 可同时监控多个代币
- ✅ **智能分析** - 自动识别价格异动、成交量暴增、买卖比异常
- ✅ **庄家行为识别** - 自动检测拉盘、出货、吸筹行为
- ✅ **完全免费** - 无需任何API Key
- ✅ **实时通知** - Telegram推送到手机

### 🎯 交易信号系统 (NEW!)
- ✅ **自动信号捕捉** - 基于多维度数据生成买入/卖出信号
- ✅ **信号强度评分** - 1-10级信号可信度评分
- ✅ **智能风险管理** - 自动计算入场价、止损位、止盈位
- ✅ **仓位建议** - 基于风险的仓位管理建议
- ✅ **实战训练** - 记录所有信号用于回测和优化

---

## 📦 项目包含

### 1. 市场监控系统 (`universal_dex_monitor.py`)
实时监控市场异动，识别庄家行为

### 2. 交易信号系统 (`universal_signal_trader.py`) 🆕
自动捕捉交易信号，生成买入/卖出建议

---

## 📊 市场监控系统

### 监控指标

### 1. 价格异动
- 📈 价格拉升（>5%）
- 📉 价格砸盘（<-5%）

### 2. 成交量分析
- ⚡ 成交量暴增（>2.5倍）

### 3. 买卖比分析
- 🟢 强烈买压（买卖比>2:1）
- 🔴 强烈卖压（买卖比<0.5:1）

### 4. 庄家行为识别
- 🚨 **庄家拉盘** = 价格大涨 + 成交量暴增
- ⚠️ **庄家出货** = 价格大跌 + 强卖压
- 💡 **庄家吸筹** = 低位 + 强买压

---

## 🚀 快速开始

### 安装依赖

```bash
pip3 install requests
```

### 配置文件

编辑 `dex_monitor_config.json`:

```json
{
  "tokens": [
    {
      "address": "0x997a58129890bbda032231a52ed1ddc845fc18e1",
      "name": "SIREN",
      "chain": "bsc"
    }
  ],
  "thresholds": {
    "price_alert": 5,
    "volume_surge": 2.5,
    "extreme_buy_ratio": 2.0,
    "extreme_sell_ratio": 0.5,
    "check_interval": 180
  }
}
```

### 配置Telegram通知

编辑 `universal_dex_monitor.py`，设置：
- `TELEGRAM_TOKEN` - 你的Bot Token
- `CHAT_ID` - 你的Chat ID

### 启动监控

```bash
# 方式1: 使用启动脚本
./start_dex_monitor.sh

# 方式2: 直接运行
python3 universal_dex_monitor.py --config dex_monitor_config.json

# 方式3: 监控单个代币
python3 universal_dex_monitor.py \
  --token 0x997a58129890bbda032231a52ed1ddc845fc18e1 \
  --name SIREN \
  --chain bsc
```

---

## 🎯 交易信号系统

### 信号类型

#### 🟢🟢🟢 STRONG_BUY (强烈买入)
- 信号强度 ≥ 4
- 特征: 买卖比 > 3:1 + 价格上涨 > 5%
- 建议: 激进入场

#### 🟢 BUY (买入)
- 信号强度 ≥ 2
- 特征: 买压偏强 或 价格上涨
- 建议: 谨慎入场

#### 🔴 SELL (卖出)
- 信号强度 ≤ -2
- 特征: 卖压偏强 或 价格下跌
- 建议: 做空或离场

#### 🔴🔴🔴 STRONG_SELL (强烈卖出)
- 信号强度 ≤ -4
- 特征: 买卖比 < 0.3:1 + 价格暴跌 > 5%
- 建议: 激进做空

### 快速开始

```bash
# 添加监控代币
python3 universal_signal_trader.py \
  --config signal_trader_config.json \
  --add-token \
  --token 0x997a58129890bbda032231a52ed1ddc845fc18e1 \
  --name SIREN \
  --chain bsc

# 启动信号捕捉
python3 universal_signal_trader.py \
  --config signal_trader_config.json \
  --telegram-token YOUR_BOT_TOKEN \
  --chat-id YOUR_CHAT_ID

# 后台运行
nohup python3 -u universal_signal_trader.py \
  --config signal_trader_config.json \
  --telegram-token YOUR_BOT_TOKEN \
  --chat-id YOUR_CHAT_ID \
  > signal_trader.log 2>&1 &
```

### 信号通知示例

```
🟢🟢🟢 交易信号！ 🔶

📌 SIREN (SRN)

🎯 信号类型: STRONG_BUY
📊 信号强度: 5/10
💡 信号依据: 强烈买压 (3.2:1), 急涨 (+6.3%)

💰 当前价格: $2.27000000
📈 5分钟: +6.30%
📈 1小时: +12.50%
📈 24小时: -8.20%

📊 买卖数据:
   买: 180 | 卖: 56
   买卖比: 3.21

📍 合约地址:
0x997a58129890bbda032231a52ed1ddc845fc18e1

---

🎯 交易建议: 做多

💰 入场价: $2.27000000
🛑 止损位: $2.15650000 (-5%)
🎯 止盈1: $2.38350000 (+5%)
🎯 止盈2: $2.49700000 (+10%)
💼 建议仓位: 5% 总资金

⏰ 2026-03-24 09:30:00

⚠️ 风险提示: 
- DEX代币波动大，严格止损
- 达到止盈1可减仓50%
- 不要FOMO，等待信号

🔗 查看图表
```

---

## 📱 市场监控通知示例

```
🚨 SIREN (SIREN) 重大异动！ 🔶

🚨 疑似庄家拉盘！
   价格拉升 + 成交量暴增

📈 价格拉升 12.50%
   从 $2.450000 → $2.756250

⚡ 成交量暴增 3.2倍
   5分钟成交量从 $52,000 → $166,400

📊 当前数据
💰 价格: $2.75625000
📈 5m: +12.50% | 1h: +10.20% | 24h: +25.30%

📊 5分钟: 买850 / 卖320
💧 流动性: $18,500,000

⏰ 2026-03-23 20:15:42

🔗 查看图表
```

---

## 🌐 支持的链

| 链 | chain参数 | 说明 |
|----|-----------|------|
| BNB Smart Chain | `bsc` | 币安智能链 |
| Ethereum | `ethereum` | 以太坊主网 |
| Polygon | `polygon` | Polygon |
| Arbitrum | `arbitrum` | Arbitrum |
| Base | `base` | Base |
| Optimism | `optimism` | Optimism |
| Avalanche | `avalanche` | Avalanche C-Chain |

---

## 🔧 配置说明

### 代币配置

```json
{
  "address": "0x...",  // 代币合约地址
  "name": "TOKEN",     // 代币名称
  "chain": "bsc"       // 链名称
}
```

### 阈值配置

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `price_alert` | 价格变化>N%通知 | 5 |
| `volume_surge` | 成交量增加>N倍通知 | 2.5 |
| `extreme_buy_ratio` | 买卖比>N为强买压 | 2.0 |
| `extreme_sell_ratio` | 买卖比<N为强卖压 | 0.5 |
| `check_interval` | 检查间隔（秒） | 180 |

---

## 💡 使用场景

### 1. 寻找交易机会
监控3-5个潜在标的，发现异动后深入分析

### 2. 持仓风险监控
实时监控持仓代币，及时发现庄家出货信号

### 3. 日内波段交易
低阈值监控，快速捕捉3-5%的波动机会

### 4. 学习市场规律
观察多个代币的行为模式，理解庄家操作手法

---

## 📚 文档

- [SKILL.md](./SKILL.md) - 完整技能文档
- [QUICK_REFERENCE.md](./QUICK_REFERENCE.md) - 快速参考卡
- [UNIVERSAL_DEX_MONITOR_GUIDE.md](./UNIVERSAL_DEX_MONITOR_GUIDE.md) - 详细使用指南
- [INTEGRATION_SUMMARY.md](./INTEGRATION_SUMMARY.md) - 集成总结

---

## 🛠️ 命令行参数

```bash
# 使用配置文件
python3 universal_dex_monitor.py --config dex_monitor_config.json

# 监控单个代币
python3 universal_dex_monitor.py --token ADDRESS --name NAME --chain CHAIN

# 添加代币到配置
python3 universal_dex_monitor.py --config CONFIG --token ADDRESS --add-token

# 列出配置中的代币
python3 universal_dex_monitor.py --config CONFIG --list-tokens

# 自定义Telegram配置
python3 universal_dex_monitor.py \
  --config CONFIG \
  --telegram-token TOKEN \
  --chat-id CHAT_ID
```

---

## 🔍 如何找代币地址

### 方法1: DEX Screener
1. 访问 https://dexscreener.com
2. 搜索代币名称
3. 复制合约地址

### 方法2: 区块链浏览器
- **BSCScan**: https://bscscan.com
- **Etherscan**: https://etherscan.io
- **PolygonScan**: https://polygonscan.com

### 方法3: 钱包
在MetaMask等钱包中点击代币即可查看地址

---

## 📈 实战案例

### 案例: Meme币逼空预警

**背景**: 做空某Meme币，系统检测到异常拉升

**监控发现**:
- 价格从1.48拉升到4.81（+224%）
- 成交量暴增5倍
- 买卖比异常（>3:1）

**结果**: 及时平仓避免更大损失

**教训**: Meme币庄家控盘强，有利润就跑

---

## ⚠️ 注意事项

### 1. API限制
- DEX Screener API免费但有速率限制
- 建议检查间隔≥2分钟
- 同时监控代币数量≤10个

### 2. 通知管理
- 避免设置过低的阈值导致频繁通知
- 建议价格阈值≥5%
- 成交量阈值≥2.5倍

### 3. 数据准确性
- DEX数据基于实时交易对
- 极端情况下可能有延迟
- 建议结合图表确认

---

## 📄 许可证

MIT License - 仅供学习交流使用

---

## 🤝 贡献

欢迎提交Issue和Pull Request！

---

## 📧 联系

- GitHub: [@JasonFifteen](https://github.com/JasonFifteen)
- Telegram: [@JasonFifteen](https://t.me/JasonFifteen)

---

**开始监控，不错过任何交易机会！** 🚀
