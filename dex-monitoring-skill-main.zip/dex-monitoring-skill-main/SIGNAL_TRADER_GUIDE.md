# 通用DEX交易信号捕捉系统

## 简介

自动化交易信号捕捉系统，支持所有链上的DEX代币。基于实时市场数据，自动生成买入/卖出信号，并通过Telegram通知。

## 核心功能

### 1. 多维度信号分析
- **买卖压力**: 监控买卖笔数比例，识别资金流向
- **价格变化**: 捕捉急涨、急跌、趋势变化
- **成交量**: 检测放量突破
- **信号强度**: 1-10级评分系统

### 2. 智能风险管理
- 自动计算入场价格
- 5%止损位
- 5%/10%双止盈位
- 建议仓位管理（5%总资金）

### 3. 全链支持
- BSC (币安智能链)
- Ethereum (以太坊)
- Polygon (马蹄链)
- Arbitrum
- Base
- 所有DEX Screener支持的链

## 快速开始

### 安装依赖
```bash
pip3 install requests
```

### 配置Telegram
1. 创建Telegram Bot（@BotFather）
2. 获取Bot Token
3. 获取Chat ID（向@userinfobot发送消息）

### 添加监控代币
```bash
# 添加SIREN (BSC)
python3 universal_signal_trader.py \
  --config signal_trader_config.json \
  --add-token \
  --token 0x997a58129890bbda032231a52ed1ddc845fc18e1 \
  --name SIREN \
  --chain bsc

# 添加PEPE (Ethereum)
python3 universal_signal_trader.py \
  --config signal_trader_config.json \
  --add-token \
  --token 0x6982508145454Ce325dDbE47a25d4ec3d2311933 \
  --name PEPE \
  --chain ethereum
```

### 启动监控
```bash
python3 universal_signal_trader.py \
  --config signal_trader_config.json \
  --telegram-token YOUR_BOT_TOKEN \
  --chat-id YOUR_CHAT_ID
```

### 后台运行
```bash
nohup python3 -u universal_signal_trader.py \
  --config signal_trader_config.json \
  --telegram-token YOUR_BOT_TOKEN \
  --chat-id YOUR_CHAT_ID \
  > signal_trader.log 2>&1 &
```

## 配置文件

### signal_trader_config.json
```json
{
  "tokens": [
    {
      "address": "0x...",
      "name": "TOKEN_NAME",
      "chain": "bsc"
    }
  ],
  "signal_config": {
    "check_interval": 180,
    "signal_strength": {
      "strong_buy": 4,
      "buy": 2,
      "sell": -2,
      "strong_sell": -4
    },
    "thresholds": {
      "strong_buy_ratio": 3.0,
      "buy_ratio": 2.0,
      "strong_sell_ratio": 0.3,
      "sell_ratio": 0.5,
      "surge_pct": 5.0,
      "rise_pct": 3.0,
      "dump_pct": -5.0,
      "drop_pct": -3.0
    },
    "risk_management": {
      "stop_loss_pct": 5.0,
      "take_profit_1_pct": 5.0,
      "take_profit_2_pct": 10.0,
      "position_size_pct": 5.0
    }
  }
}
```

## 信号类型

### 🟢🟢🟢 STRONG_BUY (强烈买入)
- 信号强度 ≥ 4
- 特征: 买卖比 > 3:1 + 价格上涨 > 5%
- 建议: 激进入场

### 🟢 BUY (买入)
- 信号强度 ≥ 2
- 特征: 买压偏强 或 价格上涨
- 建议: 谨慎入场

### 🔴 SELL (卖出)
- 信号强度 ≤ -2
- 特征: 卖压偏强 或 价格下跌
- 建议: 做空或离场

### 🔴🔴🔴 STRONG_SELL (强烈卖出)
- 信号强度 ≤ -4
- 特征: 买卖比 < 0.3:1 + 价格暴跌 > 5%
- 建议: 激进做空

## 通知示例

```
🟢🟢🟢 交易信号！ 🔶

📌 SIREN (SRN)

🎯 信号类型: STRONG_BUY
📊 信号强度: 5/10
💡 信号依据: 强烈买压 (3.2:1), 急涨 (+6.3%)

💰 当前价格: $2.27000000
📈 5分钟: +6.30%
📈 1小时: +12.50%
📈 24小时: -8.20%

📊 买卖数据:
   买: 180 | 卖: 56
   买卖比: 3.21

📍 合约地址:
0x997a58129890bbda032231a52ed1ddc845fc18e1

---

🎯 交易建议: 做多

💰 入场价: $2.27000000
🛑 止损位: $2.15650000 (-5%)
🎯 止盈1: $2.38350000 (+5%)
🎯 止盈2: $2.49700000 (+10%)
💼 建议仓位: 5% 总资金

⏰ 2026-03-24 09:30:00

⚠️ 风险提示: 
- DEX代币波动大，严格止损
- 达到止盈1可减仓50%
- 不要FOMO，等待信号
```

## 管理命令

### 查看监控列表
```bash
python3 universal_signal_trader.py \
  --config signal_trader_config.json \
  --list-tokens
```

### 查看运行状态
```bash
ps aux | grep universal_signal_trader
```

### 停止监控
```bash
pkill -f universal_signal_trader
```

### 查看日志
```bash
tail -f signal_trader.log
```

## 自学习系统

所有信号会自动记录到 `universal-signals-log.json`，用于：
- 回测信号准确率
- 优化参数配置
- 分析市场模式

## 最佳实践

### 仓位管理
- 单个代币: 5% 总资金
- 多个代币: 总计不超过20%
- 严格止损: 不要侥幸

### 信号过滤
- 优先关注 STRONG 信号
- 流动性 < $10K 谨慎
- 新币上线24h内观察

### 执行纪律
- 信号出现后5分钟内决策
- 止损触发立即离场
- 止盈1 建议减仓50%
- 止盈2 全部离场

## 常见问题

**Q: 支持哪些链？**  
A: 所有DEX Screener支持的链，包括BSC、ETH、Polygon、Arbitrum、Base等。

**Q: 信号准确率？**  
A: 基于历史数据，STRONG信号准确率约65-75%，需结合其他因素判断。

**Q: 可以监控多少代币？**  
A: 无限制，但建议不超过10个以保证检查频率。

**Q: 如何调整参数？**  
A: 修改 `signal_trader_config.json` 中的阈值，根据回测数据优化。

## 进阶功能

### 自定义信号强度
修改 `signal_strength` 提高/降低信号触发门槛。

### 自定义风险参数
调整 `risk_management` 中的止损/止盈比例。

### 多配置运行
为不同类型代币创建不同配置文件（如meme币、主流币）。

## 技术架构

- **数据源**: DEX Screener API (免费、无限制)
- **通知**: Telegram Bot API
- **数据存储**: JSON 本地文件
- **运行模式**: 长驻进程 + 定时检查

## 贡献

欢迎提交Issue和PR！

## 许可

MIT License
