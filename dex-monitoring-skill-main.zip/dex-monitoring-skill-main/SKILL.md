---
name: DEX代币实时监控系统
description: 通用DEX代币监控工具，支持所有链上代币的实时异动监控，自动识别庄家行为
author: Jason Trading System
version: 1.0.0
category: 交易工具
tags: [DEX, 监控, 实时分析, 庄家行为, 多链支持]
---

# DEX代币实时监控系统

## 📋 技能概述

这是一个**通用的DEX代币监控系统**，可以实时监控任何DEX代币的市场异动，自动识别庄家行为（拉盘、出货、吸筹），并通过Telegram即时通知你。

### 核心优势

- ✅ **通用性强** - 支持所有DEX代币和主流链（BSC/ETH/Polygon/Arbitrum/Base等）
- ✅ **多币监控** - 可同时监控多个代币
- ✅ **智能分析** - 自动识别价格异动、成交量暴增、买卖比异常
- ✅ **庄家行为识别** - 自动检测拉盘、出货、吸筹行为
- ✅ **完全免费** - 无需任何API Key
- ✅ **实时通知** - Telegram推送到手机

---

## 🎯 使用场景

### 1. 寻找交易机会
监控3-5个潜在标的，发现异动后深入分析，找到最佳入场时机。

### 2. 持仓风险监控
实时监控你持仓的代币，及时发现庄家出货信号，保护利润。

### 3. 日内波段交易
低阈值监控，快速捕捉3-5%的波动机会。

### 4. 学习市场规律
观察多个代币的行为模式，理解庄家操作手法。

---

## 📦 工具位置

所有监控工具位于：
```
/Users/helei/Downloads/Jason skills/local-tools/
```

### 核心文件

1. **`universal_dex_monitor.py`** - 通用监控程序
2. **`dex_monitor_config.json`** - 配置文件
3. **`UNIVERSAL_DEX_MONITOR_GUIDE.md`** - 完整使用文档

---

## 🚀 快速开始

### 方式1: 使用配置文件（推荐）

**步骤1: 编辑配置文件**

```bash
cd "/Users/helei/Downloads/Jason skills/local-tools"
nano dex_monitor_config.json
```

**配置示例：**
```json
{
  "tokens": [
    {
      "address": "0x997a58129890bbda032231a52ed1ddc845fc18e1",
      "name": "SIREN",
      "chain": "bsc"
    },
    {
      "address": "0x55d398326f99059ff775485246999027b3197955",
      "name": "USDT",
      "chain": "bsc"
    }
  ],
  "thresholds": {
    "price_alert": 5,
    "volume_surge": 2.5,
    "extreme_buy_ratio": 2.0,
    "extreme_sell_ratio": 0.5,
    "check_interval": 180
  }
}
```

**步骤2: 启动监控**

```bash
python3 universal_dex_monitor.py --config dex_monitor_config.json
```

---

### 方式2: 命令行快速监控

监控单个代币：

```bash
python3 universal_dex_monitor.py \
  --token 0x997a58129890bbda032231a52ed1ddc845fc18e1 \
  --name SIREN \
  --chain bsc
```

---

## 🔧 配置说明

### 代币配置

| 字段 | 说明 | 示例 |
|------|------|------|
| `address` | 代币合约地址 | `0x997a58...` |
| `name` | 代币名称 | `SIREN` |
| `chain` | 链名称 | `bsc`/`ethereum`/`polygon` |

### 监控阈值

| 参数 | 说明 | 默认值 | 建议范围 |
|------|------|--------|----------|
| `price_alert` | 价格变化>N%时通知 | 5 | 3-10 |
| `volume_surge` | 成交量增加>N倍时通知 | 2.5 | 2-5 |
| `extreme_buy_ratio` | 买卖比>N为强买压 | 2.0 | 1.5-3.0 |
| `extreme_sell_ratio` | 买卖比<N为强卖压 | 0.5 | 0.3-0.6 |
| `check_interval` | 检查间隔（秒） | 180 | 120-300 |

---

## 📊 监控指标

### 1. 价格异动
监控每N分钟的价格变化，超过阈值立即通知。

**信号类型：**
- 📈 价格拉升（>5%）
- 📉 价格砸盘（<-5%）

### 2. 成交量分析
对比前后两次的成交量，暴增说明有大额操作。

**信号类型：**
- ⚡ 成交量暴增（>2.5倍）

### 3. 买卖比分析
计算买入次数 vs 卖出次数。

**信号类型：**
- 🟢 强烈买压（买卖比>2:1）
- 🔴 强烈卖压（买卖比<0.5:1）

### 4. 庄家行为识别

综合价格、成交量、买卖比三个维度：

- 🚨 **庄家拉盘** = 价格大涨 + 成交量暴增
- ⚠️ **庄家出货** = 价格大跌 + 强卖压
- 💡 **庄家吸筹** = 低位 + 强买压

---

## 📱 通知示例

### 重大异动（庄家拉盘）

```
🚨 SIREN (SIREN) 重大异动！ 🔶

🚨 疑似庄家拉盘！
   价格拉升 + 成交量暴增

📈 价格拉升 12.50%
   从 $2.450000 → $2.756250

⚡ 成交量暴增 3.2倍
   5分钟成交量从 $52,000 → $166,400

📊 当前数据
💰 价格: $2.75625000
📈 5m: +12.50% | 1h: +10.20% | 24h: +25.30%

📊 5分钟: 买850 / 卖320
💧 流动性: $18,500,000
📍 地址: `0x997a5812...45fc18e1`

⏰ 2026-03-23 20:15:42

🔗 查看图表
```

---

## 🌐 支持的链

| 链 | chain参数 | 说明 |
|----|-----------|------|
| BNB Smart Chain | `bsc` | 币安智能链 |
| Ethereum | `ethereum` | 以太坊主网 |
| Polygon | `polygon` | Polygon |
| Arbitrum | `arbitrum` | Arbitrum |
| Base | `base` | Base（Coinbase L2） |
| Optimism | `optimism` | Optimism |
| Avalanche | `avalanche` | Avalanche C-Chain |

---

## 💡 实战策略

### 策略1: 寻找交易机会

**目标**: 发现新的高潜力代币

**配置**:
```json
{
  "tokens": [
    {"address": "热门币1", "chain": "bsc"},
    {"address": "热门币2", "chain": "ethereum"},
    {"address": "热门币3", "chain": "base"}
  ],
  "thresholds": {
    "price_alert": 10,
    "volume_surge": 3.0,
    "check_interval": 120
  }
}
```

**操作流程**:
1. 监控3-5个潜在标的
2. 设置较高阈值（只通知大异动）
3. 收到通知后深入分析
4. 确认趋势后入场

---

### 策略2: 持仓保护

**目标**: 保护已有利润

**配置**:
```json
{
  "tokens": [
    {"address": "你的持仓代币", "chain": "bsc"}
  ],
  "thresholds": {
    "price_alert": 5,
    "volume_surge": 2.5,
    "extreme_sell_ratio": 0.6,
    "check_interval": 180
  }
}
```

**操作流程**:
1. 只监控持仓代币
2. 中等敏感度
3. 特别关注卖压信号
4. 发现出货迹象立即平仓

---

### 策略3: 日内波段

**目标**: 捕捉短期波动

**配置**:
```json
{
  "thresholds": {
    "price_alert": 3,
    "volume_surge": 2.0,
    "check_interval": 120
  }
}
```

**操作流程**:
1. 低阈值（3%）
2. 短间隔（2分钟）
3. 快进快出
4. 控制好止损

---

## 🔍 如何找代币地址

### 方法1: DEX Screener

1. 访问 https://dexscreener.com
2. 搜索代币名称
3. 复制合约地址

### 方法2: 区块链浏览器

- **BSCScan**: https://bscscan.com
- **Etherscan**: https://etherscan.io
- **PolygonScan**: https://polygonscan.com

### 方法3: 钱包

在MetaMask等钱包中点击代币即可查看地址。

---

## 🎓 学习资源

### 相关技能

- **[交易策略](/skills/trading-strategies/SKILL.md)** - 各种交易策略详解
- **[风险管理](/docs/RISK_MANAGEMENT.md)** - 专业风险管理指南
- **[自学习系统](/skills/self-learning-trading-system/SKILL.md)** - AI自我提升系统

### 监控原理

详细的监控原理和算法说明，请查看：
```
/Users/helei/Downloads/Jason skills/local-tools/UNIVERSAL_DEX_MONITOR_GUIDE.md
```

---

## 📝 命令行参考

### 基本命令

```bash
# 使用配置文件
python3 universal_dex_monitor.py --config dex_monitor_config.json

# 监控单个代币
python3 universal_dex_monitor.py --token ADDRESS --name NAME --chain CHAIN

# 添加代币到配置
python3 universal_dex_monitor.py --config CONFIG --token ADDRESS --add-token

# 列出配置中的代币
python3 universal_dex_monitor.py --config CONFIG --list-tokens
```

### 后台运行

```bash
# 使用nohup
nohup python3 -u universal_dex_monitor.py \
  --config dex_monitor_config.json \
  > dex_monitor.log 2>&1 &

# 查看日志
tail -f dex_monitor.log

# 停止监控
pkill -f universal_dex_monitor
```

### 使用screen（推荐）

```bash
# 创建session
screen -S dex-monitor

# 启动监控
python3 universal_dex_monitor.py --config dex_monitor_config.json

# 离开（Ctrl+A 然后 D）

# 重新连接
screen -r dex-monitor
```

---

## ⚠️ 注意事项

### 1. API限制
- DEX Screener API免费但有速率限制
- 建议检查间隔≥2分钟
- 同时监控代币数量≤10个

### 2. 通知管理
- 避免设置过低的阈值导致频繁通知
- 建议价格阈值≥5%
- 成交量阈值≥2.5倍

### 3. 数据准确性
- DEX数据基于实时交易对
- 极端情况下可能有延迟
- 建议结合图表确认

---

## 🐛 常见问题

### Q1: 为什么没有收到通知？

**A**: 检查以下几点
1. Telegram Bot Token和Chat ID是否正确
2. 代币地址是否正确
3. 阈值是否设置过高
4. 检查日志确认是否有错误

### Q2: 可以监控多少个代币？

**A**: 
- 技术上无限制
- 建议≤10个（避免API限制）
- 越多代币，检查周期越长

### Q3: 支持哪些链？

**A**: 
- 支持DEX Screener支持的所有链
- 主要包括：BSC、ETH、Polygon、Arbitrum、Base、Optimism、Avalanche等

### Q4: 数据来源是什么？

**A**:
- 数据来自DEX Screener API
- 完全免费，无需API Key
- 实时性：延迟<1分钟

---

## 📚 完整文档

更详细的使用指南，请查看：

```
/Users/helei/Downloads/Jason skills/local-tools/UNIVERSAL_DEX_MONITOR_GUIDE.md
```

---

## 🤝 与其他技能配合

### 与交易策略配合

1. **监控发现异动** → 使用本技能
2. **深入分析** → 使用[市场分析技能]
3. **制定策略** → 参考[交易策略技能]
4. **执行交易** → 使用交易所API
5. **风险管理** → 参考[风险管理文档]

### 与自学习系统配合

- 监控数据自动记录
- 异动案例自动归档
- 策略效果持续优化
- AI持续学习提升

---

## 📈 成功案例

### 案例1: SIREN逼空预警（你的经验）

**背景**: 你做空SIREN，系统检测到异常拉升

**监控发现**:
- 价格从1.48拉升到4.81（+224%）
- 成交量暴增5倍
- 买卖比异常（>3:1）

**结果**: 及时平仓避免更大损失

**教训**: Meme币庄家控盘强，有利润就跑

---

## 🎯 总结

这个DEX监控系统是你的**市场雷达**：

- 🔍 **发现机会** - 实时捕捉市场异动
- 🛡️ **风险预警** - 及时发现出货信号
- 📊 **数据支持** - 客观的市场数据
- 🤖 **自动化** - 24/7不间断监控

**立即开始使用，不要错过任何交易机会！** 🚀
