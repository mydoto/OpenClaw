# 代币管理工具使用指南

## 功能

动态添加/管理监控代币，无需手动编辑配置文件。

## 快速使用

### 添加新代币

```bash
# 方式1: 自动获取代币信息
python3 token_manager.py --add 0x代币地址

# 方式2: 指定代币名称
python3 token_manager.py --add 0x代币地址 --name BR --chain bsc

# 方式3: 添加但不自动重启（批量添加时使用）
python3 token_manager.py --add 0x代币地址 --name TOKEN --no-restart
```

### 列出所有监控代币

```bash
python3 token_manager.py --list
```

## 示例

```bash
# 添加BR代币
python3 token_manager.py --add 0xff7d6a96ae471bbcd7713af9cb1feeb16cf56b41 --name BR

# 添加以太坊上的代币
python3 token_manager.py --add 0x... --chain ethereum

# 查看监控列表
python3 token_manager.py --list
```

## 自动功能

添加代币时会自动：
1. ✅ 从DEX Screener获取代币信息
2. ✅ 更新两个配置文件
3. ✅ 重启监控系统
4. ✅ 发送Telegram通知确认

## 支持的链

- bsc (币安智能链)
- ethereum (以太坊)
- polygon (Polygon)
- arbitrum (Arbitrum)
- base (Base)
- 其他DEX Screener支持的链

## 注意事项

- 添加代币会自动重启监控系统（约3秒）
- 系统会自动去重，不会重复添加
- 确保代币地址正确（小写）
- 链名称要与DEX Screener一致
