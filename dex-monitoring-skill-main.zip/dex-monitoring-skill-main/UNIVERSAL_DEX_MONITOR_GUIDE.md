# 通用DEX代币监控系统

## 🎯 功能特点

### 支持所有DEX代币
- ✅ **多链支持**: BSC、ETH、Polygon、Arbitrum、Base等
- ✅ **多代币同时监控**: 可以同时监控多个代币
- ✅ **灵活配置**: 通过配置文件或命令行管理
- ✅ **完全免费**: 无需任何API Key

### 自动监控
- 📈 价格异动（可自定义阈值）
- 📊 成交量暴增
- 💹 买卖比异常
- 🐋 庄家行为识别（拉盘/出货/吸筹）

---

## 🚀 快速开始

### 方式1: 使用配置文件（推荐，监控多个代币）

**1. 编辑配置文件**

```bash
nano "/Users/helei/Downloads/Jason skills/local-tools/dex_monitor_config.json"
```

配置格式：
```json
{
  "tokens": [
    {
      "address": "0x997a58129890bbda032231a52ed1ddc845fc18e1",
      "name": "SIREN",
      "chain": "bsc"
    },
    {
      "address": "0x55d398326f99059ff775485246999027b3197955",
      "name": "USDT",
      "chain": "bsc"
    }
  ],
  "thresholds": {
    "price_alert": 5,
    "volume_surge": 2.5,
    "extreme_buy_ratio": 2.0,
    "extreme_sell_ratio": 0.5,
    "check_interval": 180
  }
}
```

**2. 启动监控**

```bash
cd "/Users/helei/Downloads/Jason skills/local-tools"
python3 universal_dex_monitor.py --config dex_monitor_config.json
```

---

### 方式2: 命令行指定单个代币

```bash
# 监控单个代币
python3 universal_dex_monitor.py \
  --token 0x997a58129890bbda032231a52ed1ddc845fc18e1 \
  --name SIREN \
  --chain bsc
```

---

## 📝 使用示例

### 1. 添加新代币到配置

```bash
# 方法A: 直接编辑配置文件（推荐）
nano dex_monitor_config.json

# 方法B: 使用命令行添加
python3 universal_dex_monitor.py \
  --config dex_monitor_config.json \
  --token 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c \
  --name WBNB \
  --chain bsc \
  --add-token
```

### 2. 查看当前监控的代币

```bash
python3 universal_dex_monitor.py \
  --config dex_monitor_config.json \
  --list-tokens
```

### 3. 监控ETH链上的代币

```bash
python3 universal_dex_monitor.py \
  --token 0xdac17f958d2ee523a2206206994597c13d831ec7 \
  --name USDT \
  --chain ethereum
```

### 4. 同时监控多个链的代币

编辑配置文件：
```json
{
  "tokens": [
    {
      "address": "0x997a58129890bbda032231a52ed1ddc845fc18e1",
      "name": "SIREN",
      "chain": "bsc"
    },
    {
      "address": "0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984",
      "name": "UNI",
      "chain": "ethereum"
    },
    {
      "address": "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174",
      "name": "USDC",
      "chain": "polygon"
    }
  ]
}
```

---

## 🔧 配置说明

### 代币配置

| 字段 | 说明 | 必填 |
|------|------|------|
| `address` | 代币合约地址 | ✅ |
| `name` | 代币名称（会自动从DEX获取） | ❌ |
| `chain` | 链名称（bsc/ethereum/polygon等） | ✅ |

### 阈值配置

| 字段 | 说明 | 默认值 |
|------|------|--------|
| `price_alert` | 价格变化超过多少%发送通知 | 5 |
| `volume_surge` | 成交量增加多少倍发送通知 | 2.5 |
| `extreme_buy_ratio` | 强买压的买卖比阈值 | 2.0 |
| `extreme_sell_ratio` | 强卖压的买卖比阈值 | 0.5 |
| `check_interval` | 检查间隔（秒） | 180 |

---

## 🌐 支持的链

| 链 | chain参数 | 说明 |
|----|-----------|------|
| BNB Smart Chain | `bsc` | 币安智能链 |
| Ethereum | `ethereum` | 以太坊主网 |
| Polygon | `polygon` | Polygon |
| Arbitrum | `arbitrum` | Arbitrum |
| Base | `base` | Base |
| Optimism | `optimism` | Optimism |
| Avalanche | `avalanche` | Avalanche C-Chain |

---

## 📱 通知示例

### 单个代币异动

```
🚨 SIREN (SIREN) 重大异动！ 🔶

🚨 疑似庄家拉盘！
   价格拉升 + 成交量暴增

📈 价格拉升 12.50%
   从 $2.450000 → $2.756250

⚡ 成交量暴增 3.2倍
   5分钟成交量从 $52,000 → $166,400

📊 当前数据
💰 价格: $2.75625000
📈 5m: +12.50% | 1h: +10.20% | 24h: +25.30%

📊 5分钟: 买850 / 卖320
💧 流动性: $18,500,000
📍 地址: `0x997a5812...45fc18e1`

⏰ 2026-03-23 20:15:42

🔗 查看图表
```

### 多代币监控

系统会为每个检测到异动的代币发送单独的通知，方便你快速识别哪个代币有机会。

---

## 🎯 实战案例

### 案例1: 监控热门Meme币

```json
{
  "tokens": [
    {
      "address": "0x4200000000000000000000000000000000000006",
      "name": "WETH",
      "chain": "base"
    },
    {
      "address": "0x532f27101965dd16442E59d40670FaF5eBB142E4",
      "name": "BRETT",
      "chain": "base"
    },
    {
      "address": "0x997a58129890bbda032231a52ed1ddc845fc18e1",
      "name": "SIREN",
      "chain": "bsc"
    }
  ],
  "thresholds": {
    "price_alert": 8,
    "volume_surge": 3.0,
    "check_interval": 120
  }
}
```

**说明**: 
- 提高阈值（8%价格变化、3倍成交量）
- 缩短检查间隔（2分钟）
- 监控多链的热门币

---

### 案例2: 保守型监控

```json
{
  "tokens": [
    {
      "address": "0x55d398326f99059ff775485246999027b3197955",
      "name": "USDT",
      "chain": "bsc"
    },
    {
      "address": "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
      "name": "WBNB",
      "chain": "bsc"
    }
  ],
  "thresholds": {
    "price_alert": 3,
    "volume_surge": 2.0,
    "check_interval": 300
  }
}
```

**说明**:
- 监控主流币
- 更敏感的阈值（3%）
- 更长的间隔（5分钟），避免频繁通知

---

## 🔍 如何找到代币地址

### 方法1: 从DEX Screener

1. 访问 https://dexscreener.com
2. 搜索代币名称
3. 点击代币，URL中包含合约地址
4. 或在页面上直接复制合约地址

### 方法2: 从区块链浏览器

**BSCScan**: https://bscscan.com  
**Etherscan**: https://etherscan.io  
**PolygonScan**: https://polygonscan.com

搜索代币名称，即可找到合约地址。

### 方法3: 从钱包

如果你在MetaMask等钱包持有该代币，点击代币即可查看合约地址。

---

## 💡 使用建议

### 1. 寻找交易机会
**场景**: 你想发现新的交易机会

**配置**:
```json
{
  "tokens": [
    {"address": "...", "name": "热门币1", "chain": "bsc"},
    {"address": "...", "name": "热门币2", "chain": "bsc"},
    {"address": "...", "name": "热门币3", "chain": "eth"}
  ],
  "thresholds": {
    "price_alert": 10,
    "volume_surge": 3.0,
    "check_interval": 120
  }
}
```

**策略**: 
- 监控3-5个潜在标的
- 设置较高阈值（只通知大异动）
- 检查间隔2分钟
- 收到通知后深入分析

---

### 2. 持仓保护
**场景**: 你持有某个代币，想及时发现风险

**配置**:
```json
{
  "tokens": [
    {"address": "你的持仓代币", "chain": "bsc"}
  ],
  "thresholds": {
    "price_alert": 5,
    "volume_surge": 2.5,
    "extreme_sell_ratio": 0.6,
    "check_interval": 180
  }
}
```

**策略**:
- 只监控持仓代币
- 中等敏感度
- 特别关注卖压信号

---

### 3. 日内波段
**场景**: 做短线波段交易

**配置**:
```json
{
  "thresholds": {
    "price_alert": 3,
    "volume_surge": 2.0,
    "check_interval": 120
  }
}
```

**策略**:
- 低阈值（3%）
- 短间隔（2分钟）
- 快进快出

---

## ⚙️ 后台运行

### 使用nohup后台运行

```bash
nohup python3 -u universal_dex_monitor.py \
  --config dex_monitor_config.json \
  > dex_monitor.log 2>&1 &

# 查看日志
tail -f dex_monitor.log

# 停止监控
pkill -f universal_dex_monitor
```

### 使用screen（推荐）

```bash
# 创建新session
screen -S dex-monitor

# 启动监控
python3 universal_dex_monitor.py --config dex_monitor_config.json

# 按 Ctrl+A 然后按 D 离开（监控继续运行）

# 重新连接
screen -r dex-monitor

# 停止监控
# 在screen中按 Ctrl+C
```

---

## 🚦 命令行参数完整列表

```bash
python3 universal_dex_monitor.py --help

可选参数:
  --config, -c          配置文件路径 (JSON)
  --token, -t           代币合约地址
  --name, -n            代币名称（可选）
  --chain               链名称 (默认: bsc)
  --telegram-token      Telegram Bot Token
  --chat-id             Telegram Chat ID
  --add-token           添加代币到配置并退出
  --list-tokens         列出配置中的所有代币
```

---

## 🎯 总结

### 优势
- ✅ **通用性强** - 支持所有DEX代币和主流链
- ✅ **灵活配置** - 可同时监控多个代币
- ✅ **完全免费** - 无需任何API Key
- ✅ **智能分析** - 自动识别庄家行为
- ✅ **实时通知** - Telegram推送到手机

### 适用场景
- 🔍 寻找交易机会
- 🛡️ 持仓风险监控
- 📈 波段交易辅助
- 🎓 学习市场规律

---

**开始你的DEX监控之旅！** 🚀
