#!/bin/bash
# DEX监控快速启动脚本

TOOLS_DIR="/Users/helei/Downloads/Jason skills/local-tools"
CONFIG_FILE="$TOOLS_DIR/dex_monitor_config.json"
MONITOR_SCRIPT="$TOOLS_DIR/universal_dex_monitor.py"
LOG_FILE="$TOOLS_DIR/dex_monitor.log"

echo "============================================"
echo "    通用DEX监控系统 - 快速启动"
echo "============================================"
echo ""

# 检查文件
if [ ! -f "$MONITOR_SCRIPT" ]; then
    echo "❌ 错误: 监控脚本不存在"
    echo "   路径: $MONITOR_SCRIPT"
    exit 1
fi

if [ ! -f "$CONFIG_FILE" ]; then
    echo "⚠️  警告: 配置文件不存在，将创建默认配置"
    cat > "$CONFIG_FILE" <<EOF
{
  "tokens": [
    {
      "address": "0x997a58129890bbda032231a52ed1ddc845fc18e1",
      "name": "SIREN",
      "chain": "bsc"
    }
  ],
  "thresholds": {
    "price_alert": 5,
    "volume_surge": 2.5,
    "extreme_buy_ratio": 2.0,
    "extreme_sell_ratio": 0.5,
    "check_interval": 180
  }
}
EOF
    echo "✅ 已创建默认配置: $CONFIG_FILE"
    echo ""
fi

# 显示配置
echo "📋 当前配置:"
echo "-------------------------------------------"
python3 "$MONITOR_SCRIPT" --config "$CONFIG_FILE" --list-tokens 2>/dev/null || echo "  配置文件格式有误"
echo ""

# 询问启动方式
echo "请选择启动方式:"
echo "  1) 前台运行（可直接看到输出）"
echo "  2) 后台运行（使用nohup）"
echo "  3) 取消"
echo ""
read -p "输入选项 [1-3]: " choice

case $choice in
    1)
        echo ""
        echo "🚀 启动监控（前台模式）..."
        echo "   按 Ctrl+C 停止"
        echo ""
        python3 "$MONITOR_SCRIPT" --config "$CONFIG_FILE"
        ;;
    
    2)
        echo ""
        echo "🚀 启动监控（后台模式）..."
        nohup python3 -u "$MONITOR_SCRIPT" --config "$CONFIG_FILE" > "$LOG_FILE" 2>&1 &
        PID=$!
        sleep 2
        
        if kill -0 $PID 2>/dev/null; then
            echo "✅ 监控已启动 (PID: $PID)"
            echo ""
            echo "查看日志:"
            echo "  tail -f $LOG_FILE"
            echo ""
            echo "停止监控:"
            echo "  pkill -f universal_dex_monitor"
            echo ""
        else
            echo "❌ 启动失败，查看日志:"
            echo "  cat $LOG_FILE"
        fi
        ;;
    
    3)
        echo "已取消"
        exit 0
        ;;
    
    *)
        echo "❌ 无效选项"
        exit 1
        ;;
esac
