#!/usr/bin/env python3
"""
动态添加代币监控工具
支持无需重启直接添加新代币
"""
import json
import requests
import subprocess
import sys
from pathlib import Path

class TokenManager:
    def __init__(self, config_dir="/Users/helei/Downloads/Jason skills/local-tools"):
        self.config_dir = Path(config_dir)
        self.dex_config = self.config_dir / "dex_monitor_config.json"
        self.signal_config = self.config_dir / "signal_trader_config.json"
        
    def get_token_info(self, address):
        """从DEX Screener获取代币信息"""
        url = f"https://api.dexscreener.com/latest/dex/tokens/{address}"
        try:
            r = requests.get(url, timeout=10)
            data = r.json()
            
            if 'pairs' in data and len(data['pairs']) > 0:
                pair = data['pairs'][0]
                return {
                    'name': pair.get('baseToken', {}).get('name', 'Unknown'),
                    'symbol': pair.get('baseToken', {}).get('symbol', 'Unknown'),
                    'chain': pair.get('chainId', 'bsc')
                }
            return None
        except Exception as e:
            print(f"获取代币信息失败: {e}")
            return None
    
    def add_token(self, address, name=None, chain='bsc', auto_restart=True):
        """添加代币到监控"""
        print(f"\n{'='*70}")
        print(f"  添加代币到监控系统")
        print(f"{'='*70}\n")
        
        address = address.lower()
        
        # 1. 获取代币信息
        print("1️⃣ 获取代币信息...")
        if name:
            token_name = name
            token_symbol = name
        else:
            info = self.get_token_info(address)
            if info:
                token_name = info['name']
                token_symbol = info['symbol']
                chain = info.get('chain', chain)
                print(f"   ✅ {token_name} ({token_symbol})")
            else:
                token_name = "Unknown"
                token_symbol = "Unknown"
                print(f"   ⚠️  无法获取代币信息，使用默认名称")
        
        token_data = {
            "address": address,
            "name": token_name,
            "chain": chain
        }
        
        # 2. 更新DEX监控配置
        print("\n2️⃣ 更新配置文件...")
        with open(self.dex_config, 'r') as f:
            dex_config = json.load(f)
        
        # 检查是否已存在
        exists = any(t['address'].lower() == address for t in dex_config['tokens'])
        if exists:
            print(f"   ⚠️  代币已在监控列表中")
            return False
        
        dex_config['tokens'].append(token_data)
        
        with open(self.dex_config, 'w') as f:
            json.dump(dex_config, f, indent=2, ensure_ascii=False)
        print(f"   ✅ dex_monitor_config.json")
        
        # 3. 更新信号配置
        with open(self.signal_config, 'r') as f:
            signal_config = json.load(f)
        
        signal_config['tokens'].append(token_data)
        
        with open(self.signal_config, 'w') as f:
            json.dump(signal_config, f, indent=2, ensure_ascii=False)
        print(f"   ✅ signal_trader_config.json")
        
        # 4. 重启监控系统
        if auto_restart:
            print("\n3️⃣ 重启监控系统...")
            self.restart_monitors()
        
        # 5. 发送通知
        print("\n4️⃣ 发送通知...")
        self.send_notification(token_name, address, chain)
        
        print(f"\n{'='*70}")
        print(f"  ✅ {token_name} 已添加到监控！")
        print(f"{'='*70}\n")
        
        return True
    
    def restart_monitors(self):
        """重启监控系统"""
        # 停止旧进程
        subprocess.run("pkill -f 'universal_dex_monitor.py'", shell=True)
        subprocess.run("pkill -f 'universal_signal_trader.py'", shell=True)
        print("   ✅ 已停止旧进程")
        
        import time
        time.sleep(2)
        
        # 启动新进程
        subprocess.Popen(
            "cd '/Users/helei/Downloads/Jason skills/local-tools' && "
            "python3 -u universal_dex_monitor.py --config dex_monitor_config.json "
            "> dex_monitor_$(date +%Y%m%d).log 2>&1 &",
            shell=True
        )
        
        subprocess.Popen(
            "cd '/Users/helei/Downloads/Jason skills/local-tools' && "
            "python3 -u universal_signal_trader.py --config signal_trader_config.json "
            "--telegram-token 8200719161:AAEk04eOrn4WfcY75_gEYaYJHEynGmUV030 "
            "--chat-id 6174733465 "
            "> signal_trader_$(date +%Y%m%d).log 2>&1 &",
            shell=True
        )
        print("   ✅ 监控系统已重启")
    
    def send_notification(self, token_name, address, chain):
        """发送添加成功的通知"""
        TOKEN = "8200719161:AAEk04eOrn4WfcY75_gEYaYJHEynGmUV030"
        CHAT_ID = "6174733465"
        
        message = f"""✅ *新代币已添加到监控*

📍 *代币信息*
名称: {token_name}
地址: `{address}`
链: {chain.upper()}

📊 *监控功能*
• 价格异动（>5%）
• 成交量暴增（>2.5倍）
• 买卖压力异常
• 交易信号捕捉
• 庄家行为识别

⏱️ 每3分钟检查一次

💡 系统正在监控中！"""
        
        url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
        try:
            r = requests.post(url, json={
                "chat_id": CHAT_ID,
                "text": message,
                "parse_mode": "Markdown"
            }, timeout=10)
            if r.status_code == 200:
                print("   ✅ 通知已发送")
        except:
            pass
    
    def list_tokens(self):
        """列出所有监控的代币"""
        with open(self.dex_config, 'r') as f:
            config = json.load(f)
        
        print(f"\n{'='*70}")
        print(f"  当前监控的代币列表")
        print(f"{'='*70}\n")
        
        for i, token in enumerate(config['tokens'], 1):
            print(f"{i}. {token['name']} ({token['chain'].upper()})")
            print(f"   地址: {token['address']}")
            print()


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='代币监控管理工具')
    parser.add_argument('--add', help='添加代币地址')
    parser.add_argument('--name', help='代币名称（可选）')
    parser.add_argument('--chain', default='bsc', help='链名称（默认bsc）')
    parser.add_argument('--list', action='store_true', help='列出所有监控代币')
    parser.add_argument('--no-restart', action='store_true', help='不自动重启监控系统')
    
    args = parser.parse_args()
    
    manager = TokenManager()
    
    if args.list:
        manager.list_tokens()
    elif args.add:
        manager.add_token(
            args.add,
            name=args.name,
            chain=args.chain,
            auto_restart=not args.no_restart
        )
    else:
        parser.print_help()
