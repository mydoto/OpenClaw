#!/usr/bin/env python3
"""
通用DEX代币监控系统
支持监控任何DEX代币（BSC/ETH/Polygon等）
监控价格、成交量、买卖比，自动识别庄家行为
"""

import requests
import time
import json
import sys
import argparse
from datetime import datetime
from pathlib import Path

class UniversalDEXMonitor:
    def __init__(self, telegram_token, chat_id, config_file=None):
        self.telegram_token = telegram_token
        self.chat_id = chat_id
        self.config_file = config_file
        
        # 监控的代币列表
        self.tokens = []
        
        # 历史数据 {token_address: {last_price, last_volume_5m}}
        self.history = {}
        
        # 统计
        self.alert_count = 0
        
        # 监控阈值（可在配置文件中覆盖）
        self.default_thresholds = {
            'price_alert': 5,           # 价格变化>5%通知
            'volume_surge': 2.5,        # 成交量暴增2.5倍通知
            'extreme_buy_ratio': 2.0,   # 买卖比>2（强买压）
            'extreme_sell_ratio': 0.5,  # 买卖比<0.5（强卖压）
            'check_interval': 180       # 3分钟检查一次
        }
        
        # 加载配置
        self.load_config()
    
    def load_config(self):
        """加载配置文件"""
        if not self.config_file or not Path(self.config_file).exists():
            print("⚠️  未找到配置文件，使用命令行参数或默认配置")
            return
        
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            # 加载代币列表
            self.tokens = config.get('tokens', [])
            
            # 加载阈值（如果配置文件中有）
            thresholds = config.get('thresholds', {})
            self.default_thresholds.update(thresholds)
            
            print(f"✅ 已加载配置: {len(self.tokens)} 个代币")
        
        except Exception as e:
            print(f"❌ 加载配置失败: {e}")
    
    def add_token(self, address, name=None, chain='bsc'):
        """添加代币到监控列表"""
        token = {
            'address': address.lower(),
            'name': name or 'Unknown',
            'symbol': name or 'Unknown',
            'chain': chain
        }
        
        # 检查是否已存在
        if any(t['address'] == token['address'] for t in self.tokens):
            print(f"⚠️  {token['name']} 已在监控列表中")
            return False
        
        self.tokens.append(token)
        print(f"✅ 已添加 {token['name']} ({token['chain'].upper()})")
        return True
    
    def remove_token(self, address):
        """从监控列表移除代币"""
        address = address.lower()
        self.tokens = [t for t in self.tokens if t['address'] != address]
        if address in self.history:
            del self.history[address]
    
    def save_config(self):
        """保存配置到文件"""
        if not self.config_file:
            return
        
        config = {
            'tokens': self.tokens,
            'thresholds': self.default_thresholds
        }
        
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            print(f"✅ 配置已保存到 {self.config_file}")
        except Exception as e:
            print(f"❌ 保存配置失败: {e}")
    
    def send_telegram(self, message):
        """发送Telegram通知"""
        url = f"https://api.telegram.org/bot{self.telegram_token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": message,
            "parse_mode": "Markdown",
            "disable_web_page_preview": True
        }
        
        try:
            response = requests.post(url, json=payload, timeout=5)
            return response.json().get("ok", False)
        except Exception as e:
            print(f"[错误] Telegram: {e}")
            return False
    
    def get_token_data(self, token_address):
        """获取代币DEX数据"""
        url = f"https://api.dexscreener.com/latest/dex/tokens/{token_address}"
        
        try:
            r = requests.get(url, timeout=10)
            data = r.json()
            
            if 'pairs' not in data or len(data['pairs']) == 0:
                return None
            
            # 选择流动性最高的交易对
            pairs_with_liquidity = [p for p in data['pairs'] if 'liquidity' in p and 'usd' in p['liquidity']]
            
            if not pairs_with_liquidity:
                # 如果没有流动性数据，选择第一个
                pair = data['pairs'][0]
                liquidity = 0
            else:
                pair = max(pairs_with_liquidity, key=lambda p: float(p['liquidity']['usd']))
                liquidity = float(pair['liquidity']['usd'])
            
            # 解析数据
            price = float(pair['priceUsd'])
            volume = pair['volume']
            changes = pair['priceChange']
            txns = pair.get('txns', {})
            
            return {
                'address': token_address,
                'name': pair.get('baseToken', {}).get('name', 'Unknown'),
                'symbol': pair.get('baseToken', {}).get('symbol', 'Unknown'),
                'chain': pair.get('chainId', 'unknown'),
                'price': price,
                'volume_5m': float(volume.get('m5', 0)),
                'volume_1h': float(volume.get('h1', 0)),
                'volume_24h': float(volume.get('h24', 0)),
                'liquidity': liquidity,
                'change_5m': float(changes.get('m5', 0)),
                'change_1h': float(changes.get('h1', 0)),
                'change_24h': float(changes.get('h24', 0)),
                'buys_5m': txns.get('m5', {}).get('buys', 0),
                'sells_5m': txns.get('m5', {}).get('sells', 0),
                'buys_1h': txns.get('h1', {}).get('buys', 0),
                'sells_1h': txns.get('h1', {}).get('sells', 0),
                'dex_url': pair.get('url', ''),
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
        
        except Exception as e:
            print(f"[错误] 获取 {token_address[:8]}... 数据失败: {e}")
            return None
    
    def analyze_signals(self, data):
        """分析市场信号"""
        if not data:
            return []
        
        signals = []
        address = data['address']
        
        # 获取历史数据
        hist = self.history.get(address, {})
        last_price = hist.get('last_price')
        last_volume = hist.get('last_volume_5m')
        
        # 1. 价格异动检测
        if last_price:
            price_change_pct = (data['price'] - last_price) / last_price * 100
            
            if abs(price_change_pct) >= self.default_thresholds['price_alert']:
                if price_change_pct > 0:
                    signals.append({
                        'type': 'price_surge',
                        'level': 'high' if price_change_pct > 10 else 'medium',
                        'message': f"📈 价格拉升 *{price_change_pct:.2f}%*",
                        'detail': f"从 ${last_price:.6f} → ${data['price']:.6f}"
                    })
                else:
                    signals.append({
                        'type': 'price_dump',
                        'level': 'high' if price_change_pct < -10 else 'medium',
                        'message': f"📉 价格砸盘 *{abs(price_change_pct):.2f}%*",
                        'detail': f"从 ${last_price:.6f} → ${data['price']:.6f}"
                    })
        
        # 2. 成交量暴增检测
        if last_volume and data['volume_5m'] > 0 and last_volume > 0:
            volume_ratio = data['volume_5m'] / last_volume
            
            if volume_ratio >= self.default_thresholds['volume_surge']:
                signals.append({
                    'type': 'volume_surge',
                    'level': 'high' if volume_ratio > 5 else 'medium',
                    'message': f"⚡ 成交量暴增 *{volume_ratio:.1f}倍*",
                    'detail': f"5分钟成交量从 ${last_volume:,.0f} → ${data['volume_5m']:,.0f}"
                })
        
        # 3. 买卖比异常检测
        if data['sells_5m'] > 0:
            buy_sell_ratio = data['buys_5m'] / data['sells_5m']
            
            if buy_sell_ratio >= self.default_thresholds['extreme_buy_ratio']:
                signals.append({
                    'type': 'strong_buy',
                    'level': 'medium',
                    'message': f"🟢 强烈买压",
                    'detail': f"买卖比 {buy_sell_ratio:.2f}:1 (买{data['buys_5m']}/卖{data['sells_5m']})"
                })
            
            elif buy_sell_ratio <= self.default_thresholds['extreme_sell_ratio']:
                signals.append({
                    'type': 'strong_sell',
                    'level': 'medium',
                    'message': f"🔴 强烈卖压",
                    'detail': f"买卖比 {buy_sell_ratio:.2f}:1 (买{data['buys_5m']}/卖{data['sells_5m']})"
                })
        
        # 4. 综合判断：庄家行为
        behavior = self.detect_whale_behavior(data, signals)
        if behavior:
            signals.append(behavior)
        
        return signals
    
    def detect_whale_behavior(self, data, signals):
        """检测庄家行为"""
        signal_types = [s['type'] for s in signals]
        
        # 拉盘特征
        if 'price_surge' in signal_types and 'volume_surge' in signal_types:
            return {
                'type': 'whale_pump',
                'level': 'critical',
                'message': f"🚨 *疑似庄家拉盘！*",
                'detail': f"价格拉升 + 成交量暴增"
            }
        
        # 出货特征
        if 'price_dump' in signal_types and 'strong_sell' in signal_types:
            return {
                'type': 'whale_dump',
                'level': 'critical',
                'message': f"⚠️ *疑似庄家出货！*",
                'detail': f"价格砸盘 + 强烈卖压"
            }
        
        # 吸筹特征
        if 'strong_buy' in signal_types and data['change_5m'] < 2:
            return {
                'type': 'whale_accumulate',
                'level': 'medium',
                'message': f"💡 疑似庄家吸筹",
                'detail': f"低位强买压"
            }
        
        return None
    
    def format_alert(self, data, signals):
        """格式化通知消息"""
        # 按重要性排序
        level_order = {'critical': 0, 'high': 1, 'medium': 2}
        signals.sort(key=lambda x: level_order[x['level']])
        
        # 构建消息
        alert_lines = []
        
        # 标题
        token_name = f"{data['name']} ({data['symbol']})"
        chain_emoji = {
            'bsc': '🔶',
            'ethereum': '⟠',
            'polygon': '🟣',
            'arbitrum': '🔵',
            'base': '🔷'
        }.get(data['chain'], '⚪')
        
        if any(s['level'] == 'critical' for s in signals):
            alert_lines.append(f"🚨 *{token_name} 重大异动！* {chain_emoji}")
        else:
            alert_lines.append(f"⚠️ *{token_name} 市场异动* {chain_emoji}")
        
        alert_lines.append("")
        
        # 信号列表
        for signal in signals:
            alert_lines.append(signal['message'])
            alert_lines.append(f"   _{signal['detail']}_")
            alert_lines.append("")
        
        # 当前数据
        alert_lines.append("📊 *当前数据*")
        alert_lines.append(f"💰 价格: ${data['price']:.8f}")
        alert_lines.append(f"📈 5m: {data['change_5m']:+.2f}% | 1h: {data['change_1h']:+.2f}% | 24h: {data['change_24h']:+.2f}%")
        alert_lines.append("")
        alert_lines.append(f"📊 5分钟: 买{data['buys_5m']} / 卖{data['sells_5m']}")
        alert_lines.append(f"💧 流动性: ${data['liquidity']:,.0f}")
        alert_lines.append(f"📍 地址: `{data['address'][:10]}...{data['address'][-8:]}`")
        alert_lines.append("")
        alert_lines.append(f"⏰ {data['timestamp']}")
        
        if data.get('dex_url'):
            alert_lines.append("")
            alert_lines.append(f"🔗 [查看图表]({data['dex_url']})")
        
        return "\n".join(alert_lines)
    
    def update_history(self, data):
        """更新历史数据"""
        self.history[data['address']] = {
            'last_price': data['price'],
            'last_volume_5m': data['volume_5m']
        }
    
    def monitor_loop(self):
        """主监控循环"""
        if not self.tokens:
            print("❌ 没有要监控的代币！")
            print("使用 --add-token 添加代币，或提供配置文件")
            return
        
        print("=" * 80)
        print("🔍 通用DEX监控系统启动")
        print("=" * 80)
        print()
        print(f"监控代币: {len(self.tokens)} 个")
        for token in self.tokens:
            print(f"  • {token['name']} ({token['chain'].upper()}) - {token['address'][:10]}...")
        print()
        print("监控内容:")
        print(f"  ✓ 价格异动 (>{self.default_thresholds['price_alert']}%)")
        print(f"  ✓ 成交量暴增 (>{self.default_thresholds['volume_surge']}倍)")
        print(f"  ✓ 买卖比异常 (>{self.default_thresholds['extreme_buy_ratio']} 或 <{self.default_thresholds['extreme_sell_ratio']})")
        print(f"  ✓ 庄家行为识别")
        print()
        print(f"检查间隔: {self.default_thresholds['check_interval']}秒 ({self.default_thresholds['check_interval']//60}分钟)")
        print("=" * 80)
        print()
        
        # 初始化：获取所有代币的初始数据
        print("正在获取初始数据...")
        for token in self.tokens:
            data = self.get_token_data(token['address'])
            if data:
                self.update_history(data)
                # 更新代币名称
                token['name'] = data['name']
                token['symbol'] = data['symbol']
                print(f"✅ {data['name']}: ${data['price']:.6f} (24h: {data['change_24h']:+.2f}%)")
            else:
                print(f"❌ {token['address'][:10]}... 获取失败")
            time.sleep(0.5)  # 避免API限制
        
        print()
        
        # 启动通知
        token_list = "\n".join([f"• {t['name']} ({t.get('symbol', t['name'])})" for t in self.tokens])
        startup_msg = (
            f"✅ *DEX监控启动*\n\n"
            f"监控 {len(self.tokens)} 个代币:\n{token_list}\n\n"
            f"检查间隔: {self.default_thresholds['check_interval']//60}分钟\n\n"
            f"_监控中..._"
        )
        self.send_telegram(startup_msg)
        
        check_count = 0
        
        while True:
            try:
                check_count += 1
                now = datetime.now().strftime('%H:%M:%S')
                
                print(f"[{now}] 检查 #{check_count}")
                
                # 检查所有代币
                for token in self.tokens:
                    data = self.get_token_data(token['address'])
                    
                    if not data:
                        print(f"  {token['name']:15s} ⚠️  获取失败")
                        continue
                    
                    # 显示状态
                    buy_sell = f"{data['buys_5m']}/{data['sells_5m']}"
                    print(f"  {data['name']:15s} ${data['price']:.6f} | 5m: {data['change_5m']:+6.2f}% | 买卖: {buy_sell:8s}", end="")
                    
                    # 分析信号
                    signals = self.analyze_signals(data)
                    
                    if signals:
                        print(f" | 🚨 {len(signals)}个异动")
                        
                        # 发送通知
                        alert_message = self.format_alert(data, signals)
                        
                        if self.send_telegram(alert_message):
                            self.alert_count += 1
                            print(f"       ✅ 已通知 (累计 {self.alert_count})")
                    else:
                        print(f" | ✓")
                    
                    # 更新历史
                    self.update_history(data)
                    
                    time.sleep(0.5)  # 避免API限制
                
                print()
                sys.stdout.flush()
                
                # 等待下次检查
                time.sleep(self.default_thresholds['check_interval'])
                
            except KeyboardInterrupt:
                print("\n监控已停止")
                self.send_telegram("⚠️ DEX监控已停止")
                break
            
            except Exception as e:
                print(f"[错误] {e}")
                import traceback
                traceback.print_exc()
                time.sleep(self.default_thresholds['check_interval'])


def main():
    parser = argparse.ArgumentParser(description='通用DEX代币监控系统')
    
    parser.add_argument('--config', '-c', 
                        help='配置文件路径 (JSON)')
    
    parser.add_argument('--token', '-t', 
                        help='代币合约地址')
    
    parser.add_argument('--name', '-n', 
                        help='代币名称（可选）')
    
    parser.add_argument('--chain', 
                        default='bsc',
                        help='链名称 (bsc/eth/polygon等，默认bsc)')
    
    parser.add_argument('--telegram-token', 
                        default='YOUR_TELEGRAM_BOT_TOKEN',
                        help='Telegram Bot Token')
    
    parser.add_argument('--chat-id', 
                        default='YOUR_TELEGRAM_CHAT_ID',
                        help='Telegram Chat ID')
    
    parser.add_argument('--add-token',
                        action='store_true',
                        help='添加代币到配置并退出')
    
    parser.add_argument('--list-tokens',
                        action='store_true',
                        help='列出配置中的所有代币')
    
    args = parser.parse_args()
    
    # 创建监控器
    monitor = UniversalDEXMonitor(
        telegram_token=args.telegram_token,
        chat_id=args.chat_id,
        config_file=args.config
    )
    
    # 如果指定了单个代币，添加到列表
    if args.token:
        monitor.add_token(args.token, args.name, args.chain)
    
    # 处理特殊命令
    if args.add_token:
        if args.token:
            monitor.save_config()
            print("✅ 代币已添加到配置")
        else:
            print("❌ 请使用 --token 指定代币地址")
        return
    
    if args.list_tokens:
        print("\n当前监控的代币:")
        for i, token in enumerate(monitor.tokens, 1):
            print(f"{i}. {token['name']} ({token['chain'].upper()})")
            print(f"   地址: {token['address']}")
        print()
        return
    
    # 启动监控
    monitor.monitor_loop()


if __name__ == "__main__":
    main()
