#!/usr/bin/env python3
"""
通用DEX代币交易信号捕捉系统
支持所有链上的DEX代币，自动生成买入/卖出信号
"""

import requests
import time
import json
import argparse
from datetime import datetime
from pathlib import Path


class UniversalSignalTrader:
    def __init__(self, telegram_token, chat_id, config_file=None):
        self.telegram_token = telegram_token
        self.chat_id = chat_id
        self.config_file = config_file
        
        # 监控的代币列表
        self.tokens = []
        
        # 历史数据 {address: {last_price, last_signal, position, entry_price}}
        self.history = {}
        
        # 信号记录
        self.signals_history = []
        
        # 默认配置
        self.default_config = {
            'check_interval': 180,  # 3分钟
            'signal_strength': {
                'strong_buy': 4,
                'buy': 2,
                'sell': -2,
                'strong_sell': -4
            },
            'thresholds': {
                'strong_buy_ratio': 3.0,
                'buy_ratio': 2.0,
                'strong_sell_ratio': 0.3,
                'sell_ratio': 0.5,
                'surge_pct': 5.0,
                'rise_pct': 3.0,
                'dump_pct': -5.0,
                'drop_pct': -3.0
            },
            'risk_management': {
                'stop_loss_pct': 5.0,
                'take_profit_1_pct': 5.0,
                'take_profit_2_pct': 10.0,
                'position_size_pct': 5.0  # 建议仓位占总资金比例
            }
        }
        
        # 学习目录
        self.learning_dir = Path("/Users/helei/Downloads/Jason skills/trading-assistant/skills/self-learning-trading-system")
        self.signals_log = self.learning_dir / "universal-signals-log.json"
        
        self.load_config()
        self.load_signals_history()
    
    def load_config(self):
        """加载配置文件"""
        if self.config_file and Path(self.config_file).exists():
            with open(self.config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
                self.tokens = config.get('tokens', [])
                
                # 合并配置
                if 'signal_config' in config:
                    for key in config['signal_config']:
                        if key in self.default_config:
                            self.default_config[key].update(config['signal_config'][key])
    
    def save_config(self):
        """保存配置"""
        if not self.config_file:
            return
        
        config = {
            'tokens': self.tokens,
            'signal_config': self.default_config
        }
        
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
    
    def load_signals_history(self):
        """加载历史信号"""
        if self.signals_log.exists():
            with open(self.signals_log, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.signals_history = data.get('signals', [])
    
    def save_signals_history(self):
        """保存信号历史"""
        self.learning_dir.mkdir(parents=True, exist_ok=True)
        with open(self.signals_log, 'w', encoding='utf-8') as f:
            json.dump({
                'signals': self.signals_history[-200:],  # 保留最近200个
                'last_updated': datetime.now().isoformat()
            }, f, indent=2, ensure_ascii=False)
    
    def add_token(self, address, name=None, chain='bsc'):
        """添加监控代币"""
        token = {
            'address': address.lower(),
            'name': name or 'Unknown',
            'chain': chain
        }
        
        # 检查是否已存在
        for t in self.tokens:
            if t['address'] == token['address']:
                print(f"代币 {address} 已存在")
                return False
        
        self.tokens.append(token)
        self.save_config()
        print(f"✅ 已添加: {token['name']} ({chain.upper()})")
        return True
    
    def send_telegram(self, message):
        """发送Telegram通知"""
        url = f"https://api.telegram.org/bot{self.telegram_token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": message,
            "parse_mode": "Markdown",
            "disable_web_page_preview": True
        }
        
        try:
            response = requests.post(url, json=payload, timeout=5)
            return response.json().get("ok", False)
        except Exception as e:
            print(f"[错误] Telegram: {e}")
            return False
    
    def get_token_data(self, token_address):
        """获取代币实时数据"""
        url = f"https://api.dexscreener.com/latest/dex/tokens/{token_address}"
        
        try:
            r = requests.get(url, timeout=10)
            data = r.json()
            
            if 'pairs' not in data or len(data['pairs']) == 0:
                return None
            
            # 选择流动性最高的交易对
            pairs_with_liquidity = [p for p in data['pairs'] if 'liquidity' in p and 'usd' in p['liquidity']]
            if not pairs_with_liquidity:
                pair = data['pairs'][0]
                liquidity = 0
            else:
                pair = max(pairs_with_liquidity, key=lambda p: float(p['liquidity']['usd']))
                liquidity = float(pair['liquidity']['usd'])
            
            price = float(pair['priceUsd'])
            volume = pair['volume']
            changes = pair['priceChange']
            txns = pair.get('txns', {})
            
            return {
                'address': token_address,
                'name': pair.get('baseToken', {}).get('name', 'Unknown'),
                'symbol': pair.get('baseToken', {}).get('symbol', 'Unknown'),
                'chain': pair.get('chainId', 'unknown'),
                'price': price,
                'volume_5m': float(volume.get('m5', 0)),
                'volume_1h': float(volume.get('h1', 0)),
                'volume_24h': float(volume.get('h24', 0)),
                'liquidity': liquidity,
                'change_5m': float(changes.get('m5', 0)),
                'change_1h': float(changes.get('h1', 0)),
                'change_24h': float(changes.get('h24', 0)),
                'buys_5m': txns.get('m5', {}).get('buys', 0),
                'sells_5m': txns.get('m5', {}).get('sells', 0),
                'buys_1h': txns.get('h1', {}).get('buys', 0),
                'sells_1h': txns.get('h1', {}).get('sells', 0),
                'dex_url': pair.get('url', ''),
                'timestamp': datetime.now().isoformat()
            }
        
        except Exception as e:
            print(f"[错误] 获取 {token_address[:8]}... 数据失败: {e}")
            return None
    
    def analyze_signal(self, data):
        """分析交易信号"""
        if not data:
            return None
        
        signals = []
        signal_strength = 0
        thresholds = self.default_config['thresholds']
        
        # 1. 买卖比分析
        if data['sells_5m'] > 0:
            buy_sell_ratio = data['buys_5m'] / data['sells_5m']
            
            if buy_sell_ratio >= thresholds['strong_buy_ratio']:
                signals.append(f"强烈买压 ({buy_sell_ratio:.1f}:1)")
                signal_strength += 3
            elif buy_sell_ratio >= thresholds['buy_ratio']:
                signals.append(f"买压偏强 ({buy_sell_ratio:.1f}:1)")
                signal_strength += 2
            elif buy_sell_ratio <= thresholds['strong_sell_ratio']:
                signals.append(f"强烈卖压 ({buy_sell_ratio:.2f}:1)")
                signal_strength -= 3
            elif buy_sell_ratio <= thresholds['sell_ratio']:
                signals.append(f"卖压偏强 ({buy_sell_ratio:.2f}:1)")
                signal_strength -= 2
        
        # 2. 价格变化分析
        change_5m = data['change_5m']
        if change_5m >= thresholds['surge_pct']:
            signals.append(f"急涨 ({change_5m:+.2f}%)")
            signal_strength += 2
        elif change_5m >= thresholds['rise_pct']:
            signals.append(f"上涨 ({change_5m:+.2f}%)")
            signal_strength += 1
        elif change_5m <= thresholds['dump_pct']:
            signals.append(f"急跌 ({change_5m:+.2f}%)")
            signal_strength -= 2
        elif change_5m <= thresholds['drop_pct']:
            signals.append(f"下跌 ({change_5m:+.2f}%)")
            signal_strength -= 1
        
        # 3. 成交量分析（简化版）
        if data['volume_5m'] > 0 and data['volume_1h'] > 0:
            volume_ratio = (data['volume_5m'] * 12) / data['volume_1h']
            if volume_ratio > 2:
                signals.append("放量")
                signal_strength += 1
        
        # 生成交易信号
        strength_thresholds = self.default_config['signal_strength']
        
        if signal_strength >= strength_thresholds['strong_buy']:
            signal_type = 'STRONG_BUY'
        elif signal_strength >= strength_thresholds['buy']:
            signal_type = 'BUY'
        elif signal_strength <= strength_thresholds['strong_sell']:
            signal_type = 'STRONG_SELL'
        elif signal_strength <= strength_thresholds['sell']:
            signal_type = 'SELL'
        else:
            return None
        
        return {
            'type': signal_type,
            'strength': signal_strength,
            'signals': signals,
            'price': data['price'],
            'data': data,
            'timestamp': data['timestamp']
        }
    
    def calculate_entry_exit(self, signal, data):
        """计算入场、止损、止盈位"""
        price = data['price']
        risk = self.default_config['risk_management']
        
        if signal['type'] in ['BUY', 'STRONG_BUY']:
            # 做多
            entry = price
            stop_loss = price * (1 - risk['stop_loss_pct'] / 100)
            take_profit_1 = price * (1 + risk['take_profit_1_pct'] / 100)
            take_profit_2 = price * (1 + risk['take_profit_2_pct'] / 100)
            direction = "做多"
            
        else:  # SELL, STRONG_SELL
            # 做空
            entry = price
            stop_loss = price * (1 + risk['stop_loss_pct'] / 100)
            take_profit_1 = price * (1 - risk['take_profit_1_pct'] / 100)
            take_profit_2 = price * (1 - risk['take_profit_2_pct'] / 100)
            direction = "做空"
        
        return {
            'direction': direction,
            'entry': entry,
            'stop_loss': stop_loss,
            'take_profit_1': take_profit_1,
            'take_profit_2': take_profit_2,
            'position_size': risk['position_size_pct']
        }
    
    def format_signal_message(self, signal, entry_exit):
        """格式化信号消息"""
        data = signal['data']
        
        signal_emoji = {
            'STRONG_BUY': '🟢🟢🟢',
            'BUY': '🟢',
            'SELL': '🔴',
            'STRONG_SELL': '🔴🔴🔴'
        }
        
        chain_emoji = {
            'bsc': '🔶',
            'ethereum': '⟠',
            'polygon': '🟣',
            'arbitrum': '🔵',
            'base': '🔷'
        }.get(data['chain'], '⚪')
        
        emoji = signal_emoji.get(signal['type'], '⚪')
        token_name = f"{data['name']} ({data['symbol']})"
        
        buy_sell_ratio_str = f"{data['buys_5m']/data['sells_5m']:.2f}" if data['sells_5m'] > 0 else 'N/A'
        
        message = f"""
{emoji} *交易信号！* {chain_emoji}

📌 *{token_name}*

🎯 *信号类型*: {signal['type']}
📊 *信号强度*: {abs(signal['strength'])}/10
💡 *信号依据*: {', '.join(signal['signals'])}

💰 *当前价格*: ${data['price']:.8f}
📈 *5分钟*: {data['change_5m']:+.2f}%
📈 *1小时*: {data['change_1h']:+.2f}%
📈 *24小时*: {data['change_24h']:+.2f}%

📊 *买卖数据*:
   买: {data['buys_5m']} | 卖: {data['sells_5m']}
   买卖比: {buy_sell_ratio_str}

📍 *合约地址*:
`{data['address']}`

---

🎯 *交易建议*: {entry_exit['direction']}

💰 *入场价*: ${entry_exit['entry']:.8f}
🛑 *止损位*: ${entry_exit['stop_loss']:.8f} ({'-' if entry_exit['direction'] == '做多' else '+'}{self.default_config['risk_management']['stop_loss_pct']}%)
🎯 *止盈1*: ${entry_exit['take_profit_1']:.8f} ({'+' if entry_exit['direction'] == '做多' else '-'}{self.default_config['risk_management']['take_profit_1_pct']}%)
🎯 *止盈2*: ${entry_exit['take_profit_2']:.8f} ({'+' if entry_exit['direction'] == '做多' else '-'}{self.default_config['risk_management']['take_profit_2_pct']}%)
💼 *建议仓位*: {entry_exit['position_size']}% 总资金

⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

⚠️ *风险提示*: 
- DEX代币波动大，严格止损
- 达到止盈1可减仓50%
- 不要FOMO，等待信号
"""
        
        if data.get('dex_url'):
            message += f"\n🔗 [查看图表]({data['dex_url']})"
        
        return message
    
    def run(self):
        """运行信号捕捉"""
        if not self.tokens:
            print("❌ 没有要监控的代币！")
            print("使用 --add-token 添加代币")
            return
        
        print("=" * 80)
        print("🎯 通用交易信号捕捉系统启动")
        print("=" * 80)
        print()
        print(f"监控代币: {len(self.tokens)} 个")
        for token in self.tokens:
            print(f"  • {token['name']} ({token['chain'].upper()}) - {token['address'][:10]}...")
        print()
        print("监控内容:")
        print("  ✓ 实时价格变化")
        print("  ✓ 买卖压力分析")
        print("  ✓ 成交量分析")
        print("  ✓ 自动生成交易信号")
        print()
        print(f"检查间隔: {self.default_config['check_interval']}秒")
        print("=" * 80)
        print()
        
        # 启动通知
        self.send_telegram(
            f"✅ *交易信号系统启动*\n\n"
            f"监控 {len(self.tokens)} 个代币\n"
            f"有信号会立即通知你！"
        )
        
        check_count = 0
        
        while True:
            try:
                check_count += 1
                now = datetime.now().strftime('%H:%M:%S')
                
                print(f"[{now}] 检查 #{check_count}")
                
                for token in self.tokens:
                    # 获取数据
                    data = self.get_token_data(token['address'])
                    
                    if not data:
                        print(f"  {token['name']}: ⚠️ 获取数据失败")
                        continue
                    
                    # 更新名称
                    if token['name'] == 'Unknown':
                        token['name'] = data['name']
                        self.save_config()
                    
                    # 显示当前状态
                    print(f"  {data['symbol']}: ${data['price']:.8f} | 5m: {data['change_5m']:+.2f}% | B/S: {data['buys_5m']}/{data['sells_5m']}")
                    
                    # 分析信号
                    signal = self.analyze_signal(data)
                    
                    if signal:
                        print(f"    🎯 发现信号: {signal['type']} (强度: {signal['strength']})")
                        
                        # 计算入场出场点
                        entry_exit = self.calculate_entry_exit(signal, data)
                        
                        # 格式化消息
                        message = self.format_signal_message(signal, entry_exit)
                        
                        # 发送通知
                        if self.send_telegram(message):
                            print(f"    ✅ 信号已发送")
                            
                            # 记录信号
                            signal_record = {
                                'timestamp': signal['timestamp'],
                                'token': data['symbol'],
                                'address': data['address'],
                                'chain': data['chain'],
                                'type': signal['type'],
                                'price': signal['price'],
                                'strength': signal['strength'],
                                'signals': signal['signals'],
                                'entry_exit': entry_exit
                            }
                            self.signals_history.append(signal_record)
                            self.save_signals_history()
                
                print()
                time.sleep(self.default_config['check_interval'])
                
            except KeyboardInterrupt:
                print("\n信号捕捉已停止")
                self.send_telegram("⚠️ 交易信号系统已停止")
                break
            
            except Exception as e:
                print(f"[错误] {e}")
                import traceback
                traceback.print_exc()
                time.sleep(self.default_config['check_interval'])


def main():
    parser = argparse.ArgumentParser(description='通用DEX代币交易信号捕捉系统')
    parser.add_argument('--config', '-c', help='配置文件路径 (JSON)')
    parser.add_argument('--telegram-token', default='YOUR_TELEGRAM_BOT_TOKEN', help='Telegram Bot Token')
    parser.add_argument('--chat-id', default='YOUR_TELEGRAM_CHAT_ID', help='Telegram Chat ID')
    parser.add_argument('--add-token', action='store_true', help='添加代币到配置')
    parser.add_argument('--token', '-t', help='代币合约地址')
    parser.add_argument('--name', '-n', help='代币名称（可选）')
    parser.add_argument('--chain', default='bsc', help='链名称 (bsc/ethereum/polygon等)')
    parser.add_argument('--list-tokens', action='store_true', help='列出配置中的所有代币')
    
    args = parser.parse_args()
    
    trader = UniversalSignalTrader(args.telegram_token, args.chat_id, args.config)
    
    if args.list_tokens:
        if not trader.tokens:
            print("没有监控的代币")
        else:
            print(f"\n监控代币列表 ({len(trader.tokens)} 个):\n")
            for i, token in enumerate(trader.tokens, 1):
                print(f"{i}. {token['name']} ({token['chain'].upper()})")
                print(f"   地址: {token['address']}")
                print()
        return
    
    if args.add_token:
        if not args.token:
            print("❌ 请提供代币地址 --token")
            return
        
        trader.add_token(args.token, args.name, args.chain)
        print("\n使用以下命令开始监控:")
        print(f"python3 universal_signal_trader.py --config {args.config}")
        return
    
    # 开始监控
    trader.run()


if __name__ == "__main__":
    main()
